# 移植到另一台电脑

## 最快路径（3 步）

1. 把 `tgb-jian-gu-qi-yi.zip`（4.8MB）拷到新电脑，解压，得到 `tgb-jian-gu-qi-yi/` 目录
2. 双击目录里的 **`install.cmd`**（macOS / Linux 用 `python3 scripts/install.py`）
3. 按提示粘一次 cookie，完事

安装器会自动：装到 `~/.workbuddy/skills/tgb-jian-gu-qi-yi` → 检查 Python →
没 `requests` 就建独立 venv 装上 → 写好路径配置 → 生成 `更新.cmd` → 跑一次自检。

**不跑安装器也行**：直接把解压出来的 `tgb-jian-gu-qi-yi/` 文件夹整个丢进
WorkBuddy 的技能目录（`~/.workbuddy/skills/`），重启 WorkBuddy 就能检索。
只是**不能增量更新数据**（缺 Python 环境和路径配置）。

## 前置条件

| 项目 | 要求 | 说明 |
|---|---|---|
| Python | 3.9+ | 只用于「抓取更新」，纯检索不需要 |
| requests | 任意版本 | 安装器会自动装；手动装：`pip install requests` |
| 网络 | 能访问 tgb.cn | 只更新时需要 |
| cookie | 淘股吧登录态 | 只更新时需要，见下 |

## 目录里有什么

```
tgb-jian-gu-qi-yi/
├── SKILL.md                     技能说明（WorkBuddy 读这个）
├── install.cmd                  Windows 双击安装
├── PORTING.md                   本文件
├── scripts/
│   ├── install.py               移植安装器
│   ├── update_kb.py             一键增量更新
│   ├── tgb_kb.py                公共库
│   ├── build_replies_index.py   单独重建精华+索引
│   ├── build_handbook.py        单独重建速查手册
│   ├── count_pages.py           统计评论页数（诊断用）
│   └── README.md                接口机制 + 踩坑清单
└── references/                  12.4MB 数据
    ├── index.md                 主帖主题索引
    ├── index_topics.txt         主帖列表（含跟帖总数）
    ├── posts/                   98 篇主帖正文
    ├── replies/                 50,783 条楼主跟帖（全量）
    ├── replies_digest/          25,052 条精华（推荐检索这个）
    ├── replies_index.md         跟帖总索引
    └── 跟帖实战速查手册.md       214 条实战原话 / 11 主题
```

## 两种运行模式

| 模式 | 命令 | 数据在哪 | 适用 |
|---|---|---|---|
| **原地模式** | `update_kb.py --inplace --root <技能目录>` | 技能目录 `references/` 内，只有一份 | **新机器用这个** |
| 普通模式 | `update_kb.py` | 独立工作目录 + 同步进技能目录，两份 | 本机开发、要保留原始抓取产物 |

安装器默认配成**原地模式**，不浪费一倍磁盘（数据 12.4MB，两份就是 25MB）。

## cookie

抓取更新需要淘股吧登录态。它**会过期**，过期时 `update_kb.py` 第一步就会明确报错。

获取：浏览器登录 tgb.cn → F12 → Network → 任选一个请求 →
Request Headers 里复制整条 `cookie` 的值。

存放位置（任选其一，优先级从高到低）：

1. `--cookie-file <路径>`
2. 环境变量 `TGB_COOKIE`
3. `<ROOT>/cookie.txt`（原地模式下就是技能目录下的 `cookie.txt`）

> 打包时 **cookie.txt 被有意排除在外**，所以新机器需要重新配一次。
> 这是对的——cookie 是账号凭据，不该跟着包到处传。

## 跨平台

- Windows：`install.cmd` / `更新.cmd`（`.venv\Scripts\python.exe`）
- macOS / Linux：
  ```bash
  python3 scripts/install.py
  ./更新.sh
  ```
  技能目录统一是 `~/.workbuddy/skills/tgb-jian-gu-qi-yi`，装到别处加 `--dest`。

## 常见问题

**Q：装完 WorkBuddy 里搜不到这个技能？**
确认目录名是 `tgb-jian-gu-qi-yi` 且直接位于 `~/.workbuddy/skills/` 下
（即 `~/.workbuddy/skills/tgb-jian-gu-qi-yi/SKILL.md` 存在），然后重启 WorkBuddy。

**Q：`No module named 'requests'`？**
系统 Python 常常没装。用安装器建的 venv 解释器，或手动 `pip install requests`。

**Q：自检报「cookie 失效」？**
cookie 过期了。重新从浏览器复制一条存到 `<技能目录>/cookie.txt`。
不影响已经下载好的 12.4MB 数据——检索照常能用。

**Q：只想读、不想抓？**
什么都不用配。解压 → 放进 skills 目录 → 重启 WorkBuddy。

**Q：数据怎么同步回旧电脑？**
在任何一台机器上跑完更新后，把 `references/` 整个目录拷过去覆盖即可。
`kb_state.json` 也一起拷，这样增量判定不会失效。
