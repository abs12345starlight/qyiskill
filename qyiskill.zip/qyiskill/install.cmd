@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo ============================================================
echo   见股起意知识库 - 移植安装
echo ============================================================
echo.

set FOUND=
for %%P in ("%USERPROFILE%\.workbuddy\binaries\python\envs\default\Scripts\python.exe" "python3" "python" "py") do (
    if not defined FOUND (
        %%~P -c "import sys" >nul 2>&1
        if not errorlevel 1 (
            set "FOUND=%%~P"
        )
    )
)

if not defined FOUND (
    echo [错误] 没找到 Python。请先安装 Python 3.9+ 并勾选 Add to PATH。
    echo        下载地址: https://www.python.org/downloads/
    pause
    exit /b 1
)

"%FOUND%" "%~dp0scripts\install.py" %*
echo.
pause
