# -*- coding: utf-8 -*-
"""
见股起意知识库 · 公共库
========================================
所有抓取/解析脚本共用的底层能力：
  - 配置解析（工作目录 / 技能目录 / cookie）
  - HTTP 会话（线程安全 + 重试）
  - 主帖列表抓取（带跟帖总数）
  - 评论页解析（楼主跟帖 / 全部跟帖）
  - 主帖正文解析
  - Markdown 读写与解析（跟帖 md ↔ 结构化条目）
  - 精华过滤规则

路径优先级：
  ROOT      : --root 参数 > 环境变量 TGB_KB_ROOT > <script>/_root.txt > 默认工作区
  SKILL_DIR : 环境变量 TGB_SKILL_DIR > ~/.workbuddy/skills/tgb-jian-gu-qi-yi
  COOKIE    : --cookie-file 参数 > 环境变量 TGB_COOKIE > <ROOT>/cookie.txt
              > <script>/cookie.txt > 脚本内置 FALLBACK_COOKIE（会过期）
"""
import os
import re
import sys
import json
import time
import threading
import html as htmlmod

import requests

BASE = "https://www.tgb.cn"
AUTHOR_ID = "8478060"
AUTHOR_NAME = "见股起意"

DEFAULT_ROOT = r"C:/Users/zx744/WorkBuddy/2026-07-29-10-57-33"

# 内置备用 cookie（会过期）。推荐把新 cookie 写进 <ROOT>/cookie.txt。
FALLBACK_COOKIE = (
    "gdp_user_id=gioenc-9de92826%2Cb19d%2C51e3%2C8b9d%2C71a78e15066e; "
    "893eedf422617c96_gdp_gio_id=gioenc-00327904; "
    "893eedf422617c96_gdp_cs1=gioenc-00327904; "
    "_c_WBKFRo=tS4gNz2mBRfyAmKvAmSLwHjvELSHGBSHu2WfpBcd; "
    "acw_tc=7929ee2c17852932668108997e1418eb547bf1383888706a9b63a37b629840; "
    "JSESSIONID=MzBkZDNkMTMtMTVlNy00ZWE1LWE4OTYtODllNWMzZjQ1YjZl; "
    "tgbuser=11236815; "
    "tgbpwd=ac17a2884cf0409e8b169cbe7ac6521d4969d2cbe7ef8767d6be0f4a9941435210szv7rkebnvwo6; "
    "loginStatus=account; creatorStatus11236815=true; wsStatus=true; showStatus11236815=true"
)

HEADERS = {
    "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "accept-language": "zh-CN,zh;q=0.9",
    "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                  "(KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36",
}

# 付费墙标记：网页端「只看该作者」积分耗尽时返回 HTTP 200 的提示页
POVERTY_MARK = "积分不够"

# ===== 配置 =====

def get_root(root=None):
    if root:
        return os.path.abspath(root)
    env = os.environ.get("TGB_KB_ROOT")
    if env:
        return os.path.abspath(env)
    here = os.path.dirname(os.path.abspath(__file__))
    p = os.path.join(here, "_root.txt")
    if os.path.exists(p):
        with open(p, "r", encoding="utf-8") as f:
            v = f.read().strip()
        if v:
            return os.path.abspath(v)
    return DEFAULT_ROOT


def get_skill_dir():
    env = os.environ.get("TGB_SKILL_DIR")
    if env:
        return os.path.abspath(env)
    return os.path.join(os.path.expanduser("~"), ".workbuddy", "skills",
                        "tgb-jian-gu-qi-yi")


# 目录布局。两种模式：
#   普通模式 —— 数据在独立工作目录，跑完再同步进技能目录（本机开发用）
#   inplace  —— 数据就住在技能目录 references/ 下，原地更新（移植到新机器用）
_LAYOUT = {"base": "", "posts": "tgb_posts", "replies": "tgb_replies",
           "digest": "tgb_replies_digest", "index": "tgb_replies_index.md",
           "topics": "tgb_all_topics.txt"}


def set_layout(inplace=False):
    global _LAYOUT
    _LAYOUT = ({"base": "references", "posts": "posts", "replies": "replies",
                "digest": "replies_digest", "index": "replies_index.md",
                "topics": "index_topics.txt"}
               if inplace else
               {"base": "", "posts": "tgb_posts", "replies": "tgb_replies",
                "digest": "tgb_replies_digest", "index": "tgb_replies_index.md",
                "topics": "tgb_all_topics.txt"})


def sub(key, root):
    """按当前布局取子目录路径"""
    return os.path.join(root, _LAYOUT["base"], _LAYOUT[key])


def load_cookie(path=None, root=None):
    """按优先级加载 cookie 字符串，返回 (cookie_str, 来源说明)"""
    cands = []
    if path:
        cands.append((path, "--cookie-file"))
    env = os.environ.get("TGB_COOKIE")
    if env:
        cands.append((None, "环境变量 TGB_COOKIE"))
    root = root or get_root()
    cands.append((os.path.join(root, "cookie.txt"), "<ROOT>/cookie.txt"))
    cands.append((os.path.join(os.path.dirname(os.path.abspath(__file__)),
                               "cookie.txt"), "<scripts>/cookie.txt"))
    for p, label in cands:
        if p is None:
            return env.strip(), label
        if os.path.exists(p):
            with open(p, "r", encoding="utf-8") as f:
                s = f.read().strip()
            if s:
                return s, f"{label} ({p})"
    return FALLBACK_COOKIE, "脚本内置 FALLBACK_COOKIE（大概率已过期）"


# ===== HTTP =====

_local = threading.local()
_COOKIE_CACHE = {"value": None}


def init_cookie(cookie_str):
    _COOKIE_CACHE["value"] = cookie_str


def _cookie():
    if _COOKIE_CACHE["value"] is None:
        _COOKIE_CACHE["value"], _ = load_cookie()
    return _COOKIE_CACHE["value"]


def session():
    s = getattr(_local, "s", None)
    if s is None:
        s = requests.Session()
        s.headers.update(HEADERS)
        s.headers["referer"] = f"{BASE}/blog/{AUTHOR_ID}"
        s.cookies.update(
            dict(kv.strip().split("=", 1) for kv in _cookie().split(";") if "=" in kv)
        )
        _local.s = s
    return s


def get(url, retries=3, timeout=30):
    for i in range(retries):
        try:
            r = session().get(url, timeout=timeout)
            if r.status_code == 200:
                r.encoding = "utf-8"
                return r.text
            if r.status_code in (403, 429, 503):
                time.sleep(5 * (i + 1))
                continue
        except Exception:
            pass
        time.sleep(2 * (i + 1))
    return None


def check_cookie():
    """校验 cookie 是否还有效。返回 (ok: bool, 说明: str)"""
    h = get(f"{BASE}/user/blog/moreTopic?userID={AUTHOR_ID}")
    if not h:
        return False, "请求失败（网络不通 / 被拦截）"
    slugs = re.findall(r'href="(/a/[A-Za-z0-9]+)"', h)
    if not slugs:
        t = re.search(r"<title>(.*?)</title>", h, re.S)
        title = htmlmod.unescape(t.group(1)).strip() if t else "无标题"
        return False, f"未取到主帖列表（页面标题：{title}），cookie 多半已失效"
    return True, f"正常，读到 {len(slugs)} 条主帖链接"


# ===== 文本清洗 =====

def clean_text(s):
    s = re.sub(r"<br\s*/?>", "\n", s, flags=re.I)
    s = re.sub(r"</p>", "\n", s, flags=re.I)
    s = re.sub(r"<[^>]+>", "", s)
    s = htmlmod.unescape(s)
    s = re.sub(r"[ \t\u00a0]+", " ", s)
    return "\n".join(ln.strip() for ln in s.split("\n") if ln.strip()).strip()


def safe_name(s):
    return re.sub(r'[\\/:*?"<>|]', "_", s)[:80].strip()


# ===== 主帖列表 =====

def fetch_topics(max_pages=30, sleep=0.3):
    """
    抓取博主全部主帖。返回 [{idx, title, slug, reply_count}, ...]
    列表页按时间倒序，因此 idx 从 1 开始即为「最新」。
    分页用「新页无新增 slug 即停止」的方式兜底（详见 README）。
    """
    out, seen = [], set()
    for p in range(1, max_pages + 1):
        url = f"{BASE}/user/blog/moreTopic?userID={AUTHOR_ID}"
        if p > 1:
            url += f"&pageNo={p}"
        h = get(url)
        if not h:
            break
        rows = re.findall(
            r'data-subject="([^"]*)"\s*/>.*?href="(/a/[A-Za-z0-9]+)"[^>]*>.*?\((\d+)\)',
            h, re.S)
        added = 0
        for subj, slug, cnt in rows:
            if slug in seen:
                continue
            seen.add(slug)
            added += 1
            out.append({
                "title": htmlmod.unescape(subj).strip(),
                "slug": slug,
                "reply_count": int(cnt),
            })
        if added == 0:
            break
        time.sleep(sleep)
    for i, t in enumerate(out, 1):
        t["idx"] = i
    return out


def write_topics_txt(topics, path):
    L = [f"{AUTHOR_NAME} (userID={AUTHOR_ID}) 全部主贴列表",
         f"总计: {len(topics)} 篇",
         "=" * 80, ""]
    for t in topics:
        L.append(f"  {t['idx']}. {t['title']}")
        L.append(f"     {BASE}{t['slug']}")
        L.append("")
    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(L))


# ===== 评论解析 =====

def parse_replies(page_html, only_author=True):
    """解析评论页 HTML，返回 [{time, floor, quote, content}, ...]"""
    out = []
    blocks = re.split(r'(?=<div class="comment-data user_\d+")', page_html)
    for b in blocks[1:]:
        uid = re.search(r'class="comment-data user_(\d+)"', b)
        if not uid:
            continue
        if only_author and uid.group(1) != AUTHOR_ID:
            continue
        tm = re.search(r'<span class="pcyclspan left c999"[^>]*>([\d\-: ]+)</span>', b)
        floor = re.search(r'<span class="left">\s*(第?\d+楼|沙发|板凳|地板)[^<]*', b)
        txt = re.search(r'<div class="comment-data-text" id="reply\d+">(.*?)</div>', b, re.S)
        quote = re.search(r'<div class="comment-data-quote"[^>]*>(.*?)</div>', b, re.S)
        if not txt:
            continue
        content = clean_text(txt.group(1))
        if not content:
            continue
        out.append({
            "time": tm.group(1).strip() if tm else "",
            "floor": floor.group(1).strip() if floor else "",
            "quote": clean_text(quote.group(1)) if quote else "",
            "content": content,
        })
    return out


def count_pages(slug):
    """统计某篇帖子的评论总页数；失败返回 None"""
    h = get(f"{BASE}{slug}-1?type=Z")
    if not h:
        return None
    m = re.search(r"共<b[^>]*>\s*(\d+)\s*</b>/(\d+)页", h)
    return int(m.group(2)) if m else 1


def scrape_page_range(slug, start, end):
    """抓取 slug 的第 start~end 页楼主跟帖（含端点）"""
    got = []
    for p in range(start, end + 1):
        h = get(f"{BASE}{slug}-{p}?type=Z")
        if not h:
            continue
        if POVERTY_MARK in h[:2000]:
            raise RuntimeError("触发积分付费墙，请停止使用 lookUserTopic 类接口")
        got.extend(parse_replies(h))
    return got


def dedup_key(item):
    return (item["time"], item["content"][:50])


# ===== Markdown 读写 =====

def build_md(idx, title, slug, items, reply_count=None):
    url = f"{BASE}{slug}"
    L = [f"# {title}", "",
         f"- 序号：{idx:03d}",
         f"- 作者：{AUTHOR_NAME}",
         f"- 原帖：{url}",
         f"- 楼主跟帖：{len(items)} 条"]
    if reply_count is not None:
        L.append(f"- 全站跟帖总数：{reply_count}")
    L += ["", "---", ""]
    cur = None
    for r in items:
        d = r["time"][:10]
        if d != cur:
            cur = d
            L.append(f"## {d}")
            L.append("")
        head = f"**{r['time'][11:] or r['time']}**"
        if r["floor"]:
            head += f" · {r['floor']}"
        L.append(head)
        L.append("")
        if r["quote"]:
            L.append("> " + r["quote"].replace("\n", "\n> "))
            L.append("")
        L.append(r["content"])
        L.append("")
    return "\n".join(L)


def parse_md(path):
    """
    解析跟帖 md，返回 (header_str, items)
    items: [{time, floor, quote, content}]
    注意：收集引用前必须先跳过空行，否则引用会被误当正文（曾踩过的坑）。
    """
    with open(path, "r", encoding="utf-8") as f:
        lines = f.read().split("\n")
    header, items = [], []
    i = 0
    cur_date = ""
    while i < len(lines):
        ln = lines[i]
        if ln.startswith("## ") and re.match(r"^\d{4}-\d{2}-\d{2}$", ln[3:].strip()):
            cur_date = ln[3:].strip()
        m = re.match(r"^\*\*(\d{2}:\d{2}|\d{4}-\d{2}-\d{2} \d{2}:\d{2})\*\*"
                     r"(?:\s*·\s*(.+?))?\s*$", ln)
        if m:
            tm = m.group(1)
            floor = m.group(2) or ""
            full_time = tm if len(tm) > 5 else f"{cur_date} {tm}"
            i += 1
            while i < len(lines) and lines[i].strip() == "":
                i += 1
            quote = []
            while i < len(lines) and lines[i].startswith("> "):
                quote.append(lines[i][2:])
                i += 1
            while i < len(lines) and lines[i].strip() == "":
                i += 1
            body = []
            while (i < len(lines) and lines[i].strip() != ""
                   and not lines[i].startswith("**")
                   and not lines[i].startswith("## ")):
                body.append(lines[i])
                i += 1
            items.append({"time": full_time, "floor": floor,
                          "quote": "\n".join(quote).strip(),
                          "content": "\n".join(body).strip()})
            continue
        header.append(ln)
        i += 1
    return "\n".join(header).strip(), items


# ===== 主帖正文 =====

def extract_article(html):
    """提取主帖标题 / 日期 / 正文"""
    res = {}
    m = re.search(r"<title>(.*?)</title>", html, re.S)
    if m:
        t = htmlmod.unescape(m.group(1).strip())
        t = re.sub(r"\s*[-_]\s*见股起意.*$", "", t)
        t = re.sub(r"\s*_\s*淘股吧.*$", "", t)
        res["title"] = t.strip()
    m = re.search(r"(\d{4}-\d{1,2}-\d{1,2}\s+\d{1,2}:\d{2})", html)
    if m:
        res["date"] = m.group(1)
    body = _slice_div(html, r'<div[^>]*class="[^"]*article-text p_coten[^"]*"[^>]*>')
    if not body:
        body = _slice_div(html, r'<div[^>]*class="[^"]*article-content[^"]*"[^>]*>')
    if body:
        body = re.sub(r"<br\s*/?>", "\n", body, flags=re.I)
        body = re.sub(r"</p>", "\n\n", body, flags=re.I)
        body = re.sub(r"</div>", "\n", body, flags=re.I)
        body = re.sub(r"</h\d>", "\n\n", body, flags=re.I)
        body = re.sub(r"<[^>]+>", "", body)
        body = htmlmod.unescape(body)
        lines = []
        for ln in body.split("\n"):
            s = ln.strip()
            if s:
                lines.append(s)
            elif lines and lines[-1] != "":
                lines.append("")
        res["body"] = "\n".join(lines)
    return res


def _slice_div(html, pattern):
    m = re.search(pattern, html)
    if not m:
        return None
    start, depth, pos = m.end(), 1, m.end()
    while depth > 0 and pos < len(html):
        op = re.search(r"<div[^>]*>", html[pos:])
        cl = re.search(r"</div>", html[pos:])
        if not cl:
            break
        if op and op.start() < cl.start():
            depth += 1
            pos += op.end()
        else:
            depth -= 1
            if depth == 0:
                return html[start:pos]
            pos += cl.end()
    return None


# ===== 精华过滤 =====

KEYWORDS = [
    "低吸", "降仓", "加仓", "清仓", "减仓", "空仓", "满仓", "仓位", "格局", "主升",
    "分歧", "一致", "节点", "核心", "龙头", "补涨", "卡位", "竞价", "封板", "炸板",
    "回封", "量能", "放量", "缩量", "均线", "五日线", "5日线", "支撑", "压力",
    "天谴", "渡劫", "离场", "进场", "出手", "风险", "机会", "修复", "反包", "断板",
    "切换", "T出", "T出底仓", "滚动", "做T", "题材", "板块", "情绪", "高潮", "退潮",
    "冰点", "回暖", "涨停", "跌停", "深水", "水下", "红盘", "冲高", "杀跌", "砸",
    "预期", "观察", "关注", "等待", "管住手", "止损", "止盈", "落袋", "持有", "拿着",
    "和而泰", "华胜", "利欧", "红宝丽", "国芳", "银之杰", "克来", "中毅达", "拓维",
]

GREETINGS = re.compile(
    r"^(早呀|早上好|早|晚上好|晚安|好|好的|嗯|嗯嗯|哦|啊|哈哈|哈哈哈|谢谢|多谢|"
    r"收到了|看到了|知道|知道了|明白|收到|是的|对|对对|不错|加油|辛苦|辛苦了|"
    r"支持|顶|赞|666|好的呢|好嘞|好哒|好de|ok|OK|Ok|嗯呢|嘻嘻|呵呵|哈哈哈哈|"
    r"师父早|师父好|老师早|老师好|大家早|各位早|早啊|早安|晚好|吃了吗|在吗|"
    r"谢谢师父|感谢|感谢师父|抱拳|玫瑰花|鲜花|爱心|强|赞赞赞|牛|牛逼|厉害)[\s！!。.~,，]*$"
)


def is_valuable(content):
    c = content.strip()
    if not c:
        return False
    if GREETINGS.match(c):
        return False
    if any(k in c for k in KEYWORDS):
        return True
    return len(c) >= 20


# ===== 精华版 + 索引 =====

def build_digest_index(root):
    """
    扫描 <root>/tgb_replies/*.md →
      生成 <root>/tgb_replies_digest/*.md（精华版）
      生成 <root>/tgb_replies_index.md（总索引）
    返回 (总跟帖数, 精华数, 文件数)
    """
    src = sub("replies", root)
    dig = sub("digest", root)
    os.makedirs(dig, exist_ok=True)
    files = sorted(f for f in os.listdir(src) if f.endswith(".md"))

    total_all = total_val = 0
    L = ["# 见股起意 · 跟帖（评论区）总索引", "",
         f"> 博主在 {len(files)} 篇主帖下的全部跟帖。跟帖中包含大量盘中实时提示、",
         "> 个股点评与答疑，是主帖之外最重要的实战内容。", "",
         "| # | 主帖 | 跟帖总数 | 精华数 | 文件 |",
         "|---|------|---------|--------|------|"]

    for fn in files:
        path = os.path.join(src, fn)
        header, items = parse_md(path)
        total_all += len(items)
        val = [it for it in items if is_valuable(it["content"])]
        total_val += len(val)

        m = re.search(r"^# (.+)$", header, re.M)
        title = m.group(1).strip() if m else fn
        idx = fn[:3]

        if val:
            out = [f"# {title} · 跟帖精华", "",
                   f"- 原帖文件：`{fn}`",
                   f"- 跟帖总数：{len(items)}，精华：{len(val)}", "", "---", ""]
            cur = None
            for it in val:
                d = it["time"][:10]
                if d != cur:
                    cur = d
                    out += [f"## {d}", ""]
                head = f"**{it['time'][11:] or it['time']}**"
                if it["floor"]:
                    head += f" · {it['floor']}"
                out += [head, ""]
                if it["quote"]:
                    out += ["> " + it["quote"].replace("\n", "\n> "), ""]
                out += [it["content"], ""]
            with open(os.path.join(dig, fn.replace("_跟帖.md", "_跟帖精华.md")),
                      "w", encoding="utf-8") as f:
                f.write("\n".join(out))

        L.append(f"| {idx} | {title[:45]} | {len(items)} | {len(val)} | `replies/{fn}` |")

    L += ["", f"**合计：跟帖 {total_all} 条，精华 {total_val} 条**", "",
          "## 检索建议", "", "```bash",
          "# 全文检索（含寒暄）", 'grep -rn "关键词" references/replies/',
          "# 精华检索（推荐，噪音少）", 'grep -rn "关键词" references/replies_digest/',
          "```"]
    with open(os.path.join(root, _LAYOUT["base"], _LAYOUT["index"]),
              "w", encoding="utf-8") as f:
        f.write("\n".join(L))
    return total_all, total_val, len(files)


# ===== 速查手册 =====

TOPICS = [
    ("低吸买点", r"低吸|深水|水下|回踩|五日线|均线|捡筹码|分批.{0,4}买|急杀", 22),
    ("卖点与离场", r"卖点|离场|清仓|降仓|止损|板砸|落袋|冲高.{0,6}卖|该走|跑路", 22),
    ("仓位管理", r"仓位|\d\.?\d?成|加仓|减仓|满仓|空仓|底仓.{0,6}不动|轻仓", 20),
    ("滚动做T", r"做T|滚动|加T|减T|平T|T出|底仓一股未动|高抛", 18),
    ("节点与选股", r"节点|选股|核心股|辨识度|筛选卡位|龙头.{0,4}确", 20),
    ("洗盘识别", r"洗盘|洗筹|震仓|浮筹|洗一洗|换手.{0,4}充分|控异动", 16),
    ("主升与格局", r"主升|格局|拿住|捂股|持股不动|陪她", 20),
    ("见顶与退潮", r"见顶|断板|大阴|滞涨|出货|退潮|亏钱效应|杀跌期", 20),
    ("竞价与开盘", r"竞价|开盘.{0,6}(买|卖|砸|抢)|一字|高开|低开|弱转强", 18),
    ("心态与纪律", r"管住手|心态|纪律|恐惧|贪婪|踏空|后悔|焦虑|手痒|知行", 20),
    ("量能与情绪", r"量能|放量|缩量|情绪|冰点|高潮|赚钱效应|分歧转一致", 18),
]

GREET = re.compile(r"^(早|好|嗯|哦|谢谢|收到|看到|哈哈|加油|对|是的)[\s！!。.~,，]*$")

# 盘后长篇总结的特征（内容重复，不适合速查）
SUMMARY_MARK = re.compile(r"持仓个股操作|盘后总结|总结贴|周[一二三四五]买入|"
                          r"\d{8}盘后|评论区有黄金")


def score(text, kw_re):
    """信息密度评分：偏好精炼、带具体数据的盘中提示，排除长篇盘后总结"""
    n = len(text)
    if n < 18 or n > 220:
        return -1
    if SUMMARY_MARK.search(text):
        return -1
    if n < 30:
        ln = 0.35
    elif n <= 150:
        ln = 1.0
    else:
        ln = 0.45
    hits = len(re.findall(kw_re, text))
    nums = len(re.findall(r"\d+(?:\.\d+)?%|\d(?:\.\d)?成|"
                          r"(?:五日|5日|十日|10日|二十日|20日)线|"
                          r"第\d+楼|-\d+%", text))
    return hits * 1.0 + ln * 2.0 + min(nums, 4) * 0.7


def build_handbook(root):
    """从精华跟帖按主题提炼实战原话 → 速查手册 md"""
    src = sub("digest", root)
    out = os.path.join(root, _LAYOUT["base"], "跟帖实战速查手册.md")

    all_items = []
    for fn in sorted(os.listdir(src)):
        if not fn.endswith(".md"):
            continue
        _, items = parse_md(os.path.join(src, fn))
        m = re.match(r"(\d{3})_", fn)
        idx = m.group(1) if m else "???"
        for it in items:
            it["src"] = idx
            all_items.append(it)

    seen, uniq = set(), []
    for it in all_items:
        k = re.sub(r"\s+", "", it["content"])[:40]
        if k in seen:
            continue
        seen.add(k)
        uniq.append(it)

    L = ["# 见股起意 · 跟帖实战速查手册", "",
         f"> 从 {len(all_items)} 条精华楼主跟帖中提炼。主贴讲方法论，跟帖记录盘中实战，",
         "> 以下内容均为博主原话，带时间、楼层与出处编号，可直接回溯原帖。", "",
         "**用法**：需要某主题的实战细节时，直接翻对应章节；",
         "需要更多时用出处编号 + 时间到 `references/replies_digest/` 中定位。", "",
         "---", ""]

    total_picked = 0
    for name, kw_re, topn in TOPICS:
        cands = []
        for it in uniq:
            c = it["content"]
            if GREET.match(c.strip()):
                continue
            if not re.search(kw_re, c):
                continue
            cands.append((score(c, kw_re), it))
        cands.sort(key=lambda x: -x[0])

        picked, per_src = [], {}
        for s, it in cands:
            if per_src.get(it["src"], 0) >= 3:
                continue
            picked.append(it)
            per_src[it["src"]] = per_src.get(it["src"], 0) + 1
            if len(picked) >= topn:
                break

        L.append(f"## {name}")
        L.append("")
        for it in picked:
            head = f"**{it['time']}**"
            if it["floor"]:
                head += f" · {it['floor']}"
            head += f"（帖 {it['src']}）"
            L += [head, ""]
            if it["quote"]:
                L += [f"> 回应：{it['quote'].replace(chr(10), ' / ')}", ""]
            L += ["> " + it["content"].replace("\n", "\n> "), ""]
        total_picked += len(picked)

    L += ["---", "",
          f"*共收录 {total_picked} 条实战原话，"
          f"全部出自博主在 {len(all_items)} 条精华跟帖。*"]
    with open(out, "w", encoding="utf-8") as f:
        f.write("\n".join(L))
    return total_picked, len(all_items), out


# ===== 状态文件 =====

def load_json(path, default=None):
    if os.path.exists(path):
        try:
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return default if default is not None else {}
    return default if default is not None else {}


def save_json(path, obj):
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=1)
    os.replace(tmp, path)
