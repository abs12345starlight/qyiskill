# -*- coding: utf-8 -*-
"""
见股起意知识库 · 一键增量更新
========================================
一条命令完成：校验 cookie → 抓最新主帖列表 → 抓新主帖正文 →
增量抓跟帖 → 重建精华/索引/速查手册 → 同步到技能目录 → 重新打包。

用法
----
  python update_kb.py                # 增量更新（默认）
  python update_kb.py --check        # 只体检：cookie 是否有效、有没有新帖/新跟帖
  python update_kb.py --force        # 忽略状态，全量重抓跟帖
  python update_kb.py --posts-only   # 只更新主帖正文
  python update_kb.py --replies-only # 只更新跟帖
  python update_kb.py --workers 8    # 并发数（默认 4）
  python update_kb.py --no-sync      # 不同步到技能目录
  python update_kb.py --cookie-file C:/path/cookie.txt
  python update_kb.py --root D:/my/tgb_kb

增量判定
--------
  主帖：列表页出现了 state 中没有的 slug → 新帖，抓正文 + 抓全部跟帖页
  跟帖：列表页显示的「全站跟帖总数」变化 → 只重抓尾部页（默认最后 2 页
        + 所有新增页），与本地已有条目去重合并
  --force 时忽略上述判定，98 篇全量重扫（约 5700 页 / 35 分钟）

cookie
------
  会过期。过期时把浏览器里复制的新 cookie 存到 <ROOT>/cookie.txt 即可，
  脚本会自动优先读取；也可以 --cookie-file 指定。
"""
import os
import re
import sys
import time
import shutil
import zipfile
import argparse
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import tgb_kb as K


def log(msg):
    print(msg, flush=True)


# ===== 1. 主帖正文 =====

def scrape_post(topic, posts_dir):
    """抓单篇主帖正文 → posts_dir/NNN_标题.md"""
    url = f"{K.BASE}{topic['slug']}"
    h = K.get(url)
    if not h:
        return None
    a = K.extract_article(h)
    if not a.get("body"):
        return None
    title = a.get("title") or topic["title"]
    fn = f"{topic['idx']:03d}_{K.safe_name(title)}.md"
    with open(os.path.join(posts_dir, fn), "w", encoding="utf-8") as f:
        f.write(f"# {title}\n\n")
        f.write(f"- **作者**: {K.AUTHOR_NAME}\n")
        f.write(f"- **日期**: {a.get('date', '未知')}\n")
        f.write(f"- **原文链接**: {url}\n")
        f.write(f"\n---\n\n")
        f.write(a["body"])
        f.write("\n")
    return fn


# ===== 2. 跟帖 =====

_lock = threading.Lock()


def scrape_replies_task(topic, replies_dir, state, tail_pages, force):
    """抓一篇帖子的楼主跟帖（增量或全量），返回 dict"""
    slug = topic["slug"]
    idx = topic["idx"]
    fn = f"{idx:03d}_{K.safe_name(topic['title'])}_跟帖.md"
    path = os.path.join(replies_dir, fn)

    # 已有文件按 state 里的文件名读；文件名可能因标题变化漂移，做一次兜底查找
    old_fn = None
    st = state["topics"].get(slug, {})
    if st.get("file") and os.path.exists(os.path.join(replies_dir, st["file"])):
        old_fn = st["file"]
    else:
        for f in os.listdir(replies_dir):
            if f.startswith(f"{idx:03d}_") and f.endswith("_跟帖.md"):
                old_fn = f
                break

    old_items = []
    if old_fn:
        _, old_items = K.parse_md(os.path.join(replies_dir, old_fn))

    pages = K.count_pages(slug)
    if not pages:
        return {"slug": slug, "ok": False, "note": "页数获取失败"}

    if old_items and not force:
        old_pages = st.get("pages") or pages
        start = min(max(1, old_pages - tail_pages + 1), pages)
    else:
        start = 1

    fresh = K.scrape_page_range(slug, start, pages)

    merged = {K.dedup_key(i): i for i in ([] if force else old_items)}
    added = 0
    for i in fresh:
        k = K.dedup_key(i)
        if k in merged:
            merged[k] = i          # 楼层号可能变，用新的覆盖
        else:
            added += 1
            merged[k] = i
    items = sorted(merged.values(), key=lambda x: x["time"])
    note = ""

    # --force 全量重抓时的保险：若抓到的比原来少 10% 以上，
    # 说明中途请求失败，回滚成「旧 ∪ 新」，避免把历史数据写没
    if force and old_items and len(items) < len(old_items) * 0.9:
        m2 = {K.dedup_key(i): i for i in old_items}
        m2.update({K.dedup_key(i): i for i in fresh})
        items = sorted(m2.values(), key=lambda x: x["time"])
        note = f"抓取不全，已回滚合并（旧 {len(old_items)} ∪ 新 {len(fresh)}）"

    with open(path, "w", encoding="utf-8") as f:
        f.write(K.build_md(idx, topic["title"], slug, items, topic.get("reply_count")))
    # 清理因标题变化产生的旧文件
    if old_fn and old_fn != fn and os.path.exists(os.path.join(replies_dir, old_fn)):
        os.remove(os.path.join(replies_dir, old_fn))

    return {"slug": slug, "ok": True, "count": len(items), "added": added,
            "scanned": pages - start + 1, "file": fn, "note": note, "pages": pages}


# ===== 2.5 状态播种 =====

def seed_state(state, topics, replies_dir):
    """
    kb_state.json 不存在（首次使用本脚本 / 文件被删）时，
    用已有的 *_跟帖.md 反推状态，避免把已抓过的 98 篇当成新帖全量重抓。
    文件头里的「原帖」行记录了 slug，用它做匹配。
    """
    if state["topics"] or not os.path.isdir(replies_dir):
        return 0
    files = [f for f in os.listdir(replies_dir) if f.endswith("_跟帖.md")]
    if not files:
        return 0
    by_slug = {}
    for fn in files:
        with open(os.path.join(replies_dir, fn), "r", encoding="utf-8") as f:
            head = f.read(4000)
        m = re.search(r"原帖：https?://www\.tgb\.cn(/a/[A-Za-z0-9]+)", head)
        if m:
            by_slug[m.group(1)] = fn
    n = 0
    for t in topics:
        fn = by_slug.get(t["slug"])
        if not fn:
            continue
        _, items = K.parse_md(os.path.join(replies_dir, fn))
        m = re.match(r"(\d{3})_", fn)
        t["idx"] = int(m.group(1)) if m else t["idx"]
        state["topics"][t["slug"]] = {
            "idx": t["idx"], "title": t["title"], "slug": t["slug"],
            "reply_count": t["reply_count"], "count": len(items), "file": fn,
        }
        n += 1
    return n


# ===== 3. 同步到技能目录 =====

SYNC_MAP = [
    ("tgb_posts", "references/posts"),
    ("tgb_replies", "references/replies"),
    ("tgb_replies_digest", "references/replies_digest"),
]
SYNC_FILES = [
    ("tgb_replies_index.md", "references/replies_index.md"),
    ("跟帖实战速查手册.md", "references/跟帖实战速查手册.md"),
    ("tgb_all_topics.txt", "references/index_topics.txt"),
]


def sync_to_skill(root, skill_dir):
    if not os.path.isdir(skill_dir):
        log(f"  [跳过] 技能目录不存在：{skill_dir}")
        return False
    for src, dst in SYNC_MAP:
        s = os.path.join(root, src)
        d = os.path.join(skill_dir, dst)
        if not os.path.isdir(s):
            continue
        if os.path.isdir(d):
            shutil.rmtree(d)
        shutil.copytree(s, d)
    for src, dst in SYNC_FILES:
        s = os.path.join(root, src)
        d = os.path.join(skill_dir, dst)
        if os.path.exists(s):
            os.makedirs(os.path.dirname(d), exist_ok=True)
            shutil.copy2(s, d)
    # 脚本保持同源（若本脚本就住在技能目录里，跳过，避免自拷贝报 WinError 32）
    sdir = os.path.join(skill_dir, "scripts")
    here = os.path.dirname(os.path.abspath(__file__))
    if os.path.isdir(sdir) and os.path.abspath(here) != os.path.abspath(sdir):
        for f in os.listdir(here):
            if f.endswith(".py"):
                shutil.copy2(os.path.join(here, f), os.path.join(sdir, f))
    return True


def package(root, skill_dir, out_dir=None):
    if not os.path.isdir(skill_dir):
        return None
    zpath = os.path.join(out_dir or root, "tgb-jian-gu-qi-yi.zip")
    # 打进包里没意义、或含本机信息的条目
    EXCLUDE_DIRS = {"__pycache__", ".git", ".venv"}
    EXCLUDE_FILES = {"_root.txt", "cookie.txt", ".DS_Store"}
    EXCLUDE_EXT = {".pyc", ".zip"}      # 排除 zip，否则会把上一次的包套进新包里
    n = 0
    with zipfile.ZipFile(zpath, "w", zipfile.ZIP_DEFLATED) as z:
        for base, dirs, files in os.walk(skill_dir):
            dirs[:] = [d for d in dirs if d not in EXCLUDE_DIRS]
            for f in files:
                if f in EXCLUDE_FILES or os.path.splitext(f)[1] in EXCLUDE_EXT:
                    continue
                p = os.path.join(base, f)
                z.write(p, os.path.relpath(p, os.path.dirname(skill_dir)))
                n += 1
    return zpath, n


# ===== 主流程 =====

def main():
    ap = argparse.ArgumentParser(description="见股起意知识库一键增量更新")
    ap.add_argument("--root", default=None, help="知识库工作目录")
    ap.add_argument("--cookie-file", default=None, help="cookie 文件路径")
    ap.add_argument("--workers", type=int, default=4, help="并发线程数（默认 4）")
    ap.add_argument("--tail-pages", type=int, default=2,
                    help="已抓过的帖子重抓尾部多少页（默认 2）")
    ap.add_argument("--check", action="store_true", help="只体检，不抓数据")
    ap.add_argument("--force", action="store_true", help="全量重抓跟帖")
    ap.add_argument("--posts-only", action="store_true", help="只更新主帖正文")
    ap.add_argument("--replies-only", action="store_true", help="只更新跟帖")
    ap.add_argument("--no-sync", action="store_true", help="不同步到技能目录")
    ap.add_argument("--no-package", action="store_true", help="不重新打包 zip")
    ap.add_argument("--inplace", action="store_true",
                    help="原地更新：root 就是技能目录本身，数据直接读写 references/，"
                         "跳过同步步骤（移植到新机器后用这个）")
    args = ap.parse_args()

    K.set_layout(args.inplace)
    root = K.get_root(args.root)
    # 原地模式下 root 即技能目录
    skill_dir = root if args.inplace else K.get_skill_dir()
    posts_dir = K.sub("posts", root)
    replies_dir = K.sub("replies", root)
    os.makedirs(posts_dir, exist_ok=True)
    os.makedirs(replies_dir, exist_ok=True)

    cookie, src = K.load_cookie(args.cookie_file, root)
    K.init_cookie(cookie)

    state_path = os.path.join(root, "kb_state.json")
    state = K.load_json(state_path, {"topics": {}, "last_run": None})

    t0 = time.time()
    log("=" * 66)
    log("见股起意知识库 · 增量更新" + ("（原地模式）" if args.inplace else ""))
    log("=" * 66)
    log(f"工作目录 : {root}")
    log(f"技能目录 : {skill_dir}"
        + ("（= 工作目录）" if args.inplace else ""))
    log(f"Cookie   : {src}")
    log("")

    # --- 步骤 1：cookie 体检 ---
    log("[1/7] 校验 cookie ...")
    ok, msg = K.check_cookie()
    log(f"      {msg}")
    if not ok:
        log("")
        log("  × cookie 失效。请把浏览器里复制的新 cookie 保存到：")
        log(f"      {os.path.join(root, 'cookie.txt')}")
        log("    或运行时加 --cookie-file <路径>")
        return 1

    # --- 步骤 2：抓主帖列表 ---
    log("[2/7] 抓取主帖列表 ...")
    topics = K.fetch_topics()
    if not topics:
        log("  × 未取到主帖列表，中止")
        return 1
    K.write_topics_txt(topics, os.path.join(root, K._LAYOUT["base"],
                                            K._LAYOUT["topics"]))
    log(f"      共 {len(topics)} 篇主帖")

    # 沿用已有编号：新帖排在末尾，删除的帖不再出现
    known = state["topics"]
    used = {v["idx"] for v in known.values()}
    next_idx = max(used) + 1 if used else 0
    for t in topics:
        if t["slug"] in known:
            t["idx"] = known[t["slug"]]["idx"]
        else:
            next_idx += 1
            t["idx"] = next_idx

    # 首次运行时用已有文件播种，避免误判为全量新帖
    seeded = seed_state(state, topics, replies_dir)
    if seeded:
        log(f"      已从本地 {seeded} 个跟帖文件恢复状态")

    new_topics = [t for t in topics if t["slug"] not in known]
    changed = [t for t in topics
               if t["slug"] in known
               and known[t["slug"]].get("reply_count") != t["reply_count"]]
    have_idx = {f[:3] for f in os.listdir(replies_dir) if f.endswith("_跟帖.md")}
    missing = [t for t in topics if f"{t['idx']:03d}" not in have_idx]

    log(f"      新帖 {len(new_topics)} 篇 | 跟帖数有变化 {len(changed)} 篇 "
        f"| 本地缺文件 {len(missing)} 篇")

    if args.check:
        log("")
        log("  --check 模式，不抓数据。待更新清单：")
        for t in new_topics:
            log(f"     [新帖] {t['idx']:03d} {t['title'][:40]} "
                f"(跟帖 {t['reply_count']})")
        for t in changed:
            o = known[t["slug"]].get("reply_count", 0)
            log(f"     [跟帖] {t['idx']:03d} {t['title'][:40]} "
                f"{o} → {t['reply_count']}")
        for t in missing:
            log(f"     [缺件] {t['idx']:03d} {t['title'][:40]}")
        if not (new_topics or changed or missing):
            log("     无更新，知识库已是最新")
        return 0

    # --- 步骤 3：新主帖正文 ---
    if not args.replies_only:
        log(f"[3/7] 抓取主帖正文（新帖 {len(new_topics)} 篇）...")
        n_ok = 0
        for t in new_topics:
            fn = scrape_post(t, posts_dir)
            if fn:
                n_ok += 1
                log(f"      ✓ {t['idx']:03d} {t['title'][:40]}")
            else:
                log(f"      × {t['idx']:03d} {t['title'][:40]} 抓取失败")
            time.sleep(0.4)
        log(f"      完成 {n_ok}/{len(new_topics)}")
    else:
        log("[3/7] 跳过（--replies-only）")

    # --- 步骤 4：跟帖增量 ---
    if not args.posts_only:
        if args.force:
            todo = topics
            log(f"[4/7] 全量重抓跟帖（{len(todo)} 篇）...")
        else:
            todo = list({t["slug"]: t for t in (new_topics + changed + missing)}.values())
            log(f"[4/7] 增量抓跟帖（{len(todo)} 篇）...")
        todo.sort(key=lambda t: t["idx"])

        done = 0
        total_added = 0
        with ThreadPoolExecutor(max_workers=args.workers) as ex:
            futs = {ex.submit(scrape_replies_task, t, replies_dir, state,
                              args.tail_pages, args.force): t for t in todo}
            for fu in as_completed(futs):
                t = futs[fu]
                try:
                    r = fu.result()
                except Exception as e:
                    log(f"      × {t['idx']:03d} 异常 {type(e).__name__}: {e}")
                    continue
                if not r["ok"]:
                    log(f"      × {t['idx']:03d} {t['title'][:36]} {r['note']}")
                    continue
                with _lock:
                    state["topics"][r["slug"]] = {
                        "idx": t["idx"], "title": t["title"], "slug": r["slug"],
                        "reply_count": t["reply_count"], "count": r["count"],
                        "pages": r["pages"], "file": r["file"],
                    }
                    K.save_json(state_path, state)
                total_added += r["added"]
                done += 1
                log(f"      ✓ {t['idx']:03d} {r['count']:5d} 条 (+{r['added']:3d} 新增, "
                    f"扫描 {r['scanned']} 页)  {t['title'][:28]}"
                    + (f"  ⚠ {r['note']}" if r["note"] else ""))
        log(f"      完成 {done}/{len(todo)} 篇，新增跟帖 {total_added} 条")
    else:
        log("[4/7] 跳过（--posts-only）")

    # 补全未变动帖子的元信息
    for t in topics:
        slug = t["slug"]
        if slug not in state["topics"]:
            fn = next((f for f in os.listdir(replies_dir)
                       if f.startswith(f"{t['idx']:03d}_") and f.endswith("_跟帖.md")), None)
            state["topics"][slug] = {
                "idx": t["idx"], "title": t["title"], "slug": slug,
                "reply_count": t["reply_count"], "count": None, "file": fn}
        else:
            state["topics"][slug]["reply_count"] = t["reply_count"]
            state["topics"][slug]["idx"] = t["idx"]
            state["topics"][slug]["title"] = t["title"]

    # --- 步骤 5：精华版 + 索引 ---
    log("[5/7] 重建精华版与索引 ...")
    total_all, total_val, nfiles = K.build_digest_index(root)
    log(f"      跟帖 {total_all} 条 → 精华 {total_val} 条（{nfiles} 篇）")

    # --- 步骤 6：速查手册 ---
    log("[6/7] 重建实战速查手册 ...")
    picked, pool, hb = K.build_handbook(root)
    log(f"      {picked} 条实战原话 → {hb}")

    # --- 步骤 7：同步 + 打包 ---
    if args.inplace:
        log("[7/7] 原地模式：数据已在技能目录内，跳过同步")
        if args.no_package:
            log("      跳过打包（--no-package）")
        else:
            r = package(root, skill_dir, out_dir=os.path.dirname(root))
            if r:
                zp, n = r
                log(f"      已打包 → {zp}（{os.path.getsize(zp)/1048576:.1f}MB, {n} 文件）")
    elif args.no_sync:
        log("[7/7] 跳过同步（--no-sync）")
    else:
        log("[7/7] 同步到技能目录并打包 ...")
        if sync_to_skill(root, skill_dir):
            log(f"      已同步 → {skill_dir}")
        if args.no_package:
            log("      跳过打包（--no-package）")
        else:
            r = package(root, skill_dir)
            if r:
                zp, n = r
                log(f"      已打包 → {zp}（{os.path.getsize(zp)/1048576:.1f}MB, {n} 文件）")

    state["last_run"] = time.strftime("%Y-%m-%d %H:%M:%S")
    state["stats"] = {"topics": len(topics), "replies": total_all,
                      "digest": total_val, "handbook": picked}
    K.save_json(state_path, state)

    log("")
    log("=" * 66)
    log(f"全部完成，用时 {(time.time()-t0)/60:.1f} 分钟")
    log(f"主帖 {len(topics)} 篇 | 跟帖 {total_all} 条 | 精华 {total_val} 条 "
        f"| 手册 {picked} 条")
    log("=" * 66)
    return 0


if __name__ == "__main__":
    sys.exit(main())
