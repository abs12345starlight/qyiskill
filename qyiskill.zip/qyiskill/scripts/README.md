# scripts/ 说明

## 一键更新（日常只用它）

```bash
python update_kb.py                # 增量更新：新主帖 + 新跟帖 → 重建索引/手册 → 同步 → 打包
python update_kb.py --check        # 只体检：cookie 是否有效、有几篇待更新，不抓数据
python update_kb.py --force        # 全量重抓（98 篇 ≈ 5,700 页 ≈ 35 分钟）
python update_kb.py --workers 8    # 调并发
python update_kb.py --posts-only / --replies-only
python update_kb.py --no-sync      # 只更新工作目录，不动技能目录
python update_kb.py --root D:/xxx  # 换工作目录
```

完整流程 7 步：校验 cookie → 抓主帖列表 → 抓新主帖正文 → 增量抓跟帖 →
重建精华/索引 → 重建速查手册 → 同步到技能目录并打包。

## 单步工具（诊断 / 单独重跑某一步）

| 脚本 | 作用 |
|---|---|
| `build_replies_index.py` | 只重建精华版 + 总索引 |
| `build_handbook.py` | 只重建《跟帖实战速查手册》 |
| `count_pages.py` | 统计每篇帖子的评论页数，写 `pages_stat.json` |
| `install.py` | 移植安装器（换电脑时用），Windows 入口是 `install.cmd` |
| `tgb_kb.py` | 公共库：请求 / 解析 / 过滤 / 构建，被上面所有脚本 import |

## 两种运行模式

| 模式 | 命令 | 数据位置 | 适用 |
|---|---|---|---|
| 普通 | `python update_kb.py` | 独立工作目录，跑完同步进技能目录（占两份） | 本机开发 |
| 原地 | `python update_kb.py --inplace --root <技能目录>` | 技能目录 `references/` 内（只一份） | 新机器 |

`--inplace` 时 root 就是技能目录本身，跳过同步步骤，zip 打在技能目录的**上一级**。

## 换电脑

见技能目录里的 `PORTING.md`。简版：拷 zip → 解压 → 双击 `install.cmd` → 粘 cookie。

## 环境

需要 `requests`。本机可用解释器：

```
C:/Users/zx744/.workbuddy/binaries/python/envs/default/Scripts/python.exe
```

用系统 python 会报 `ModuleNotFoundError: No module named 'requests'`。

## cookie

会过期。过期后脚本第一步就会报「cookie 失效」。处理方式：
浏览器登录 tgb.cn → F12 → Network → 随便一个请求的 Request Headers →
复制整条 `cookie` → 存到 `<ROOT>/cookie.txt`（一行，不要换行）。

也可 `--cookie-file <路径>` 或设环境变量 `TGB_COOKIE`。

## 路径

```
ROOT      = --root > $TGB_KB_ROOT > <scripts>/_root.txt > C:/Users/zx744/WorkBuddy/2026-07-29-10-57-33
SKILL_DIR = $TGB_SKILL_DIR > ~/.workbuddy/skills/tgb-jian-gu-qi-yi
```

## 关键机制（踩过的坑，改代码前先看）

1. **评论是服务端渲染的**，直接解析 HTML，不需要模拟 AJAX。
   块结构：`<div class="comment-data user_{userID}">`，楼层在 `<span class="left">`，
   时间在 `pcyclspan left c999`，正文在 `comment-data-text`，引用在 `comment-data-quote`。

2. **不要用 `/topic/lookUserTopic`（「只看该作者」）接口**。
   它每页 100 条、本该最省事，但**网页端是积分付费功能**。积分耗尽后返回
   **HTTP 200** 的 `淘股吧_积分不够` 页面——不报错、静默失败，会把抓到的数据写坏。
   官方说 APP 内免费，网页端收费。
   免费替代：`/a/{slug}-{pageNo}?type=Z`，每页固定 **46 条**
   （`pageSize`/`size` 参数无效），本地按 `user_8478060` 过滤。

3. **主帖列表页 `moreTopic?userID=8478060`** 每行能同时拿到
   `data-subject`（标题）、`href="/a/xxx"`（slug）和 `(15520)`（全站跟帖总数）。
   最后一个数字用来做增量判定：数字变了才重抓该帖。
   分页用 GET `pageNo` 无效（返回同一页），所以实现上用
   「新页无新增 slug 即停止」兜底。

4. **`parse_md()` 收集引用前必须先跳过空行**，否则引用文本会被当成正文、
   真正的回复内容被丢弃（曾让精华数从 25k 掉到 5.2k）。

5. **增量策略**：对已抓过的帖子只重抓「最后 2 页 + 所有新增页」，
   再与本地条目按 `(时间, 内容前50字)` 去重合并。全量重扫用 `--force`。
