# -*- coding: utf-8 -*-
"""
见股起意知识库 · 移植安装器
========================================
在新电脑上运行一次，完成：
  1. 把技能目录装到 WorkBuddy 的 skills/ 下
  2. 找到可用的 Python；没有 requests 就建独立 venv 装上
  3. 写入 _root.txt（原地模式，数据直接读写技能目录内的 references/）
  4. 引导填 cookie
  5. 生成「更新.cmd」（Windows 双击即可增量更新）
  6. 跑一次 --check 自检

用法：
  python install.py                       # 装到默认 ~/.workbuddy/skills/tgb-jian-gu-qi-yi
  python install.py --dest D:/skills/tgb  # 装到指定位置
  python install.py --no-venv             # 不建虚拟环境（自己保证有 requests）
  python install.py --skip-check          # 装完不自检
"""
import os
import sys
import shutil
import argparse
import subprocess

HERE = os.path.dirname(os.path.abspath(__file__))
SKILL_SRC = os.path.dirname(HERE)          # install.py 位于 <skill>/scripts/
SKILL_NAME = os.path.basename(SKILL_SRC)


def log(m=""):
    print(m, flush=True)


def default_dest():
    return os.path.join(os.path.expanduser("~"), ".workbuddy", "skills", SKILL_NAME)


def step(n, total, msg):
    log(f"[{n}/{total}] {msg} ...")


# ===== 步骤：找 Python / 装 requests =====

def find_python():
    cands = []
    if sys.executable:
        cands.append(sys.executable)
    for c in ("python3", "python", "py"):
        p = shutil.which(c)
        if p:
            cands.append(p)
    seen, out = set(), []
    for c in cands:
        k = os.path.normcase(os.path.abspath(c))
        if k not in seen:
            seen.add(k)
            out.append(c)
    return out


def has_requests(py):
    try:
        r = subprocess.run([py, "-c", "import requests"],
                           capture_output=True, timeout=60)
        return r.returncode == 0
    except Exception:
        return False


def ensure_env(dest, allow_venv=True):
    """返回 (可用 python 路径, 说明)。找不到返回 (None, 原因)"""
    for py in find_python():
        if has_requests(py):
            return py, f"复用已有解释器（已装 requests）"
    if not allow_venv:
        return None, "现有 Python 都没装 requests，且指定了 --no-venv"
    base = next(iter(find_python()), None)
    if not base:
        return None, "系统里没找到 Python"
    venv = os.path.join(dest, ".venv")
    log(f"      建虚拟环境：{venv}")
    r = subprocess.run([base, "-m", "venv", venv], capture_output=True)
    if r.returncode != 0:
        return None, f"venv 创建失败：{r.stderr.decode('utf-8', 'ignore')[:200]}"
    exe = os.path.join(venv, "Scripts" if os.name == "nt" else "bin",
                       "python.exe" if os.name == "nt" else "python")
    if not os.path.exists(exe):
        return None, f"venv 里找不到解释器：{exe}"
    log("      安装 requests ...")
    r = subprocess.run([exe, "-m", "pip", "install", "-q", "--disable-pip-version-check",
                        "requests"], capture_output=True)
    if r.returncode != 0:
        return None, f"pip install requests 失败：" \
                     f"{r.stderr.decode('utf-8', 'ignore')[:200]}"
    if not has_requests(exe):
        return None, "requests 装完仍无法 import"
    return exe, f"已新建 venv 并装入 requests"


# ===== 步骤：写更新启动器 =====

CMD = """@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo ============================================================
echo   见股起意知识库 - 增量更新（原地模式）
echo ============================================================
echo.
"{py}" "%~dp0scripts\\update_kb.py" --inplace --root "%~dp0." %*
echo.
pause
"""

SH = """#!/usr/bin/env bash
cd "$(dirname "$0")"
"{py}" "$(dirname "$0")/scripts/update_kb.py" --inplace --root "$(dirname "$0")" "$@"
"""


def write_launcher(dest, py):
    p = os.path.join(dest, "更新.cmd" if os.name == "nt" else "更新.sh")
    tpl = CMD if os.name == "nt" else SH
    with open(p, "w", encoding="utf-8" if os.name == "nt" else "utf-8") as f:
        f.write(tpl.format(py=py))
    if os.name != "nt":
        os.chmod(p, 0o755)
    return p


# ===== 步骤：cookie =====

def setup_cookie(dest):
    p = os.path.join(dest, "cookie.txt")
    if os.path.exists(p) and os.path.getsize(p) > 50:
        return p, "已存在，沿用"
    log("")
    log("  需要 cookie 才能抓取更新（只有纯检索、不更新数据的话可以跳过）。")
    log("  获取方式：浏览器登录 tgb.cn → F12 → Network → 任选一个请求 →")
    log("           Request Headers 里复制整条 cookie 的值。")
    try:
        s = input("  请粘贴 cookie（直接回车跳过）> ").strip()
    except (EOFError, KeyboardInterrupt):
        s = ""
    if not s:
        log("  已跳过。之后手动把 cookie 存到：")
        log(f"      {p}")
        return None, "未配置（不影响检索，影响更新）"
    with open(p, "w", encoding="utf-8") as f:
        f.write(s)
    return p, "已写入"


def main():
    ap = argparse.ArgumentParser(description="见股起意知识库 · 移植安装器")
    ap.add_argument("--dest", default=None, help="安装目标目录")
    ap.add_argument("--no-venv", action="store_true", help="不自动建虚拟环境")
    ap.add_argument("--skip-check", action="store_true", help="装完不跑自检")
    ap.add_argument("--skip-cookie", action="store_true", help="不交互式问 cookie")
    args = ap.parse_args()

    dest = os.path.abspath(args.dest or default_dest())
    src = SKILL_SRC
    TOTAL = 6

    log("=" * 66)
    log("见股起意知识库 · 移植安装")
    log("=" * 66)
    log(f"源目录 : {src}")
    log(f"目标   : {dest}")
    log("")

    # 1 复制
    step(1, TOTAL, "安装技能目录")
    if os.path.abspath(src) == os.path.abspath(dest):
        log("      源=目标，跳过复制")
    elif os.path.commonpath([os.path.abspath(src)]) == \
            os.path.commonpath([os.path.abspath(src), os.path.abspath(dest)]):
        log("  × 目标目录位于源目录内部，会递归复制。请换一个 --dest。")
        log(f"      源: {src}")
        log(f"      目标: {dest}")
        return 1
    else:
        if os.path.isdir(dest):
            log(f"      目标已存在，覆盖合并 → {dest}")
        os.makedirs(os.path.dirname(dest), exist_ok=True)
        shutil.copytree(src, dest, dirs_exist_ok=True)
        log(f"      ✓ 已安装到 {dest}")

    # 2 校验结构
    step(2, TOTAL, "校验目录结构")
    must = [os.path.join(dest, "SKILL.md"),
            os.path.join(dest, "references", "posts"),
            os.path.join(dest, "references", "replies"),
            os.path.join(dest, "scripts", "update_kb.py")]
    missing = [m for m in must if not os.path.exists(m)]
    if missing:
        log("  × 结构不完整，缺少：")
        for m in missing:
            log(f"      {m}")
        return 1
    log(f"      ✓ SKILL.md / references/ / scripts/ 齐全")

    # 3 环境
    step(3, TOTAL, "准备 Python 环境")
    py, why = ensure_env(dest, allow_venv=not args.no_venv)
    if not py:
        log(f"      ! {why}")
        log("      ! 不影响「读」知识库（检索不需要 Python），但无法增量更新。")
        log("      ! 手动装 requests 后重试： pip install requests")
        py = None
    else:
        log(f"      ✓ {py}")
        log(f"        {why}")

    # 4 _root.txt（原地模式）
    step(4, TOTAL, "写入路径配置（原地模式）")
    with open(os.path.join(dest, "scripts", "_root.txt"), "w", encoding="utf-8") as f:
        f.write(dest)
    log(f"      ✓ scripts/_root.txt = {dest}")

    # 5 cookie
    step(5, TOTAL, "配置 cookie")
    if args.skip_cookie:
        log("      已跳过（--skip-cookie）")
    else:
        p, why2 = setup_cookie(dest)
        log(f"      {'✓' if p else '!'} {why2}")

    # 6 启动器 + 自检
    step(6, TOTAL, "生成更新启动器")
    if py:
        lp = write_launcher(dest, py)
        log(f"      ✓ {lp}")

        if not args.skip_check:
            log("")
            log("  自检中（--check）...")
            r = subprocess.run([py, os.path.join(dest, "scripts", "update_kb.py"),
                                "--inplace", "--root", dest, "--check"])
            if r.returncode != 0:
                log("  ! 自检未通过，多半是 cookie 未配置或已过期（见上方提示）")
    else:
        log("      ! 跳过（没有可用 Python）")

    log("")
    log("=" * 66)
    log("安装完成")
    log("=" * 66)
    log(f"技能位置 : {dest}")
    log("")
    log("以后要更新数据：")
    if os.name == "nt":
        log(f"  双击  {os.path.join(dest, '更新.cmd')}")
    log(f"  或命令  python scripts{os.sep}update_kb.py --inplace --root \"{dest}\"")
    log("")
    log("把它变成 WorkBuddy 技能：确认上面的路径在 WorkBuddy 的 skills/ 下即可，")
    log("重启 WorkBuddy 后就能在对话里直接检索这个知识库。")
    return 0


if __name__ == "__main__":
    sys.exit(main())
