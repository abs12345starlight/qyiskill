# -*- coding: utf-8 -*-
"""
重建「精华版 + 总索引」（单独跑时用这个；日常请用 update_kb.py 一键更新）

  python build_replies_index.py [--root DIR]

输入：<root>/tgb_replies/*.md
输出：<root>/tgb_replies_digest/*.md  +  <root>/tgb_replies_index.md
"""
import os
import sys
import argparse

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import tgb_kb as K


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=None)
    args = ap.parse_args()
    root = K.get_root(args.root)
    total_all, total_val, nfiles = K.build_digest_index(root)
    print(f"处理 {nfiles} 个跟帖文件")
    print(f"跟帖总数 {total_all}，精华 {total_val} 条")
    print(f"索引已生成: {os.path.join(root, 'tgb_replies_index.md')}")


if __name__ == "__main__":
    main()
