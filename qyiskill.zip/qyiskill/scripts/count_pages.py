# -*- coding: utf-8 -*-
"""
统计每篇主帖的评论总页数（诊断用；日常请用 update_kb.py 一键更新）

  python count_pages.py [--root DIR]

输出：<root>/pages_stat.json
"""
import os
import sys
import json
import time
import argparse

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import tgb_kb as K


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=None)
    args = ap.parse_args()
    root = K.get_root(args.root)

    topics = K.fetch_topics()
    res = {}
    for t in topics:
        pages = K.count_pages(t["slug"])
        res[f"{t['idx']:03d}"] = {"slug": t["slug"], "title": t["title"],
                                  "pages": pages if pages else -1,
                                  "reply_count": t["reply_count"]}
        print(f"{t['idx']:03d} {pages if pages else 'ERR':>5} 页  {t['title'][:40]}",
              flush=True)
        time.sleep(0.3)

    with open(os.path.join(root, "pages_stat.json"), "w", encoding="utf-8") as f:
        json.dump(res, f, ensure_ascii=False, indent=1)

    tot = sum(v["pages"] for v in res.values() if v["pages"] > 0)
    print(f"\n共 {len(res)} 篇，总页数: {tot}")


if __name__ == "__main__":
    main()
