# -*- coding: utf-8 -*-
"""
重建《跟帖实战速查手册》（单独跑时用这个；日常请用 update_kb.py 一键更新）

  python build_handbook.py [--root DIR]

输入：<root>/tgb_replies_digest/*.md
输出：<root>/跟帖实战速查手册.md
"""
import os
import sys
import argparse

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import tgb_kb as K


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=None)
    args = ap.parse_args()
    root = K.get_root(args.root)
    picked, pool, out = K.build_handbook(root)
    print(f"候选精华跟帖 {pool} 条 → 收录 {picked} 条")
    print(f"手册已生成：{out}")


if __name__ == "__main__":
    main()
