# -*- coding: utf-8 -*-
"""个股/题材时间线查询器 —— 把某只票（或某个词）的全部跟帖按时间拉出来。

用法（在技能目录下，用能 import requests 的那个 python）：

    python 工具/检索个股.py 红宝丽                 # 搜精华版，直接打印
    python 工具/检索个股.py 红宝丽 --qa            # 搜对话版（能看到网友提问）
    python 工具/检索个股.py 红宝丽 --full          # 搜全量版（更慢更全）
    python 工具/检索个股.py 红宝丽 --out hbl.txt   # 存成文件慢慢看
    python 工具/检索个股.py 红宝丽 --brief         # 只看每月条数分布

输出格式（每条）：

    [2025-05-07 14:24] 第2500楼 (帖021)
    红宝丽，今天是真正的渡劫之战，你们懂了吗？

原理：精华/全量目录里每个 md 对应一篇主帖，结构是
`## YYYY-MM-DD` 分日、`**HH:MM** · 第N楼` 分条，
本脚本按这两个标记切块，命中关键词的块按 (日期, 时间, 楼层) 排序。

注意：`(帖021)` 是主帖编号，回原文时到 `资料/03_跟帖精华/021_*.md` 里
搜楼层号即可定位上下文。
"""
import os
import re
import sys
import glob
import argparse

HERE = os.path.dirname(os.path.abspath(__file__))
SKILL = os.path.dirname(HERE)

DAY = re.compile(r"^## (\d{4}-\d{2}-\d{2})\s*$")
ENT = re.compile(r"^\*\*(\d{2}:\d{2})\*\* · 第(\d+)楼\s*$")


def collect(key, src):
    """扫描 src 目录下所有 md，返回 [(日期, 时间, 楼层, 帖号, 正文)]，按时间排序。"""
    items = []
    for fp in sorted(glob.glob(os.path.join(src, "*.md"))):
        topic = os.path.basename(fp)[:3]
        day = ""
        cur = None
        buf = []
        with open(fp, encoding="utf-8") as f:
            for line in f:
                m = DAY.match(line)
                if m:
                    if cur and key in "".join(buf):
                        items.append(cur + ("".join(buf).strip(),))
                    cur, buf = None, []
                    day = m.group(1)
                    continue
                m = ENT.match(line)
                if m:
                    if cur and key in "".join(buf):
                        items.append(cur + ("".join(buf).strip(),))
                    cur = (day, m.group(1), int(m.group(2)), topic)
                    buf = []
                    continue
                if cur is not None:
                    buf.append(line)
        if cur and key in "".join(buf):
            items.append(cur + ("".join(buf).strip(),))
    items.sort(key=lambda x: (x[0], x[1], x[2]))
    return items


def render(items, key):
    out = ["关键词：%s   命中 %d 条" % (key, len(items)), "=" * 70, ""]
    for day, tm, floor, topic, body in items:
        out.append("[%s %s] 第%d楼 (帖%s)" % (day, tm, floor, topic))
        out.append(body)
        out.append("-" * 70)
    return "\n".join(out)


def brief(items, key):
    stat = {}
    for day, tm, floor, topic, body in items:
        stat[day[:7]] = stat.get(day[:7], 0) + 1
    out = ["关键词：%s   命中 %d 条   覆盖 %d 个月" % (key, len(items), len(stat)), ""]
    for ym in sorted(stat):
        out.append("  %s  %s %d" % (ym, "#" * min(stat[ym], 50), stat[ym]))
    return "\n".join(out)


def main():
    ap = argparse.ArgumentParser(description="按关键词抽取跟帖时间线")
    ap.add_argument("keyword", help="个股名或题材词，如 红宝丽 / 商业航天")
    ap.add_argument("--full", action="store_true", help="搜全量版（默认搜精华版）")
    ap.add_argument("--qa", action="store_true",
                    help="搜对话版（楼主+网友提问），优先级高于 --full")
    ap.add_argument("--brief", action="store_true", help="只打印每月条数分布")
    ap.add_argument("--out", help="输出到文件而不是屏幕")
    a = ap.parse_args()

    sub = ("04_跟帖对话版" if a.qa else
           "02_跟帖全量" if a.full else "03_跟帖精华")
    src = os.path.join(SKILL, "资料", sub)
    if not os.path.isdir(src):
        sys.exit("找不到数据目录：%s" % src)

    items = collect(a.keyword, src)
    if not items:
        sys.exit("「%s」在%s里一条都没命中，换个词或加 --full 试试。" % (a.keyword, sub))

    text = brief(items, a.keyword) if a.brief else render(items, a.keyword)
    if a.out:
        with open(a.out, "w", encoding="utf-8") as f:
            f.write(text + "\n")
        print("已写入 %s（%d 条）" % (a.out, len(items)))
    else:
        print(text)


if __name__ == "__main__":
    main()
