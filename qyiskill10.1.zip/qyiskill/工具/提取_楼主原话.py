# -*- coding: utf-8 -*-
"""精确提取「楼主本人的发言正文」——剥掉引用网友的部分。

跟帖文件的结构：
    **21:43** · 第14957楼      ← 楼主所在楼层
    (空行)
    > 网友昵称                  ← 楼主引用的网友原话（可多段）
    > 2026-09-11 22:41
    (空行)
    楼主真正说的话……            ← 要的就是这段

所以：定位 `**HH:MM** · 第N楼`，跳过其后的 `>` 引用块，取第一段正文。
"""
import os
import re
import sys
from collections import Counter

S = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DIG = os.path.join(S, "资料", "03_跟帖精华")

CUT = sys.argv[1] if len(sys.argv) > 1 else "2026-08-01"
KWS = sys.argv[2].split(",") if len(sys.argv) > 2 else None

# 楼层头：**HH:MM** · 第N楼
HEAD = re.compile(r"\*\*(\d{2}:\d{2})\*\* · (?:第)?(\d+)楼")

def iter_posts(text):
    """产出 (时间, 楼层, 楼主正文)"""
    heads = list(HEAD.finditer(text))
    for i, h in enumerate(heads):
        start = h.end()
        end = heads[i + 1].start() if i + 1 < len(heads) else len(text)
        chunk = text[start:end]
        lines = [ln for ln in chunk.split("\n")]
        body = []
        for ln in lines:
            st = ln.strip()
            if not st:
                continue
            if st.startswith(">"):
                continue          # 引用网友的
            if st.startswith("##"):
                break
            body.append(st)
        yield h.group(1), h.group(2), " ".join(body)

# 日期切分
def iter_days(fn):
    body = open(fn, encoding="utf-8").read()
    parts = re.split(r"^## (\d{4}-\d{2}-\d{2})$", body, flags=re.M)
    for i in range(1, len(parts) - 1, 2):
        yield parts[i], parts[i + 1]

needle = KWS[0] if KWS else None
found = []
theme_counter = Counter()

THEMES = ["商业航天", "机器人", "固态电池", "芯片", "半导体", "存储", "算力", "AI硬件",
          "光模块", "CPO", "PCB", "六氟", "量子", "核聚变", "深海", "低空", "稳定币",
          "创新药", "军工", "金融", "券商", "稀土", "液冷", "玻璃基板", "MLCC", "光纤",
          "数据中心", "国产替代", "核电", "粮食", "医药", "消费", "航天", "大科技"]

for fn in sorted(os.listdir(DIG)):
    if not fn.endswith(".md"):
        continue
    idx = fn[:3]
    for day, block in iter_days(os.path.join(DIG, fn)):
        if day < CUT:
            continue
        for t, floor, txt in iter_posts(block):
            if len(txt) < 10:
                continue
            for w in THEMES:
                if w in txt:
                    theme_counter[w] += 1
            if needle and needle in txt:
                found.append((day, t, idx, floor, txt))

if needle:
    print(f"=== 楼主发言中含「{needle}」的（{CUT} 后）共 {len(found)} 条 ===")
    for day, t, idx, floor, txt in found:
        print(f"\n[{day} {t} 帖{idx} 第{floor}楼]\n{txt[:500]}")
else:
    print(f"=== 题材命中（{CUT} 后，楼主本人正文）===")
    for k, c in theme_counter.most_common(40):
        print(f"{c:3d}  {k}")
