# -*- coding: utf-8 -*-
"""一键增量更新的启动器（自动判断用哪份数据）

用户双击「更新知识库.cmd」/ 在 DS 里跑本脚本 → 本文件判断出正确的
root 与 --inplace 参数，再执行 抓取更新.py。

为什么不写在批处理里：bat 的引号嵌套 + 延迟展开太容易写错，
判断逻辑放 Python 里可靠得多（2026-09-27 踩过）。

★ 核心原则：**按「本文件住在哪」决定用哪份数据**，而不是按「哪个目录有数据」。
  因为这台电脑上 WorkBuddy 和 DS 两套并存，只看数据会把两边搅在一起。

    ~/.dsh/skills/qyiskill/工具/   → 用 DS 那份（原地）
    ~/.workbuddy/skills/.../工具/           → 用车间（WorkBuddy 常态）
    车间/工具/                              → 用车间（历史布局）

注：车间里没有 工具/ 目录（脚本只装在技能目录），所以判断车间时
    脚本一律取技能目录里的那份。
"""
import os
import sys
import subprocess

HOME = os.path.expanduser("~")
HERE = os.path.dirname(os.path.abspath(__file__))      # .../工具
SELF_ROOT = os.path.dirname(HERE)                      # 技能目录 or 车间

SKILL = os.path.join(HOME, ".workbuddy", "skills", "qyiskill")
DSDIR = os.path.join(HOME, ".dsh", "skills", "qyiskill")
WORK = os.path.join(HOME, "WorkBuddy", "2026-07-29-10-57-33")

PY = os.path.join(HOME, ".workbuddy", "binaries", "python",
                  "envs", "default", "Scripts", "python.exe")
if not os.path.exists(PY):
    PY = sys.executable or "python"

REL = os.path.join("工具", "抓取更新", "抓取更新.py")


def norm(p):
    return os.path.normcase(os.path.abspath(p))


def has_creds(d):
    """该目录有没有「独立更新」需要的凭证与状态"""
    return (os.path.exists(os.path.join(d, "增量状态.json"))
            and os.path.exists(os.path.join(d, "cookie.txt")))


def ok_inplace(d):
    return has_creds(d) and os.path.exists(os.path.join(d, REL))


script = args = None

# ① DS 技能目录 → 用 DS
if norm(SELF_ROOT) == norm(DSDIR):
    if ok_inplace(DSDIR):
        script = os.path.join(DSDIR, REL)
        args = ["--inplace", "--root", DSDIR]
        print(f"  [模式] 原地 · DS  {DSDIR}")
    else:
        script = os.path.join(DSDIR, REL)     # 让下游报出具体缺失
        args = ["--inplace", "--root", DSDIR]
        print(f"  [提示] {DSDIR} 缺状态文件或 cookie，可能首次运行")

# ② 未知位置但自带数据 → 原地
elif norm(SELF_ROOT) not in (norm(SKILL), norm(WORK)) and ok_inplace(SELF_ROOT):
    script = os.path.join(SELF_ROOT, REL)
    args = ["--inplace", "--root", SELF_ROOT]
    print(f"  [模式] 原地  {SELF_ROOT}")

# ③ 车间可用 → 车间（脚本取技能目录那份）
elif has_creds(WORK) and os.path.exists(os.path.join(SKILL, REL)):
    script = os.path.join(SKILL, REL)
    args = ["--root", WORK]
    print(f"  [模式] 车间  {WORK}")

# ④ 技能目录自带完整数据 → 原地
elif ok_inplace(SKILL):
    script = os.path.join(SKILL, REL)
    args = ["--inplace", "--root", SKILL]
    print(f"  [模式] 原地 · 技能目录  {SKILL}")

else:
    print("[错误] 找不到可用的知识库数据。检查过：")
    for label, d in (("车间", WORK), ("WorkBuddy 技能", SKILL), ("DS 技能", DSDIR)):
        print(f"    [{label}] {d}")
        print(f"         状态文件 {'有' if os.path.exists(os.path.join(d,'增量状态.json')) else '无'}"
              f" / cookie {'有' if os.path.exists(os.path.join(d,'cookie.txt')) else '无'}"
              f" / 脚本 {'有' if os.path.exists(os.path.join(d,REL)) else '无'}")
    sys.exit(1)

print()
r = subprocess.run([PY, script] + args + sys.argv[1:])
print()
if r.returncode >= 2:
    print("[!] 更新失败，原因见上。")
    print("    cookie 失效或撞实名墙时，双击「更新cookie.cmd」换新 cookie。")
    print("    本地数据完好，检索不受影响。")
sys.exit(r.returncode)
