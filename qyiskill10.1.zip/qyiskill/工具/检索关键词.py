# -*- coding: utf-8 -*-
"""关键词原话查询器 —— 按任意关键词/正则抓出带完整出处的原话片段。

和 检索个股.py 的区别：
    检索个股.py     → 按「个股名」查，输出整条跟帖，适合看某只票的来龙去脉
    检索关键词.py   → 按「任意词/正则」查，输出命中处前后各一段上下文，
                      适合查方法论概念（抽血、持续性、节点、渡劫、鱼尾……）

三层数据用 --qa / --full 切换：
    默认        精华版 资料/03_跟帖精华（最快，已滤寒暄）
    --qa        对话版 资料/04_跟帖对话版（**能同时看到网友提问**，理解回答的首选）
    --full      全量版 资料/02_跟帖全量（最全，但只有楼主发言）

用法（在技能目录下）：

    python 工具/检索关键词.py 抽血                 # 精华版，默认前后 90/150 字
    python 工具/检索关键词.py 抽血 --qa            # 对话版（能同时看到网友提问）
    python 工具/检索关键词.py 持续性 --full        # 全量版（更慢更全）
    python 工具/检索关键词.py "节点|首板"          # 支持正则，多个词用 | 连
    python 工具/检索关键词.py 抽血 --ctx 200       # 上下文窗口放大到 200 字
    python 工具/检索关键词.py 抽血 --limit 15      # 只显示最新 15 条
    python 工具/检索关键词.py 抽血 --out x.txt     # 存文件
    python 工具/检索关键词.py 抽血 --asc           # 按时间正序（看演变过程）

输出格式（每条）：

    [2025-12-11 14:05 · 帖004 · 第10672楼]
      ...大消费，我说过了，不会去碰，没什么持续性...

原理：跟帖 md 的结构是 `## YYYY-MM-DD` 分日 + `**HH:MM** · 第N楼` 分条。
本脚本先扫描全文件建立 (偏移 → 日期) 和 (偏移 → 时间/楼层) 两张索引表，
再对关键词的每个匹配位置二分定位它属于哪一天哪一条，最后取前后窗口。

为什么要这个脚本：直接 grep 出来的是裸行，没有日期和楼层，
回原文核对时找不到位置；而且 git bash 里 `cut -c` 会按字节切中文导致乱码，
必须用 python 读。
"""
import os
import re
import sys
import glob
import argparse

HERE = os.path.dirname(os.path.abspath(__file__))
SKILL = os.path.dirname(HERE)

DAY = re.compile(r"^## (\d{4}-\d{2}-\d{2})\s*$", re.M)
ENT = re.compile(r"^\*\*(\d{2}:\d{2})\*\*\s*·\s*第(\d+)楼", re.M)


def locate(pos, marks):
    """在 [(偏移, 值)] 里找最后一个 <= pos 的项。marks 必须按偏移升序。"""
    lo, hi, best = 0, len(marks) - 1, ""
    while lo <= hi:
        mid = (lo + hi) // 2
        if marks[mid][0] <= pos:
            best = marks[mid][1]
            lo = mid + 1
        else:
            hi = mid - 1
    return best


def collect(kw, src, before=90, after=150):
    hits = []
    pat = re.compile(kw)
    for fp in sorted(glob.glob(os.path.join(src, "*.md"))):
        topic = os.path.basename(fp)[:3]
        with open(fp, encoding="utf-8") as f:
            txt = f.read()
        daymarks = [(m.start(), m.group(1)) for m in DAY.finditer(txt)]
        entmarks = []
        for m in ENT.finditer(txt):
            entmarks.append((m.start(), (m.group(1), m.group(2))))
        for m in pat.finditer(txt):
            s = max(0, m.start() - before)
            e = min(len(txt), m.end() + after)
            seg = re.sub(r"\s+", " ", txt[s:e]).strip()
            tm, floor = locate(m.start(), entmarks) or ("", "")
            hits.append((locate(m.start(), daymarks), tm, floor, topic, seg))
    return hits


def main():
    ap = argparse.ArgumentParser(
        description="按关键词抓原话片段（带日期/楼层/帖号）")
    ap.add_argument("keyword", help="关键词，支持正则，多词用 | 连接")
    ap.add_argument("--full", action="store_true",
                    help="搜全量版（默认搜精华版）")
    ap.add_argument("--qa", action="store_true",
                    help="搜对话版（楼主+网友提问，带问答上下文），优先级高于 --full")
    ap.add_argument("--ctx", type=int, default=150,
                    help="命中后向后的字数，默认 150")
    ap.add_argument("--before", type=int, default=90,
                    help="命中向前取的字数，默认 90")
    ap.add_argument("--limit", type=int, default=0, help="只显示 N 条")
    ap.add_argument("--asc", action="store_true", help="按时间正序")
    ap.add_argument("--out", help="输出到文件而不是打印")
    ap.add_argument("--root", help="工作目录（默认脚本所在技能目录）")
    args = ap.parse_args()

    root = args.root or SKILL
    # 三层：精华（默认）/ 全量 / 对话版
    key = ("04_跟帖对话版" if args.qa
           else "02_跟帖全量" if args.full
           else "03_跟帖精华")
    # 技能目录是 <root>/资料/<层>，工作目录是 <root>/<层>
    cands = [os.path.join(root, "资料", key), os.path.join(root, key)]
    src = next((c for c in cands if os.path.isdir(c)), None)
    if not src:
        sys.exit(f"找不到目录：{cands[0]}\n"
                 f"提示：对话版需要先跑 工具/重建_对话版.py 生成")

    hits = collect(args.keyword, src, args.before, args.ctx)
    hits.sort(key=lambda x: (x[0], x[1]), reverse=not args.asc)
    if args.limit:
        hits = hits[:args.limit]

    lines = [f"关键词「{args.keyword}」在 {os.path.basename(src)} 命中 "
             f"{len(hits)} 处：", ""]
    for d, tm, floor, topic, seg in hits:
        head = f"[{d or '????-??-??'} {tm or '??:??'} · 帖{topic}"
        if floor:
            head += f" · 第{floor}楼"
        lines.append(head + "]")
        lines.append("  ..." + seg + "...")
        lines.append("")

    out = "\n".join(lines)
    if args.out:
        with open(args.out, "w", encoding="utf-8") as f:
            f.write(out)
        print(f"已写入 {args.out}（{len(hits)} 条）")
    else:
        print(out)


if __name__ == "__main__":
    main()
