# -*- coding: utf-8 -*-
"""
重建《跟帖实战速查手册》（单独跑时用这个；日常请用 工具/抓取更新/抓取更新.py 一键更新）

  python 工具/重建_速查手册.py [--root DIR]

输入：<root>/03_跟帖精华/*.md      （技能目录下为 <root>/资料/03_跟帖精华/*.md）
输出：<root>/跟帖实战速查手册.md
"""
import os
import sys
import argparse

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import 公共库 as K


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=None)
    args = ap.parse_args()
    root = K.get_root(args.root)
    picked, pool, out = K.build_handbook(root)
    print(f"候选精华跟帖 {pool} 条 → 收录 {picked} 条")
    print(f"手册已生成：{out}")


if __name__ == "__main__":
    main()
