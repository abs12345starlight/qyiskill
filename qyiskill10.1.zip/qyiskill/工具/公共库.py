# -*- coding: utf-8 -*-
"""
见股起意知识库 · 公共库
========================================
所有抓取/解析脚本共用的底层能力：
  - 配置解析（工作目录 / 技能目录 / cookie）
  - HTTP 会话（线程安全 + 重试）
  - 主帖列表抓取（带跟帖总数）
  - 评论页解析（楼主跟帖 / 全部跟帖）
  - 主帖正文解析
  - Markdown 读写与解析（跟帖 md ↔ 结构化条目）
  - 精华过滤规则

路径优先级（全部可移植，不含任何写死的绝对路径）：
  SKILL_DIR : 环境变量 TGB_SKILL_DIR > 本文件上两级目录（即技能目录本身）
              > ~/.workbuddy/skills/qyiskill（兜底）
  ROOT      : --root 参数 > 环境变量 TGB_KB_ROOT > <本目录>/路径配置.txt
              > 若 技能目录/资料/ 存在则用技能目录（原地模式）> 默认工作区
  COOKIE    : --cookie-file 参数 > 环境变量 TGB_COOKIE > <ROOT>/cookie.txt
              > <本目录>/cookie.txt > 脚本内置 FALLBACK_COOKIE（会过期）

「本文件上两级目录」= 工具/公共库.py → 工具/ → 技能目录，所以整个技能目录
拷到任何地方都能自动定位数据，不需要改任何配置。
"""
import os
import re
import sys
import json
import time
import threading
import html as htmlmod

import requests

BASE = "https://www.tgb.cn"
AUTHOR_ID = "8478060"
AUTHOR_NAME = "见股起意"

# 最后兜底的工作目录。正常路径下**不会用到**——get_root() 会先尝试
# 环境变量、路径配置.txt、技能目录的 资料/ 子目录。仅当以上全不成立时
# 才回落到这里，所以换成别的机器/别的用户名时通常无需修改。
DEFAULT_ROOT = ""   # 留空：get_root() 会自动从本文件位置反推

# 内置备用 cookie（会过期）。推荐把新 cookie 写进 <ROOT>/cookie.txt。
FALLBACK_COOKIE = ""   # 公开版已移除内置凭证

HEADERS = {
    "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "accept-language": "zh-CN,zh;q=0.9",
    "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                  "(KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36",
}

# 付费墙标记：网页端「只看该作者」积分耗尽时返回 HTTP 200 的提示页
POVERTY_MARK = "积分不够"

# 实名认证墙：未完成实名认证的账号访问帖子详情页时，会被 302 重定向到
# https://www.tgb.cn/user/generalUserCertPage
# ⚠ 因为 requests 默认跟随重定向，最终会拿到一个 HTTP 200 的认证页——
# 调用方若不识别，就会把「抓不到内容」误判成「没有新内容」。
# （2026-09-15 踩过：抓取更新连续报「无更新」，实际是一篇都抓不到）
CERT_MARK = "generalUserCertPage"
_cert_warned = False


def _warn_cert():
    """首次遇到实名认证墙时打一次提示（不重复刷屏）"""
    global _cert_warned
    if _cert_warned:
        return
    _cert_warned = True
    msg = (
        "\n" + "!" * 62 + "\n"
        "[!] 淘股吧要求实名认证：帖子详情页被重定向到 generalUserCertPage\n"
        "[!] 这意味着「抓不到任何帖子内容」，不是「没有新内容」。\n"
        "[!] 本地已有数据完好，查询不受影响，但无法继续增量更新。\n"
        "[!] 解决：用该账号在网页版完成实名认证（含人脸核身）后重试。\n"
        + "!" * 62)
    print(msg, flush=True)

# ===== 配置 =====

def _self_skill_dir():
    """从本文件位置反推技能目录：工具/公共库.py → 工具/ → 技能目录

    抓取更新/ 下的脚本也 import 本模块，所以这里用 __file__ 而不是 cwd，
    无论从哪里调用、目录搬到哪，都能正确定位。
    """
    here = os.path.dirname(os.path.abspath(__file__))
    cand = os.path.dirname(here)                      # 工具/ 的上一级
    # 真技能目录应含 SKILL.md 或 资料/；否则退回 here（防止被放到奇怪层级）
    if (os.path.exists(os.path.join(cand, "SKILL.md"))
            or os.path.isdir(os.path.join(cand, "资料"))):
        return cand
    return here


def get_root(root=None):
    if root:
        return os.path.abspath(root)
    env = os.environ.get("TGB_KB_ROOT")
    if env:
        return os.path.abspath(env)
    here = os.path.dirname(os.path.abspath(__file__))
    p = os.path.join(here, "路径配置.txt")
    if os.path.exists(p):
        with open(p, "r", encoding="utf-8") as f:
            v = f.read().strip()
        # 校验路径是否真的存在，否则视为无效（换机器后旧路径会失效）
        if v and os.path.isdir(v):
            return os.path.abspath(v)
    # 技能目录里若有 资料/ 说明是原地模式 → 直接用它当 root
    sd = _self_skill_dir()
    if os.path.isdir(os.path.join(sd, "资料")):
        return sd
    return DEFAULT_ROOT or _self_skill_dir()


def get_skill_dir():
    env = os.environ.get("TGB_SKILL_DIR")
    if env:
        return os.path.abspath(env)
    return _self_skill_dir()


# 目录布局。两种模式：
#   普通模式 —— 数据在独立工作目录，跑完再同步进技能目录（本机开发用）
#   inplace  —— 数据就住在技能目录 资料/ 下，原地更新（移植到新机器用）
#
# ⚠ 字典的 key（posts/replies/digest/qa）是代码内部用的短名，拼路径时用
#   sub("posts", root)，**不要**改成中文；只有 value 是真实目录名。
_NORMAL = {"base": "", "posts": "01_主贴正文", "replies": "02_跟帖全量",
           "digest": "03_跟帖精华", "qa": "04_跟帖对话版",
           "index": "跟帖索引.md", "topics": "主贴清单.txt"}
_INPLACE = {"base": "资料", "posts": "01_主贴正文", "replies": "02_跟帖全量",
            "digest": "03_跟帖精华", "qa": "04_跟帖对话版",
            "index": "跟帖索引.md", "topics": "主贴清单.txt"}

_LAYOUT = dict(_NORMAL)


def set_layout(inplace=False):
    """切换目录布局：False=工作目录（车间），True=技能目录原地模式（成品）"""
    global _LAYOUT
    _LAYOUT = dict(_INPLACE if inplace else _NORMAL)


def sub(key, root):
    """按当前布局取子目录路径"""
    return os.path.join(root, _LAYOUT["base"], _LAYOUT[key])


def load_cookie(path=None, root=None):
    """按优先级加载 cookie 字符串，返回 (cookie_str, 来源说明)"""
    cands = []
    if path:
        cands.append((path, "--cookie-file"))
    env = os.environ.get("TGB_COOKIE")
    if env:
        cands.append((None, "环境变量 TGB_COOKIE"))
    root = root or get_root()
    cands.append((os.path.join(root, "cookie.txt"), "<ROOT>/cookie.txt"))
    cands.append((os.path.join(os.path.dirname(os.path.abspath(__file__)),
                               "cookie.txt"), "<工具>/cookie.txt"))
    for p, label in cands:
        if p is None:
            return env.strip(), label
        if os.path.exists(p):
            with open(p, "r", encoding="utf-8") as f:
                s = f.read().strip()
            if s:
                return s, f"{label} ({p})"
    return FALLBACK_COOKIE, "脚本内置 FALLBACK_COOKIE（大概率已过期）"


# ===== HTTP =====

_local = threading.local()
_COOKIE_CACHE = {"value": None}


def init_cookie(cookie_str):
    _COOKIE_CACHE["value"] = cookie_str


def _cookie():
    if _COOKIE_CACHE["value"] is None:
        _COOKIE_CACHE["value"], _ = load_cookie()
    return _COOKIE_CACHE["value"]


def session():
    s = getattr(_local, "s", None)
    if s is None:
        s = requests.Session()
        s.headers.update(HEADERS)
        s.headers["referer"] = f"{BASE}/blog/{AUTHOR_ID}"
        s.cookies.update(
            dict(kv.strip().split("=", 1) for kv in _cookie().split(";") if "=" in kv)
        )
        _local.s = s
    return s


def get(url, retries=3, timeout=30):
    for i in range(retries):
        try:
            r = session().get(url, timeout=timeout)
            # 实名认证墙 → 当次请求视为失败，并给出明确提示
            if CERT_MARK in str(r.url):
                _warn_cert()
                return None
            if r.status_code == 200:
                r.encoding = "utf-8"
                return r.text
            if r.status_code in (403, 429, 503):
                time.sleep(5 * (i + 1))
                continue
        except Exception:
            pass
        time.sleep(2 * (i + 1))
    return None


def check_cookie():
    """校验 cookie 是否还有效。返回 (ok: bool, 说明: str)"""
    h = get(f"{BASE}/user/blog/moreTopic?userID={AUTHOR_ID}")
    if not h:
        return False, "请求失败（网络不通 / 被拦截）"
    slugs = re.findall(r'href="(/a/[A-Za-z0-9]+)"', h)
    if not slugs:
        t = re.search(r"<title>(.*?)</title>", h, re.S)
        title = htmlmod.unescape(t.group(1)).strip() if t else "无标题"
        return False, f"未取到主帖列表（页面标题：{title}），cookie 多半已失效"
    return True, f"正常，读到 {len(slugs)} 条主帖链接"


# ===== 文本清洗 =====

def clean_text(s):
    s = re.sub(r"<br\s*/?>", "\n", s, flags=re.I)
    s = re.sub(r"</p>", "\n", s, flags=re.I)
    s = re.sub(r"<[^>]+>", "", s)
    s = htmlmod.unescape(s)
    s = re.sub(r"[ \t\u00a0]+", " ", s)
    return "\n".join(ln.strip() for ln in s.split("\n") if ln.strip()).strip()


def safe_name(s):
    return re.sub(r'[\\/:*?"<>|]', "_", s)[:80].strip()


# ===== 主帖列表 =====

def fetch_topics(max_pages=30, sleep=0.3):
    """
    抓取博主全部主帖。返回 [{idx, title, slug, reply_count}, ...]
    列表页按时间倒序，因此 idx 从 1 开始即为「最新」。
    分页用「新页无新增 slug 即停止」的方式兜底（详见 README）。
    """
    out, seen = [], set()
    for p in range(1, max_pages + 1):
        url = f"{BASE}/user/blog/moreTopic?userID={AUTHOR_ID}"
        if p > 1:
            url += f"&pageNo={p}"
        h = get(url)
        if not h:
            break
        rows = re.findall(
            r'data-subject="([^"]*)"\s*/>.*?href="(/a/[A-Za-z0-9]+)"[^>]*>.*?\((\d+)\)',
            h, re.S)
        added = 0
        for subj, slug, cnt in rows:
            if slug in seen:
                continue
            seen.add(slug)
            added += 1
            out.append({
                "title": htmlmod.unescape(subj).strip(),
                "slug": slug,
                "reply_count": int(cnt),
            })
        if added == 0:
            break
        time.sleep(sleep)
    for i, t in enumerate(out, 1):
        t["idx"] = i
    return out


def write_topics_txt(topics, path):
    L = [f"{AUTHOR_NAME} (userID={AUTHOR_ID}) 全部主贴列表",
         f"总计: {len(topics)} 篇",
         "=" * 80, ""]
    for t in topics:
        L.append(f"  {t['idx']}. {t['title']}")
        L.append(f"     {BASE}{t['slug']}")
        L.append("")
    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(L))


# ===== 评论解析 =====

def parse_replies(page_html, only_author=True):
    """解析评论页 HTML，返回 [{time, floor, quote, content}, ...]"""
    out = []
    blocks = re.split(r'(?=<div class="comment-data user_\d+")', page_html)
    for b in blocks[1:]:
        uid = re.search(r'class="comment-data user_(\d+)"', b)
        if not uid:
            continue
        if only_author and uid.group(1) != AUTHOR_ID:
            continue
        tm = re.search(r'<span class="pcyclspan left c999"[^>]*>([\d\-: ]+)</span>', b)
        floor = re.search(r'<span class="left">\s*(第?\d+楼|沙发|板凳|地板)[^<]*', b)
        nm = re.search(r'class="user-name[^"]*"[^>]*>\s*([^<]+?)\s*</a>', b)
        txt = re.search(r'<div class="comment-data-text" id="reply\d+">(.*?)</div>', b, re.S)
        quote = re.search(r'<div class="comment-data-quote"[^>]*>(.*?)</div>', b, re.S)
        if not txt:
            continue
        content = clean_text(txt.group(1))
        if not content:
            continue
        out.append({
            "uid": uid.group(1),
            "name": nm.group(1).strip() if nm else "",
            "time": tm.group(1).strip() if tm else "",
            "floor": floor.group(1).strip() if floor else "",
            "quote": clean_text(quote.group(1)) if quote else "",
            "content": content,
        })
    return out


def count_pages(slug):
    """统计某篇帖子的评论总页数；失败返回 None"""
    h = get(f"{BASE}{slug}-1?type=Z")
    if not h:
        return None
    m = re.search(r"共<b[^>]*>\s*(\d+)\s*</b>/(\d+)页", h)
    return int(m.group(2)) if m else 1


def scrape_page_range(slug, start, end, include_all=False):
    """抓取 slug 的第 start~end 页跟帖（含端点）

    include_all=False（默认）→ 只留楼主的，和以前一样
    include_all=True         → 所有人的都留（含 uid / name 字段），
                               用来生成「对话版」（见 build_qa_md）
    """
    got = []
    for p in range(start, end + 1):
        h = get(f"{BASE}{slug}-{p}?type=Z")
        if not h:
            continue
        if POVERTY_MARK in h[:2000]:
            raise RuntimeError("触发积分付费墙，请停止使用 lookUserTopic 类接口")
        got.extend(parse_replies(h, only_author=not include_all))
    return got


def dedup_key(item):
    return (item["time"], item["content"][:50])


# ===== 对话版（楼主 + 网友）=====
#
# 背景：默认只抓楼主（only_author=True），粉丝的提问只有被楼主引用时才以
# `> 名字 / > 时间` 的形式残留。但很多回答脱离提问就读不懂，所以再加一层
# 「对话版」：把有实质内容的网友发言也收录进来，按楼层排成问-答流。
#
# 难点是噪声：全站跟帖里 80% 是「师父早 / 666 / 感恩 / 打卡」这类，
# 直接全收会让有效信息被淹没。下面这套规则用于把这类滤掉。

# 客套 / 灌水词
SMALLTALK = re.compile(
    r"师父|师傅|老师|意师|意中人|老大|前辈|"
    r"早安|午安|晚安|早上好|中午好|晚上好|辛苦了|辛苦|"
    r"谢谢|多谢|感谢|感恩|多谢分享|学到了|学到了很多|"
    r"打卡|报到|来支持|来支持了|顶一下|顶起|沙发|板凳|地板|"
    r"功德无量|无量|威武|牛逼|牛批|厉害|膜拜|受教|佩服|"
    r"加油|祝\w*(顺|好|安)|节日快乐|周末愉快|早休息|注意保暖"
)
# 纯符号 / 表情 / 短回应
JUNK_ONLY = re.compile(
    r"^[\W\d_]{0,12}$|"
    r"^(6+|8+|9+|0+|1+|哈{2,}|啊+|哦+|嗯+|好+|赞+|顶+|收到|明白|懂了|"
    r"是的|对|对对|不错|很好|支持|来了|在|有|好嘞|ok|OK|okk)[\W\d_]*$",
    re.I,
)
# 疑问词：说明这是在提问
QWORD = re.compile(
    r"怎么|如何|为什么|为何|请问|想问|请教|求教|是不是|是否能|能不能|"
    r"可以吗|对吗|会吗|该不该|要不要|有没有|啥|什么|哪个|多少|吗|呢|吧"
)
# 有实质内容的标志：交易/市场相关词
SUBSTANCE = re.compile(
    r"涨|跌|板|仓|低吸|买入|卖出|持有|止损|止盈|竞价|开盘|收盘|尾盘|"
    r"题材|板块|龙头|核心股|节点|主升|洗盘|分歧|一致|量能|情绪|承接|"
    r"今天|明天|昨天|周一|周二|周三|周四|周五|下周|这周|本周|"
    r"资金|主力|机构|散户|套利|兑现|涨停|跌停|封板|炸板|回封|"
    r"\d+(?:板|成|%|个点|天)|老师[你您]|师傅[你您]|师父[你您]"
)
# 提到具体票/板块（常见 A 股后缀，或明确的板块名）
STOCKISH = re.compile(
    r"[\u4e00-\u9fa5]{2,4}(?:股份|科技|信息|智能|新材|材料|动力|电子|"
    r"生物|医药|能源|化学|集团|建设|医疗|光电|通信|软件|网络|数据|"
    r"环保|电力|重工|机电|控股|半导体|存储|光伏|锂电|储能|算力|机器人)|"
    r"商业航天|创新药|机器人|大金融|固态电池|军工|稀土|化工|消费|农业|种业"
)


def floor_num(f):
    """「沙发/板凳/地板/第N楼」→ 数字，用于按楼层排序"""
    if not f:
        return 0
    m = re.search(r"(\d+)", f)
    if m:
        return int(m.group(1))
    return {"沙发": 1, "板凳": 2, "地板": 3}.get(f, 0)


def split_qa(items):
    """把混合发言分成 (楼主发言, 网友发言) 两个列表"""
    author, others = [], []
    for r in items:
        if r.get("uid") == AUTHOR_ID or r.get("name") == AUTHOR_NAME:
            author.append(r)
        else:
            others.append(r)
    return author, others


def parse_quote_ref(quote):
    """'昵称\\n2026-09-08 14:21' → ('昵称', '2026-09-08 14:21')

    注意 quote 里只有被引用人的昵称和时间，**没有正文**——
    所以要还原提问原文，必须去抓网友自己的发言，这也是做对话版的原因。
    """
    lines = [l.strip() for l in (quote or "").split("\n") if l.strip()]
    if len(lines) >= 2:
        return lines[0], lines[1][:16]
    return (lines[0] if lines else "", "")


def collect_author_refs(author_items):
    """收集楼主所有引用过的 (昵称, 时间)——这些提问必须无条件保留"""
    refs = set()
    for r in author_items:
        if r.get("quote"):
            n, t = parse_quote_ref(r["quote"])
            if n and t:
                refs.add((n, t))
    return refs


def keep_reply(text, quoted_by_author=False):
    """判断一条网友发言值不值得进对话版

    反向定义「值得留」比正向定义「该删」更稳，因为网友发言的噪声花样太多
    （问候、打卡、附和、打油诗、表情……），删不完。
    """
    if quoted_by_author:
        return True                     # 楼主回复过的提问，无条件留
    t = re.sub(r"\s+", "", text or "")
    if not t:
        return False
    # ⚠ 提问判断必须放在「长度」和「客套」两道门槛之前！
    # 踩过的坑（都是实测出来的）：
    #   「师是不是空仓？」  → 抠掉问候词「师」后只剩 6 字，被客套规则误杀
    #   「怎么低吸核心股」  → 7 字，被 len<10 误杀
    # 这两类恰恰是最该留的，所以短提问要单独放行。
    if "?" in t or "？" in t:
        return True
    # 至少 5 字：「今天能买吗」刚好 5 字，而「好吧」「嗯呢」这类纯附和都在 4 字以内
    if len(t) >= 5 and QWORD.search(t):
        return True
    # 含交易词就留，哪怕只有 4 个字（「能加仓吗」）。
    # ⚠ 必须放在 len<10 那关之前，否则短提问会被长度门槛误杀。
    if len(t) >= 4 and SUBSTANCE.search(t):
        return True
    if len(t) < 10:
        return False
    if JUNK_ONLY.match(t):
        return False
    # 通篇客套：把问候语抠掉后几乎不剩东西。
    # 拦的是「师父早上好，祝您节日快乐，注意身体」这种又长又没信息量的。
    if len(SMALLTALK.sub("", t)) < 8:
        return False
    if len(t) >= 18 and STOCKISH.search(t):
        return True                     # 提到了具体票/板块
    return False


def build_qa_md(idx, title, slug, items, reply_count=None):
    """生成对话版 md：楼主 + 网友，按 (日期, 楼层) 排序，标注发言人

    格式：
        **14:21** · 第14703楼 · 网友「躺平平耶」
        提问内容……

        **14:48** · 第14704楼 · ★见股起意
        > 躺平平耶
        > 2026-09-08 14:21
        回答内容……
    """
    author, others = split_qa(items)
    refs = collect_author_refs(author)
    keep = []
    for r in others:
        key = (r.get("name") or "", (r["time"] or "")[:16])
        if keep_reply(r["content"], quoted_by_author=(key in refs)):
            r["_answered"] = key in refs
            keep.append(r)
    allit = author + keep
    allit.sort(key=lambda r: (r["time"][:10], floor_num(r["floor"]),
                              0 if (r.get("uid") == AUTHOR_ID
                                    or r.get("name") == AUTHOR_NAME) else 1))

    n_ans = sum(1 for r in keep if r.get("_answered"))
    url = f"{BASE}{slug}"
    L = [f"# {title} · 跟帖对话版", "",
         f"- 序号：{idx:03d}",
         f"- 原帖：{url}",
         f"- 本版含：★见股起意 {len(author)} 条 + 网友 {len(keep)} 条"
         f"（其中 {n_ans} 条是楼主亲自回复过的提问）",
         f"- 网友发言已过滤「问候/打卡/灌水」类，只留提问与实质讨论",
         f"- 标注：★＝见股起意本人；「」内＝网友昵称；"
         f"带「楼主回复了这条」的＝紧接着就有答案",
         "", "---", ""]
    cur = None
    for r in allit:
        d = r["time"][:10]
        if d != cur:
            cur = d
            L.append(f"## {d}")
            L.append("")
        mine = (r.get("uid") == AUTHOR_ID or r.get("name") == AUTHOR_NAME)
        head = f"**{r['time'][11:] or r['time']}**"
        if r["floor"]:
            head += f" · {r['floor']}"
        if mine:
            head += " · ★" + (r.get("name") or AUTHOR_NAME)
        else:
            head += " · 网友「" + (r.get("name") or "?") + "」"
            if r.get("_answered"):
                head += "（楼主回复了这条）"
        L.append(head)
        L.append("")
        if r["quote"]:
            L.append("> " + r["quote"].replace("\n", "\n> "))
            L.append("")
        L.append(r["content"])
        L.append("")
    return "\n".join(L), len(author), len(keep)


# ===== Markdown 读写 =====

def build_md(idx, title, slug, items, reply_count=None):
    url = f"{BASE}{slug}"
    L = [f"# {title}", "",
         f"- 序号：{idx:03d}",
         f"- 作者：{AUTHOR_NAME}",
         f"- 原帖：{url}",
         f"- 楼主跟帖：{len(items)} 条"]
    if reply_count is not None:
        L.append(f"- 全站跟帖总数：{reply_count}")
    L += ["", "---", ""]
    cur = None
    for r in items:
        d = r["time"][:10]
        if d != cur:
            cur = d
            L.append(f"## {d}")
            L.append("")
        head = f"**{r['time'][11:] or r['time']}**"
        if r["floor"]:
            head += f" · {r['floor']}"
        L.append(head)
        L.append("")
        if r["quote"]:
            L.append("> " + r["quote"].replace("\n", "\n> "))
            L.append("")
        L.append(r["content"])
        L.append("")
    return "\n".join(L)


def parse_md(path):
    """
    解析跟帖 md，返回 (header_str, items)
    items: [{time, floor, quote, content}]
    注意：收集引用前必须先跳过空行，否则引用会被误当正文（曾踩过的坑）。
    """
    with open(path, "r", encoding="utf-8") as f:
        lines = f.read().split("\n")
    header, items = [], []
    i = 0
    cur_date = ""
    while i < len(lines):
        ln = lines[i]
        if ln.startswith("## ") and re.match(r"^\d{4}-\d{2}-\d{2}$", ln[3:].strip()):
            cur_date = ln[3:].strip()
        m = re.match(r"^\*\*(\d{2}:\d{2}|\d{4}-\d{2}-\d{2} \d{2}:\d{2})\*\*"
                     r"(?:\s*·\s*(.+?))?\s*$", ln)
        if m:
            tm = m.group(1)
            floor = m.group(2) or ""
            full_time = tm if len(tm) > 5 else f"{cur_date} {tm}"
            i += 1
            while i < len(lines) and lines[i].strip() == "":
                i += 1
            quote = []
            while i < len(lines) and lines[i].startswith("> "):
                quote.append(lines[i][2:])
                i += 1
            while i < len(lines) and lines[i].strip() == "":
                i += 1
            body = []
            while (i < len(lines) and lines[i].strip() != ""
                   and not lines[i].startswith("**")
                   and not lines[i].startswith("## ")):
                body.append(lines[i])
                i += 1
            items.append({"time": full_time, "floor": floor,
                          "quote": "\n".join(quote).strip(),
                          "content": "\n".join(body).strip()})
            continue
        header.append(ln)
        i += 1
    return "\n".join(header).strip(), items


# ===== 主帖正文 =====

def extract_article(html):
    """提取主帖标题 / 日期 / 正文"""
    res = {}
    m = re.search(r"<title>(.*?)</title>", html, re.S)
    if m:
        t = htmlmod.unescape(m.group(1).strip())
        t = re.sub(r"\s*[-_]\s*见股起意.*$", "", t)
        t = re.sub(r"\s*_\s*淘股吧.*$", "", t)
        res["title"] = t.strip()
    m = re.search(r"(\d{4}-\d{1,2}-\d{1,2}\s+\d{1,2}:\d{2})", html)
    if m:
        res["date"] = m.group(1)
    body = _slice_div(html, r'<div[^>]*class="[^"]*article-text p_coten[^"]*"[^>]*>')
    if not body:
        body = _slice_div(html, r'<div[^>]*class="[^"]*article-content[^"]*"[^>]*>')
    if body:
        body = re.sub(r"<br\s*/?>", "\n", body, flags=re.I)
        body = re.sub(r"</p>", "\n\n", body, flags=re.I)
        body = re.sub(r"</div>", "\n", body, flags=re.I)
        body = re.sub(r"</h\d>", "\n\n", body, flags=re.I)
        body = re.sub(r"<[^>]+>", "", body)
        body = htmlmod.unescape(body)
        lines = []
        for ln in body.split("\n"):
            s = ln.strip()
            if s:
                lines.append(s)
            elif lines and lines[-1] != "":
                lines.append("")
        res["body"] = "\n".join(lines)
    return res


def _slice_div(html, pattern):
    m = re.search(pattern, html)
    if not m:
        return None
    start, depth, pos = m.end(), 1, m.end()
    while depth > 0 and pos < len(html):
        op = re.search(r"<div[^>]*>", html[pos:])
        cl = re.search(r"</div>", html[pos:])
        if not cl:
            break
        if op and op.start() < cl.start():
            depth += 1
            pos += op.end()
        else:
            depth -= 1
            if depth == 0:
                return html[start:pos]
            pos += cl.end()
    return None


# ===== 精华过滤 =====

KEYWORDS = [
    "低吸", "降仓", "加仓", "清仓", "减仓", "空仓", "满仓", "仓位", "格局", "主升",
    "分歧", "一致", "节点", "核心", "龙头", "补涨", "卡位", "竞价", "封板", "炸板",
    "回封", "量能", "放量", "缩量", "均线", "五日线", "5日线", "支撑", "压力",
    "天谴", "渡劫", "离场", "进场", "出手", "风险", "机会", "修复", "反包", "断板",
    "切换", "T出", "T出底仓", "滚动", "做T", "题材", "板块", "情绪", "高潮", "退潮",
    "冰点", "回暖", "涨停", "跌停", "深水", "水下", "红盘", "冲高", "杀跌", "砸",
    "预期", "观察", "关注", "等待", "管住手", "止损", "止盈", "落袋", "持有", "拿着",
    "和而泰", "华胜", "利欧", "红宝丽", "国芳", "银之杰", "克来", "中毅达", "拓维",
]

GREETINGS = re.compile(
    r"^(早呀|早上好|早|晚上好|晚安|好|好的|嗯|嗯嗯|哦|啊|哈哈|哈哈哈|谢谢|多谢|"
    r"收到了|看到了|知道|知道了|明白|收到|是的|对|对对|不错|加油|辛苦|辛苦了|"
    r"支持|顶|赞|666|好的呢|好嘞|好哒|好de|ok|OK|Ok|嗯呢|嘻嘻|呵呵|哈哈哈哈|"
    r"师父早|师父好|老师早|老师好|大家早|各位早|早啊|早安|晚好|吃了吗|在吗|"
    r"谢谢师父|感谢|感谢师父|抱拳|玫瑰花|鲜花|爱心|强|赞赞赞|牛|牛逼|厉害)[\s！!。.~,，]*$"
)


def is_valuable(content):
    c = content.strip()
    if not c:
        return False
    if GREETINGS.match(c):
        return False
    if any(k in c for k in KEYWORDS):
        return True
    return len(c) >= 20


# ===== 精华版 + 索引 =====

def build_digest_index(root):
    """
    扫描 <root>/02_跟帖全量/*.md →
      生成 <root>/03_跟帖精华/*.md（精华版）
      生成 <root>/跟帖索引.md（总索引）
    返回 (总跟帖数, 精华数, 文件数)
    """
    src = sub("replies", root)
    dig = sub("digest", root)
    os.makedirs(dig, exist_ok=True)
    files = sorted(f for f in os.listdir(src) if f.endswith(".md"))

    total_all = total_val = 0
    L = ["# 见股起意 · 跟帖（评论区）总索引", "",
         f"> 博主在 {len(files)} 篇主帖下的全部跟帖。跟帖中包含大量盘中实时提示、",
         "> 个股点评与答疑，是主帖之外最重要的实战内容。", "",
         "| # | 主帖 | 跟帖总数 | 精华数 | 文件 |",
         "|---|------|---------|--------|------|"]

    for fn in files:
        path = os.path.join(src, fn)
        header, items = parse_md(path)
        total_all += len(items)
        val = [it for it in items if is_valuable(it["content"])]
        total_val += len(val)

        m = re.search(r"^# (.+)$", header, re.M)
        title = m.group(1).strip() if m else fn
        idx = fn[:3]

        if val:
            out = [f"# {title} · 跟帖精华", "",
                   f"- 原帖文件：`{fn}`",
                   f"- 跟帖总数：{len(items)}，精华：{len(val)}", "", "---", ""]
            cur = None
            for it in val:
                d = it["time"][:10]
                if d != cur:
                    cur = d
                    out += [f"## {d}", ""]
                head = f"**{it['time'][11:] or it['time']}**"
                if it["floor"]:
                    head += f" · {it['floor']}"
                out += [head, ""]
                if it["quote"]:
                    out += ["> " + it["quote"].replace("\n", "\n> "), ""]
                out += [it["content"], ""]
            with open(os.path.join(dig, fn.replace("_跟帖.md", "_跟帖精华.md")),
                      "w", encoding="utf-8") as f:
                f.write("\n".join(out))

        L.append(f"| {idx} | {title[:45]} | {len(items)} | {len(val)} | `02_跟帖全量/{fn}` |")

    L += ["", f"**合计：跟帖 {total_all} 条，精华 {total_val} 条**", "",
          "## 检索建议", "", "```bash",
          "# 全文检索（含寒暄）", 'grep -rn "关键词" 资料/02_跟帖全量/',
          "# 精华检索（推荐，噪音少）", 'grep -rn "关键词" 资料/03_跟帖精华/',
          "```"]
    with open(os.path.join(root, _LAYOUT["base"], _LAYOUT["index"]),
              "w", encoding="utf-8") as f:
        f.write("\n".join(L))
    return total_all, total_val, len(files)


# ===== 速查手册 =====

TOPICS = [
    ("低吸买点", r"低吸|深水|水下|回踩|五日线|均线|捡筹码|分批.{0,4}买|急杀", 30),
    ("卖点与离场", r"卖点|离场|清仓|降仓|止损|板砸|落袋|冲高.{0,6}卖|该走|跑路", 30),
    ("仓位管理", r"仓位|\d\.?\d?成|加仓|减仓|满仓|空仓|底仓.{0,6}不动|轻仓", 26),
    ("滚动做T", r"做T|滚动|加T|减T|平T|T出|底仓一股未动|高抛", 24),
    ("节点与选股", r"节点|选股|核心股|辨识度|筛选卡位|龙头.{0,4}确", 26),
    ("洗盘识别", r"洗盘|洗筹|震仓|浮筹|洗一洗|换手.{0,4}充分|控异动", 20),
    ("主升与格局", r"主升|格局|拿住|捂股|持股不动|陪她", 26),
    ("见顶与退潮", r"见顶|断板|大阴|滞涨|出货|退潮|亏钱效应|杀跌期", 26),
    ("竞价与开盘", r"竞价|开盘.{0,6}(买|卖|砸|抢)|一字|高开|低开|弱转强", 24),
    ("心态与纪律", r"管住手|心态|纪律|恐惧|贪婪|踏空|后悔|焦虑|手痒|知行", 26),
    ("量能与情绪", r"量能|放量|缩量|情绪|冰点|高潮|赚钱效应|分歧转一致", 24),
    ("题材判断", r"题材|板块|主线|支线|轮动|发酵|持续性|想象力|空间", 24),
    ("答疑与纠错",
     r"你.{0,4}(错|不对|理解错|想多|想偏)|不是.{0,6}而是|误区|搞反|"
     r"错在|问题在|你以为|恰恰相反|建议.{0,4}(你|先)|应该先", 24),
    ("新手常见坑",
     r"新手|刚入市|小白|很多人.{0,6}(亏|错|追|怕)|容易犯|通病|"
     r"大部分人|散户.{0,4}(通病|习惯)|频繁|管不住", 22),
    ("模式与体系",
     r"模式|体系|要信早信|聚焦核心|意中人|祖训|交易系统|我的做法|"
     r"原则|框架|纪律.{0,4}(第|一|二|三)", 22),
]

GREET = re.compile(r"^(早|好|嗯|哦|谢谢|收到|看到|哈哈|加油|对|是的)[\s！!。.~,，]*$")

# 盘后长篇总结的特征（内容重复，不适合速查）
SUMMARY_MARK = re.compile(r"持仓个股操作|盘后总结|总结贴|周[一二三四五]买入|"
                          r"\d{8}盘后|评论区有黄金")

# 社交闲聊特征。只有「命中闲聊词 且 完全没有交易词」时才判为噪音，
# 避免误杀「直播里讲了低吸」这类同时含两类词的内容。
NOISE_MARK = re.compile(r"喝醉|喝酒|骂你|女粉|私信|加群|星球|打赏|"
                        r"几点开播|开播时间|点赞|关注我|开户|考证|天气|吃饭")
CORE_TRADING = re.compile(
    r"低吸|涨停|跌停|拉板|回封|炸板|仓位|底仓|降仓|加仓|清仓|买点|卖点|"
    r"五日线|均线|竞价|主升|洗盘|节点|龙头|核心|做T|滚动|格局|量能|情绪|"
    r"分歧|一致|离场|止损|止盈|题材|板块|分时|封板|断板|渡劫|异动|控异动")


def score(text, kw_re, time_str=""):
    """
    信息密度评分：偏好精炼、带具体数据的盘中提示，排除长篇盘后总结。
    近期内容略加权——越靠近当下，对当前市场的参考价值越高。
    """
    n = len(text)
    if n < 18 or n > 220:
        return -1
    if SUMMARY_MARK.search(text):
        return -1
    if NOISE_MARK.search(text) and not CORE_TRADING.search(text):
        return -1
    if n < 30:
        ln = 0.35
    elif n <= 150:
        ln = 1.0
    else:
        ln = 0.45
    hits = len(re.findall(kw_re, text))
    nums = len(re.findall(r"\d+(?:\.\d+)?%|\d(?:\.\d)?成|"
                          r"(?:五日|5日|十日|10日|二十日|20日)线|"
                          r"第\d+楼|-\d+%", text))
    rec = 0.0
    ym = time_str[:7]
    if ym >= "2026-01":
        rec = 0.6
    elif ym >= "2025-07":
        rec = 0.35
    elif ym >= "2025-01":
        rec = 0.15
    return hits * 1.0 + ln * 2.0 + min(nums, 4) * 0.7 + rec


def _shingles(s, k=4):
    s = re.sub(r"\s+", "", s)
    return {s[i:i + k] for i in range(max(0, len(s) - k + 1))}


def _too_similar(text, picked, thresh=0.5):
    """与已选条目做 4-gram Jaccard，过滤语义近似重复"""
    a = _shingles(text)
    if not a:
        return False
    for p in picked:
        b = _shingles(p)
        if not b:
            continue
        j = len(a & b) / len(a | b)
        if j >= thresh:
            return True
    return False


def build_handbook(root):
    """从精华跟帖按主题提炼实战原话 → 速查手册 md"""
    src = sub("digest", root)
    out = os.path.join(root, _LAYOUT["base"], "跟帖实战速查手册.md")

    all_items = []
    for fn in sorted(os.listdir(src)):
        if not fn.endswith(".md"):
            continue
        _, items = parse_md(os.path.join(src, fn))
        m = re.match(r"(\d{3})_", fn)
        idx = m.group(1) if m else "???"
        for it in items:
            it["src"] = idx
            all_items.append(it)

    seen, uniq = set(), []
    for it in all_items:
        k = re.sub(r"\s+", "", it["content"])[:40]
        if k in seen:
            continue
        seen.add(k)
        uniq.append(it)

    L = ["# 见股起意 · 跟帖实战速查手册", "",
         f"> 从 {len(all_items)} 条精华楼主跟帖中提炼。主贴讲方法论，跟帖记录盘中实战，",
         "> 以下内容均为博主原话，带时间、楼层与出处编号，可直接回溯原帖。", "",
         "**用法**：需要某主题的实战细节时，直接翻对应章节；",
         "需要更多时用出处编号 + 时间到 `资料/03_跟帖精华/` 中定位。", "",
         f"章节：{' / '.join(t[0] for t in TOPICS)}", "",
         "---", "",
         "## 目录", ""]
    for i, (name, _, _) in enumerate(TOPICS, 1):
        L.append(f"{i}. {name}")
    L += ["", "---", ""]

    total_picked = 0
    for name, kw_re, topn in TOPICS:
        cands = []
        for it in uniq:
            c = it["content"]
            if GREET.match(c.strip()):
                continue
            if not re.search(kw_re, c):
                continue
            s = score(c, kw_re, it.get("time", ""))
            if s > 0:
                cands.append((s, it))
        cands.sort(key=lambda x: (-x[0], x[1]["time"]))

        picked, per_src, texts = [], {}, []
        for s, it in cands:
            if per_src.get(it["src"], 0) >= 3:
                continue
            if _too_similar(it["content"], texts):
                continue
            picked.append(it)
            texts.append(it["content"])
            per_src[it["src"]] = per_src.get(it["src"], 0) + 1
            if len(picked) >= topn:
                break

        L.append(f"## {name}")
        L.append("")
        for it in picked:
            head = f"**{it['time']}**"
            if it["floor"]:
                head += f" · {it['floor']}"
            head += f"（帖 {it['src']}）"
            L += [head, ""]
            if it["quote"]:
                L += [f"> 回应：{it['quote'].replace(chr(10), ' / ')}", ""]
            L += ["> " + it["content"].replace("\n", "\n> "), ""]
        total_picked += len(picked)

    L += ["---", "",
          f"*共收录 {total_picked} 条实战原话，"
          f"全部出自博主在 {len(all_items)} 条精华跟帖。*"]
    with open(out, "w", encoding="utf-8") as f:
        f.write("\n".join(L))
    return total_picked, len(all_items), out


# ===== 个股 / 题材 / 时间线 导航索引 =====

# A股常见后缀，用于高precision提取个股名
_SUFFIX = (r"股份|科技|集团|电子|生物|医药|能源|化学|新材|动力|智能|传媒|证券|银行|"
           r"食品|乳业|汽车|建设|重工|机电|通信|软件|网络|数据|环保|电力|钢铁|有色|"
           r"机械|化工|材料|精密|光电|医疗|健康|文化|旅游|农业|家居|服饰|珠宝|矿业|"
           r"石油|燃气|水务|交通|物流|电商|金控|控股|发展|实业|联合|国际|信息|"
           r"半导体|存储|光伏|锂电|储能|算力|机器人|电路|微电")
# 连接词先替换成分隔符，避免「每日互动和并行科技」被切成「动和并行科技」
_CONN_RE = re.compile(r"[和与跟及或]")
# 左边界：必须是分隔符（非中文 / 非数字 / 非字母），
# 否则「12日航天发展」会被切成「日航天发展」
_NAME_RE = re.compile(r"(?<![\u4e00-\u9fa5A-Za-z0-9])([\u4e00-\u9fa5]{2,4})("
                      + _SUFFIX + r")")

# 前缀里的口语引导词（贪婪匹配会把它们吞进个股名，需要剥掉）
_LEAD_MULTI = ("明天", "昨天", "今天", "今年", "明年", "当日", "今日", "昨日",
               "周一", "周二", "周三", "周四", "周五", "周六", "周日",
               "比如", "随着", "随后", "观察", "除了", "还是", "然后", "而且",
               "其实", "因为", "所以", "如果", "就是", "可能", "应该", "已经",
               "正在", "刚刚", "马上", "一直", "再次", "接着", "结果", "于是",
               "另外", "当然", "不过", "只是", "主要", "重点", "继续", "开始",
               "准备", "打算", "希望", "觉得", "感觉", "知道", "看到", "说到",
               "提到", "注意", "关注", "提醒", "提示", "包括", "以及", "或者",
               "没有", "不能", "不会", "不要", "只有", "只要", "并且", "同时",
               "之后", "之前", "当时", "目前", "最后", "过去", "未来", "近期",
               "最近", "此外", "其中", "盯着", "最终", "高端", "日的", "当日",
               "模仿", "参考", "回顾", "回到", "再说", "还说", "只会", "只能",
               "完全", "特别", "尤其", "甚至", "依然", "依旧", "仍旧", "仍然",
               "暂时", "暂不", "先看", "再看", "多看", "少看", "重点看", "重点",
               "优先", "考虑", "选择", "换成", "换成", "切到", "去做", "去做",
               "到了", "到了", "等的", "等它", "等这", "等那", "拿着", "加上",
               "剩下", "留着", "出了", "进了", "做了", "买了", "卖了",
               "对于", "关于", "按照", "带动", "来说", "来说说", "叠加",
               "上周五", "下午", "现在", "很多", "一个", "一是", "一点",
               "世界", "国产", "大金融", "交易", "消费", "无人", "新能源",
               "华为", "哪吒", "有人", "有的", "有些", "那些",
               "尾盘", "早盘", "盘中", "开盘", "竞价")
_LEAD_SINGLE = "的了是在有就也都还再又才把被让给而那这个看说做买卖拿加减从像但"


def _strip_lead(name):
    """
    剥掉贪婪匹配吞进来的口语引导词。
    注意：剥到不足 2 字也要继续（返回空串由调用方判定为无效），
    否则「比如建设」会被当成个股名保留下来。
    """
    for _ in range(3):
        for w in _LEAD_MULTI:
            if name.startswith(w):
                name = name[len(w):]
                break
        else:
            if name and name[0] in _LEAD_SINGLE:
                name = name[1:]
                continue
            break
    return name

# 无后缀的短名（人工从语料候选中核定，避免规则误判）
SHORT_NAMES = """
红宝丽 多氟多 中毅达 银之杰 赢时胜 海能达 渝三峡 四川长虹 常山北明 华胜天成
每日互动 西藏天路 二六三 拓斯达 寒武纪 江波龙 深城交 德明利 贝因美 连云港
天下秀 创世纪 三六零 指南针 数据港 英维克 广生堂 昂利康 大宏立 南京港
安纳达 凯美特气 上海贝岭 五洲新春 万丰奥威 四方精创 蒙草生态 大千生态 深水规院
立方数科 中科海讯 共创草坪 金陵体育 深水海纳 蓝海华腾 蓝色光标 工业富联 海峡创新
科大国创 上海沪工 中科磁业 捷强装备 襄阳轴承 晨曦航空 七丰精工 世纪鼎利 东方财富
南方路机 国光连锁 冀东装备 张江高科 中钨高新 成飞集成 山子高科 中国电建 联环药业
中国长城 卧龙电驱 中大力德 中科曙光 国轩高科 合富中国 北方长龙 海南华铁 上海电力
中国卫星 大众公用 国晟科技 天华新能 中一科技 综艺股份 信邦智能 吉视传媒 标准股份
五新隧装 汇博云通 至纯科技 蓝黛科技 均胜电子 上纬新材 宗申动力 一鸣食品 粤桂股份
御银股份 梦网科技 尚纬股份 华映科技 信隆健康 广哈通信 利和兴 初灵信息 联美控股
福龙马 通宇通讯 方正电机 平潭发展 万通发展 西部材料 顺灏股份 神州信息
新炬网络 华银电力 长城军工 格尔软件 赛微电子 有研新材 海立股份 天际股份 中欣氟材
新瀚新材 山河智能 恒宝股份 建设工业 鑫科材料 长盛轴承 航锦科技 日出东方 岩山科技
杭钢股份 逸豪新材 国芳集团 宝通科技 美格智能 博创科技 电光科技 国民技术 汉得信息
永鼎股份 豪恩汽电 浙数文化 双成药业 天玑科技 天赐材料 天风证券 上海电气 洪田股份
三维通信 胜宏科技 通富微电 巨轮智能 尤夫股份 安记食品 乾照光电 江丰电子 合锻智能
中国软件 金发科技 天孚通信 辰欣药业 台基股份 霍普股份 海默科技 思泉新材 国投智能
保利联合 兴业股份 汇得科技 东贝集团 东华软件 引力传媒 益民集团 国星光电 汇金科技
岭南股份 润欣科技 日丰股份 科大智能 先导智能 美力科技 光线传媒 建新股份 高新兴
和而泰 三花智控 拓普集团 浙江荣泰 长盈精密 横河精密 日盈电子 新莱应材
""".split()

# 带个股后缀但其实是题材/概念词，需排除（精确匹配，不影响「神州信息」这类真名）
STOCK_STOP = {"量子科技", "人形机器人", "芯片半导体", "存储芯片", "智能驾驶",
              "跨境支付", "人工智能", "数字经济", "首发经济", "谷子经济",
              "低空经济", "深海经济", "深空经济", "固态电池", "光刻机",
              "大金融", "新消费", "创新药", "自主可控", "国产替代",
              "机器人", "大科技", "高端存储", "存储", "信息", "建设", "汽车",
              "芯片", "半导体", "光伏", "锂电", "储能", "算力", "电路",
              "微电", "数据", "网络", "通信", "环保", "材料", "软件", "硬件",
              "机械", "化工", "医药", "能源", "化学", "生物", "食品", "乳业",
              "服饰", "珠宝", "矿业", "石油", "燃气", "水务", "交通", "物流",
              "电商", "金控", "控股", "发展", "实业", "联合", "国际", "集团",
              "股份", "科技", "电子", "动力", "智能", "精密", "光电", "医疗",
              "健康", "文化", "旅游", "农业", "家居", "传媒", "证券", "银行",
              "重工", "机电", "钢铁", "有色", "电力",
              "国产软件", "消费电子", "新能源汽车", "华为汽车", "磷化工",
              "大科技", "国产算力", "交易软件", "无人物流", "芯片股"}

# 题材关键词（人工整理，覆盖博主主要操作的板块）
# 注意：不要放互为子串的词（如「固态」与「固态电池」），否则计数重复
THEMES = [
    "商业航天", "卫星互联网", "人形机器人", "机器人", "AI", "人工智能", "算力",
    "CPO", "PCB", "光模块", "固态电池", "锂电池", "六氟磷酸", "光刻机", "光刻胶",
    "稀土", "稳定币", "数字货币", "跨境支付", "脑机接口", "可控核聚变",
    "核电", "深海经济", "深空经济", "低空经济", "化工", "军工", "半导体", "芯片",
    "存储", "光伏", "券商", "大金融", "创新药", "新消费", "IP经济", "重组",
    "量子科技", "海峡两岸", "雅下水电", "海南自贸区", "摩尔线程", "DeepSeek",
    "英伟达", "液冷", "无人驾驶", "智能驾驶", "华为", "鸿蒙", "国产替代",
    "自主可控", "PEEK材料", "数据要素", "谷子经济", "宠物经济", "首发经济",
    "超导", "转基因", "东数西算", "光刻胶", "固态电池",
]
THEMES = list(dict.fromkeys(THEMES))  # 去重保序

GENERIC_KW = (r"低吸|涨停|拉板|回封|炸板|降仓|加仓|清仓|底仓|格局|滚动|做T|"
              r"买点|卖点|五日线|竞价|开盘|仓位|控异动|渡劫|核心|龙头|分歧|"
              r"一致|量能|节点|情绪|洗盘|主升|离场")


def _load_digest_items(root):
    """读取全部精华跟帖，附加 src（主帖编号）"""
    src = sub("digest", root)
    items = []
    if not os.path.isdir(src):
        return items
    for fn in sorted(os.listdir(src)):
        if not fn.endswith(".md"):
            continue
        m = re.match(r"(\d{3})_", fn)
        idx = m.group(1) if m else "???"
        _, its = parse_md(os.path.join(src, fn))
        for it in its:
            it["src"] = idx
            items.append(it)
    return items


def extract_stock_names(text):
    """从一段文本中提取个股名（双源：后缀规则 + 核定短名表）"""
    out = set()
    c = _CONN_RE.sub("\x00", text)
    for m in _NAME_RE.finditer(c):
        prefix, suffix = m.group(1), m.group(2)
        if "\x00" in prefix:
            continue
        prefix = _strip_lead(prefix)
        nm = prefix + suffix
        if len(prefix) < 2 or len(nm) < 3:
            continue
        if nm in STOCK_STOP:
            continue
        out.add(nm)
    for nm in SHORT_NAMES:
        if nm in text and nm not in STOCK_STOP:
            out.add(nm)
    return out


def _fmt_quote(it, prefix=""):
    head = f"**{it['time']}**"
    if it.get("floor"):
        head += f" · {it['floor']}"
    head += f"（帖 {it['src']}）"
    L = [prefix + head, ""]
    if it.get("quote"):
        L += [f"> 回应：{it['quote'].replace(chr(10), ' / ')}", ""]
    L += ["> " + it["content"].replace("\n", "\n> "), ""]
    return L


def _pick_quotes(items, kw_re, topn=3, per_src=2):
    """按信息密度挑代表性原话"""
    cands = []
    for it in items:
        s = score(it["content"], kw_re)
        if s > 0:
            cands.append((s, it))
    cands.sort(key=lambda x: (-x[0], x[1]["time"]))
    picked, cnt = [], {}
    for _, it in cands:
        if cnt.get(it["src"], 0) >= per_src:
            continue
        picked.append(it)
        cnt[it["src"]] = cnt.get(it["src"], 0) + 1
        if len(picked) >= topn:
            break
    return picked


def build_nav_index(root):
    """生成《个股与题材速查索引》：个股表 + 题材表 + 时间线"""
    items = _load_digest_items(root)
    if not items:
        return 0, 0, None
    out = os.path.join(root, _LAYOUT["base"], "个股与题材速查索引.md")

    # --- 个股 ---
    stock = {}
    for it in items:
        for nm in extract_stock_names(it["content"]):
            d = stock.setdefault(nm, {"n": 0, "srcs": set(), "items": [],
                                      "first": it["time"], "last": it["time"]})
            d["n"] += 1
            d["srcs"].add(it["src"])
            d["items"].append(it)
            if it["time"] < d["first"]:
                d["first"] = it["time"]
            if it["time"] > d["last"]:
                d["last"] = it["time"]

    stock = {k: v for k, v in stock.items() if v["n"] >= 2}
    rank_all = sorted(stock.items(), key=lambda kv: (-kv[1]["n"], kv[0]))
    # 低频段（2-4 次）规则提取容易混入口语词，单独降级为附录
    rank = [kv for kv in rank_all if kv[1]["n"] >= 5]
    low = [kv for kv in rank_all if kv[1]["n"] < 5]

    # --- 题材 ---
    theme = {}
    for t in THEMES:
        hit = [it for it in items if t in it["content"]]
        if hit:
            theme[t] = {"n": len(hit), "srcs": {i["src"] for i in hit},
                        "items": hit}
    trank = sorted(theme.items(), key=lambda kv: -kv[1]["n"])

    # --- 时间线 ---
    month = {}
    for it in items:
        m = it["time"][:7]
        d = month.setdefault(m, {"n": 0, "srcs": set(), "items": []})
        d["n"] += 1
        d["srcs"].add(it["src"])
        d["items"].append(it)
    mrank = sorted(month.items())

    L = ["# 见股起意 · 个股与题材速查索引", "",
         f"> 从 {len(items)} 条精华跟帖中自动提取。",
         "> **用法**：想查「某只票 / 某个题材他怎么说」时，先在这里定位，",
         "> 拿到「帖编号 + 时间」后到 `资料/03_跟帖精华/` 里读完整上下文。",
         "",
         f"**共识别出 {len(rank)} 只个股、{len(trank)} 个题材，"
         f"覆盖 {len(mrank)} 个月份。**", "",
         "> 说明：个股名由「后缀规则 + 人工核定词表」双源提取，",
         "> 可能混入少量非个股词（如题材名、口语词），也可能漏掉极低频个股。",
         "> 做重要判断时请回到原文核对。", "",
         "---", ""]

    # 个股总表（≥5 次，高可信）
    L += ["## 一、个股速查表（提及 ≥ 5 次）", "",
          f"> 共 {len(rank)} 只，按提及次数排序。低频个股见本节末尾附录。", "",
          "| # | 个股 | 提及 | 涉及主帖 | 首次 | 最近 |",
          "|---|------|-----|---------|------|------|"]
    for i, (nm, d) in enumerate(rank, 1):
        L.append(f"| {i} | **{nm}** | {d['n']} | "
                 f"{len(d['srcs'])} 篇 | {d['first'][:10]} | {d['last'][:10]} |")
    L += [""]
    if low:
        L += [f"**低频附录**（提及 2-4 次，共 {len(low)} 只，可能混入少量口语词）：", ""]
        L.append("、".join(
            f"{nm}({d['n']})" for nm, d in low))
        L += [""]

    # 高频个股原话
    L += ["## 二、高频个股实战原话", "",
          "> 按提及次数取前 40 只，每只挑 3 条信息密度最高的原话。", ""]
    for nm, d in rank[:40]:
        L.append(f"### {nm}（{d['n']} 次 · {len(d['srcs'])} 篇主帖）")
        L.append("")
        qs = _pick_quotes(d["items"], GENERIC_KW, topn=3, per_src=2)
        if not qs:
            qs = d["items"][:2]
        for it in qs:
            L += _fmt_quote(it)
    L += ["---", ""]

    # 题材
    L += ["## 三、题材速查表", "",
          "| # | 题材 | 提及 | 涉及主帖 | 主要时期 |",
          "|---|------|-----|---------|---------|"]
    for i, (t, d) in enumerate(trank, 1):
        ts = sorted({x["time"][:7] for x in d["items"]})
        span = f"{ts[0]} ~ {ts[-1]}" if len(ts) > 1 else ts[0]
        L.append(f"| {i} | **{t}** | {d['n']} | {len(d['srcs'])} 篇 | {span} |")
    L += [""]

    L += ["## 四、高频题材实战原话", "",
          "> 按提及次数取前 15 个题材，每个挑 3 条。", ""]
    for t, d in trank[:15]:
        L.append(f"### {t}（{d['n']} 次 · {len(d['srcs'])} 篇主帖）")
        L.append("")
        qs = _pick_quotes(d["items"], GENERIC_KW, topn=3, per_src=2)
        for it in qs:
            L += _fmt_quote(it)
    L += ["---", ""]

    # 时间线
    L += ["## 五、时间线（按月）", "",
          "| 月份 | 精华跟帖 | 涉及主帖 |", "|------|---------|---------|"]
    for m, d in mrank:
        L.append(f"| {m} | {d['n']} | {len(d['srcs'])} 篇 |")
    L += [""]

    L += ["## 六、近 12 个月代表原话", "",
          "> 每月挑 3 条，用于快速了解他在那个阶段的核心判断。", ""]
    for m, d in mrank[-12:]:
        L.append(f"### {m}（{d['n']} 条）")
        L.append("")
        qs = _pick_quotes(d["items"], GENERIC_KW, topn=3, per_src=1)
        for it in qs:
            L += _fmt_quote(it)

    L += ["---", "",
          f"*数据截至本文件生成时。个股 {len(rank)} 只 / 题材 {len(trank)} 个 / "
          f"月份 {len(mrank)} 个。*"]

    with open(out, "w", encoding="utf-8") as f:
        f.write("\n".join(L))
    return len(rank), len(trank), out


# ===== 状态文件 =====

def load_json(path, default=None):
    if os.path.exists(path):
        try:
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return default if default is not None else {}
    return default if default is not None else {}


def save_json(path, obj):
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=1)
    os.replace(tmp, path)
