# -*- coding: utf-8 -*-
"""
重建「精华版 + 总索引」（单独跑时用这个；日常请用 工具/抓取更新/抓取更新.py 一键更新）

  python 工具/重建_精华与索引.py [--root DIR]

输入：<root>/02_跟帖全量/*.md      （技能目录下为 <root>/资料/02_跟帖全量/*.md）
输出：<root>/03_跟帖精华/*.md  +  <root>/跟帖索引.md
"""
import os
import sys
import argparse

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import 公共库 as K


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=None)
    args = ap.parse_args()
    root = K.get_root(args.root)
    total_all, total_val, nfiles = K.build_digest_index(root)
    print(f"处理 {nfiles} 个跟帖文件")
    print(f"跟帖总数 {total_all}，精华 {total_val} 条")
    print(f"索引已生成: {K.sub('index', root)}")


if __name__ == "__main__":
    main()
