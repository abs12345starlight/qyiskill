# -*- coding: utf-8 -*-
"""
重建《个股与题材速查索引》（单独跑时用这个；日常请用 工具/抓取更新/抓取更新.py 一键更新）

  python 工具/重建_个股题材索引.py [--root DIR]

输入：<root>/03_跟帖精华/*.md      （技能目录下为 <root>/资料/03_跟帖精华/*.md）
输出：<root>/个股与题材速查索引.md
      —— 个股速查表 + 高频个股原话 + 题材速查表 + 题材原话 + 月度时间线
"""
import os
import sys
import argparse

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import 公共库 as K


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=None)
    ap.add_argument("--inplace", action="store_true",
                    help="原地模式：数据住在技能目录 资料/ 下")
    args = ap.parse_args()

    if args.inplace:
        K.set_layout(True)
    root = K.get_root(args.root)
    ns, nt, out = K.build_nav_index(root)
    if out is None:
        print("没有找到精华跟帖，请先跑 工具/抓取更新/抓取更新.py")
        return
    print(f"个股 {ns} 只 / 题材 {nt} 个")
    print(f"索引已生成：{out}")


if __name__ == "__main__":
    main()
