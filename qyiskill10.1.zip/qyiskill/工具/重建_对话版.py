# -*- coding: utf-8 -*-
"""构建《跟帖对话版》——见股起意的回答 + 网友的提问，按楼层排成一问一答。

为什么需要这一层
----------------
默认的抓法只取楼主（uid=8478060）的发言，网友说了什么完全不收。
只有在楼主「引用」某条留言时，才会残留一个 `> 昵称 / > 时间`，
而 **被引用的正文是拿不到的**（quote 字段只有名字和时间）。

结果是很多回答脱离提问就读不懂——你看到一句「那就拿着吧」，
根本不知道前面那个人问的是什么。

这一层把网友的发言也抓下来，按楼层和博主的交织排序，还原成对话流。
难点是噪声：全站跟帖里 80% 是「师父早 / 666 / 感恩 / 打卡」，
所以 公共库.keep_reply() 负责把这类滤掉，只留提问和实质讨论。

用法
----
    python 工具/重建_对话版.py                 # 全部 98 篇（实测 18 分钟）
    python 工具/重建_对话版.py --idx 1,4,21    # 只做这几篇（定向刷新）
    python 工具/重建_对话版.py --limit 3       # 只做最新 3 篇
    python 工具/重建_对话版.py --tail 6        # 每篇只抓最后 6 页（调试用）
    python 工具/重建_对话版.py --workers 8     # 调并发
    python 工具/重建_对话版.py --root D:/xxx   # 换工作目录

输出到 <root>/04_跟帖对话版/001_xxx_对话版.md（技能目录下在 资料/ 里），
不影响已有的 02_跟帖全量 和 03_跟帖精华。

时效性说明
----------
对话版是**快照**：重建时必须把整篇的网友发言重新抓一遍（要按楼层排序，
没法简单增量追加），所以它天生比 02_跟帖全量 慢一拍。

定位是「深度查阅层」——查历史问答、看懂某句回答在回应什么。
想追最新几条跟帖，用 02_跟帖全量 或 03_跟帖精华 就够了。

所以日常不必重跑全量。想定向刷新某几篇（比如刚讨论过的那几篇）：

    python 工具/重建_对话版.py --idx 1,4,21
"""
import os
import re
import sys
import time
import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import 公共库 as K

DEFAULT_ROOT = None   # 留空：走 公共库.get_root() 的自动推断


def log(m):
    print(m, flush=True)


def qa_task(topic, qa_dir, tail=None, force_overwrite=False):
    slug, idx = topic["slug"], topic["idx"]
    fn = f"{idx:03d}_{K.safe_name(topic['title'])}_对话版.md"
    path = os.path.join(qa_dir, fn)

    pages = K.count_pages(slug)
    if not pages:
        return {"ok": False, "idx": idx, "note": "页数获取失败"}

    start = 1
    if tail:
        # --tail 是调试参数，抓到的只是尾部片段。若直接写盘会把完整版冲掉
        # （2026-09-10 踩过：用 --tail 2 测了两篇，完整数据被覆盖成 2 页）
        if os.path.exists(path) and not force_overwrite:
            return {"ok": False, "idx": idx,
                    "note": "已有完整文件，--tail 拒绝覆盖（要覆盖加 --force-overwrite）"}
        start = max(1, pages - tail + 1)

    items = K.scrape_page_range(slug, start, pages, include_all=True)
    if not items:
        return {"ok": False, "idx": idx, "note": "没抓到内容"}

    md, n_author, n_other = K.build_qa_md(
        idx, topic["title"], slug, items, topic.get("reply_count"))

    # 同名旧文件（标题变过）先清掉，避免留双份
    for f in os.listdir(qa_dir):
        if f.startswith(f"{idx:03d}_") and f.endswith("_对话版.md") and f != fn:
            try:
                os.remove(os.path.join(qa_dir, f))
            except OSError:
                pass

    with open(path, "w", encoding="utf-8") as f:
        f.write(md)
    return {"ok": True, "idx": idx, "author": n_author,
            "other": n_other, "pages": pages - start + 1, "file": fn}


def main():
    ap = argparse.ArgumentParser(description="构建跟帖对话版（楼主+网友）")
    ap.add_argument("--root", default=DEFAULT_ROOT, help="工作目录")
    ap.add_argument("--idx", help="只做指定序号的帖子，多个用逗号分隔，如 1,4,21")
    ap.add_argument("--limit", type=int, help="只做最新 N 篇")
    ap.add_argument("--tail", type=int,
                    help="⚠ 调试用：每篇只抓最后 N 页。会覆盖掉完整版！"
                         "（默认拒绝覆盖已存在的完整文件，要覆盖加 --force-overwrite）")
    ap.add_argument("--force-overwrite", action="store_true",
                    help="配合 --tail 使用，允许用残缺数据覆盖已有完整文件")
    ap.add_argument("--workers", type=int, default=6, help="并发数")
    args = ap.parse_args()

    K.set_layout(False)
    root = K.get_root(args.root)
    qa_dir = K.sub("qa", root)
    os.makedirs(qa_dir, exist_ok=True)

    log(f"工作目录：{root}")
    log("拉取主帖列表 ...")
    topics = K.fetch_topics()
    if args.idx:
        want = {int(x) for x in str(args.idx).replace("，", ",").split(",")
                if x.strip().isdigit()}
        topics = [t for t in topics if t["idx"] in want]
        log(f"  指定 {sorted(want)}，命中 {len(topics)} 篇")
    if args.limit:
        topics = topics[:args.limit]
    if not topics:
        log("没有匹配的帖子")
        return 1
    log(f"  共 {len(topics)} 篇")

    t0 = time.time()
    done = 0
    tot_a = tot_o = 0
    with ThreadPoolExecutor(max_workers=args.workers) as ex:
        futs = {ex.submit(qa_task, t, qa_dir, args.tail,
                          args.force_overwrite): t for t in topics}
        for fu in as_completed(futs):
            t = futs[fu]
            try:
                r = fu.result()
            except Exception as e:
                log(f"  [失败] {t['idx']:03d} {e}")
                continue
            done += 1
            if r["ok"]:
                tot_a += r["author"]
                tot_o += r["other"]
                log(f"  [{done}/{len(topics)}] {r['idx']:03d} "
                    f"楼主 {r['author']} + 网友 {r['other']} "
                    f"（扫 {r['pages']} 页）")
            else:
                log(f"  [{done}/{len(topics)}] {r['idx']:03d} {r['note']}")

    log("")
    log(f"完成，用时 {(time.time() - t0) / 60:.1f} 分钟")
    log(f"楼主发言 {tot_a} 条 | 网友发言 {tot_o} 条（已过滤问候灌水）")
    log(f"输出目录：{qa_dir}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
