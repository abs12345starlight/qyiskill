# -*- coding: utf-8 -*-
"""
见股起意知识库 · 一键增量更新
========================================
一条命令完成：校验 cookie → 抓最新主帖列表 → 抓新主帖正文 →
增量抓跟帖 → 重建精华/索引/速查手册 → 同步到技能目录 → 重新打包。

用法
----
  python 工具/抓取更新/抓取更新.py                # 增量更新（默认）
  python 工具/抓取更新/抓取更新.py --check        # 只体检：cookie 是否有效、有没有新帖/新跟帖
  python 工具/抓取更新/抓取更新.py --force        # 忽略状态，全量重抓跟帖
  python 工具/抓取更新/抓取更新.py --posts-only   # 只更新主帖正文
  python 工具/抓取更新/抓取更新.py --replies-only # 只更新跟帖
  python 工具/抓取更新/抓取更新.py --workers 8    # 并发数（默认 4）
  python 工具/抓取更新/抓取更新.py --no-sync      # 不同步到技能目录
  python 工具/抓取更新/抓取更新.py --cookie-file C:/path/cookie.txt
  python 工具/抓取更新/抓取更新.py --root D:/my/jgqy-kb

增量判定
--------
  主帖：列表页出现了 state 中没有的 slug → 新帖，抓正文 + 抓全部跟帖页
  跟帖：**以「网站末页最新一条楼主跟帖时间」为准**，与本地文件里最新一条比较：

        探测阶段（并发）：每篇帖子先取总页数，再从最后一页往回扫，
        找到网站上最新一条楼主跟帖；若它不新于本地 → 判定无更新，跳过
        抓取阶段：对判定有更新的帖子，继续往回定位「第一条不新于本地」
        的页码，从那一页重抓到末页（留一页重叠，保证不漏），去重合并

  ⚠ 为什么不看列表页的「全站跟帖总数」：实测这个数不随新跟帖变化
    （2026-09 那次博主连发 36 条，reply_count 仍是 15520 纹丝不动），
    只靠它会整帖漏抓。现在它只作为辅助信号保留。

  --quick N  只探测最新的 N 篇（日常快检用，博主基本都在最新几篇里发言）
  --force    忽略上述判定，98 篇全量重扫（约 5700 页 / 35 分钟）

cookie
------
  会过期。过期时把浏览器里复制的新 cookie 存到 <ROOT>/cookie.txt 即可，
  脚本会自动优先读取；也可以 --cookie-file 指定。
"""
import os
import re
import sys
import time
import shutil
import zipfile
import argparse
import threading
from datetime import datetime, timedelta
from concurrent.futures import ThreadPoolExecutor, as_completed

# 本脚本位于 <技能目录>/工具/抓取更新/，公共库在上一级 <技能目录>/工具/
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import 公共库 as K


def log(msg):
    print(msg, flush=True)


# ===== 1. 主帖正文 =====

def scrape_post(topic, posts_dir):
    """抓单篇主帖正文 → posts_dir/NNN_标题.md"""
    url = f"{K.BASE}{topic['slug']}"
    h = K.get(url)
    if not h:
        return None
    a = K.extract_article(h)
    if not a.get("body"):
        return None
    title = a.get("title") or topic["title"]
    fn = f"{topic['idx']:03d}_{K.safe_name(title)}.md"
    with open(os.path.join(posts_dir, fn), "w", encoding="utf-8") as f:
        f.write(f"# {title}\n\n")
        f.write(f"- **作者**: {K.AUTHOR_NAME}\n")
        f.write(f"- **日期**: {a.get('date', '未知')}\n")
        f.write(f"- **原文链接**: {url}\n")
        f.write(f"\n---\n\n")
        f.write(a["body"])
        f.write("\n")
    return fn


# ===== 2. 跟帖 =====

_lock = threading.Lock()


def _newest(items):
    """取一组跟帖里最新的时间（空时间跳过）"""
    ts = [i["time"] for i in items if i.get("time")]
    return max(ts) if ts else ""


def local_file_of(replies_dir, idx):
    """找到 idx 对应的本地跟帖文件名"""
    for f in os.listdir(replies_dir):
        if f.startswith(f"{idx:03d}_") and f.endswith("_跟帖.md"):
            return os.path.join(replies_dir, f)
    return None


def local_newest(replies_dir, idx):
    """本地文件里最新一条楼主跟帖的时间；无文件返回 ''"""
    p = local_file_of(replies_dir, idx)
    if not p:
        return ""
    try:
        _, items = K.parse_md(p)
    except Exception:
        return ""
    return _newest(items)


def pick_probe_list(topics, state, newest=5, active_days=45):
    """决定这一轮要探测哪些帖。

    背景：博主已「下课」（001 帖标题就是《最后一课…下课》），不会再有新主帖。
    98 篇里绝大多数是陈年老帖（状态文件里 last_time 为空），每次全量探测
    纯属浪费——实测 98 篇要 3 分多钟，而真正会有动静的只有最新的那几篇。

    所以默认只探两类（取并集）：
      ① 编号最小的 N 篇 —— 编号是倒序的，001 就是最新那篇
      ② 最近 M 天内有过跟帖的帖 —— 防止某个老帖突然复活

    要恢复全量探测用 --full-probe。
    """
    known = state["topics"]
    picked = {}

    # ① 最新的 N 篇（idx 越小越新）
    for t in sorted(topics, key=lambda x: x["idx"])[:max(1, newest)]:
        picked[t["slug"]] = t

    # ② 最近 active_days 天内有过跟帖的
    if active_days > 0:
        cut = (datetime.now() - timedelta(days=active_days)).strftime("%Y-%m-%d")
        for t in topics:
            lt = (known.get(t["slug"], {}).get("last_time") or "")[:10]
            if lt and lt >= cut:
                picked[t["slug"]] = t

    return sorted(picked.values(), key=lambda x: x["idx"])


def probe_topic(topic, replies_dir, idle_back=12, resume_back=80):
    """
    探测一篇帖子是否有新跟帖，并定位「应从哪一页开始重抓」。

    思路：评论按时间正序分页，所以从最后一页往回扫：
      - 末页有楼主跟帖 → 直接拿到网站最新时间，与本地比较（绝大多数帖子 2 个请求搞定）
      - 末页没有楼主跟帖（帖子早已冷却） → 最多往回扫 idle_back 页，
        若整段都没有楼主跟帖，判定无更新
      - 一旦发现有更新的内容 → 继续往回找第一个「楼主跟帖都不新于本地」的页，
        从那一页开始重抓（留一页重叠），最多回扫 resume_back 页

    返回 dict：{ok, slug, pages, local_last, web_last, need, resume, scanned}
    """
    slug = topic["slug"]
    pages = K.count_pages(slug)
    if not pages:
        return {"ok": False, "slug": slug, "pages": 0, "local_last": "",
                "web_last": "", "need": False, "resume": 1, "scanned": 0}

    local_last = local_newest(replies_dir, topic["idx"])
    if not local_last:          # 本地没数据 → 整帖重抓，不必探测
        return {"ok": True, "slug": slug, "pages": pages, "local_last": "",
                "web_last": "", "need": True, "resume": 1, "scanned": 0}

    web_last = ""
    resume = 1
    scanned = 0
    hit_author = False          # 回扫过程中是否遇到过楼主跟帖
    for p in range(pages, 0, -1):
        items = K.scrape_page_range(slug, p, p)
        scanned += 1
        if items:
            hit_author = True
            newest = _newest(items)
            if newest > web_last:
                web_last = newest
            if newest <= local_last:
                resume = p     # 这一页已在本地，从它开始重抓（含重叠，安全）
                break
        # 冷却帖兜底：扫了 idle_back 页仍无楼主跟帖，或已确认无更新
        if scanned >= idle_back and not hit_author:
            resume = p
            break
        # 有更新的帖子：回扫上限
        if scanned >= resume_back:
            resume = p
            break

    need = bool(web_last and web_last > local_last)
    return {"ok": True, "slug": slug, "pages": pages, "local_last": local_last,
            "web_last": web_last, "need": need, "resume": resume,
            "scanned": scanned}


def scrape_replies_task(topic, replies_dir, state, tail_pages, force, resume=None):
    """抓一篇帖子的楼主跟帖（增量或全量），返回 dict"""
    slug = topic["slug"]
    idx = topic["idx"]
    fn = f"{idx:03d}_{K.safe_name(topic['title'])}_跟帖.md"
    path = os.path.join(replies_dir, fn)

    # 已有文件按 state 里的文件名读；文件名可能因标题变化漂移，做一次兜底查找
    old_fn = None
    st = state["topics"].get(slug, {})
    if st.get("file") and os.path.exists(os.path.join(replies_dir, st["file"])):
        old_fn = st["file"]
    else:
        for f in os.listdir(replies_dir):
            if f.startswith(f"{idx:03d}_") and f.endswith("_跟帖.md"):
                old_fn = f
                break

    old_items = []
    if old_fn:
        _, old_items = K.parse_md(os.path.join(replies_dir, old_fn))

    pages = K.count_pages(slug)
    if not pages:
        return {"slug": slug, "ok": False, "note": "页数获取失败"}

    if force or not old_items:
        start = 1                       # 全量 / 首次
    elif resume:                        # 探测阶段已定位到起抓页
        start = min(max(1, resume), pages)
    else:                               # 没走探测（例如 --quick 之外的兜底）
        old_pages = st.get("pages") or pages
        start = min(max(1, old_pages - tail_pages + 1), pages)

    fresh = K.scrape_page_range(slug, start, pages)

    merged = {K.dedup_key(i): i for i in ([] if force else old_items)}
    added = 0
    for i in fresh:
        k = K.dedup_key(i)
        if k in merged:
            merged[k] = i          # 楼层号可能变，用新的覆盖
        else:
            added += 1
            merged[k] = i
    items = sorted(merged.values(), key=lambda x: x["time"])
    note = ""

    # --force 全量重抓时的保险：若抓到的比原来少 10% 以上，
    # 说明中途请求失败，回滚成「旧 ∪ 新」，避免把历史数据写没
    if force and old_items and len(items) < len(old_items) * 0.9:
        m2 = {K.dedup_key(i): i for i in old_items}
        m2.update({K.dedup_key(i): i for i in fresh})
        items = sorted(m2.values(), key=lambda x: x["time"])
        note = f"抓取不全，已回滚合并（旧 {len(old_items)} ∪ 新 {len(fresh)}）"

    with open(path, "w", encoding="utf-8") as f:
        f.write(K.build_md(idx, topic["title"], slug, items, topic.get("reply_count")))
    # 清理因标题变化产生的旧文件
    if old_fn and old_fn != fn and os.path.exists(os.path.join(replies_dir, old_fn)):
        os.remove(os.path.join(replies_dir, old_fn))

    return {"slug": slug, "ok": True, "count": len(items), "added": added,
            "scanned": pages - start + 1, "file": fn, "note": note, "pages": pages,
            "last_time": _newest(items)}


# ===== 2.5 状态播种 =====

def seed_state(state, topics, replies_dir):
    """
    增量状态.json 不存在（首次使用本脚本 / 文件被删）时，
    用已有的 *_跟帖.md 反推状态，避免把已抓过的 98 篇当成新帖全量重抓。
    文件头里的「原帖」行记录了 slug，用它做匹配。
    """
    if state["topics"] or not os.path.isdir(replies_dir):
        return 0
    files = [f for f in os.listdir(replies_dir) if f.endswith("_跟帖.md")]
    if not files:
        return 0
    by_slug = {}
    for fn in files:
        with open(os.path.join(replies_dir, fn), "r", encoding="utf-8") as f:
            head = f.read(4000)
        m = re.search(r"原帖：https?://www\.tgb\.cn(/a/[A-Za-z0-9]+)", head)
        if m:
            by_slug[m.group(1)] = fn
    n = 0
    for t in topics:
        fn = by_slug.get(t["slug"])
        if not fn:
            continue
        _, items = K.parse_md(os.path.join(replies_dir, fn))
        m = re.match(r"(\d{3})_", fn)
        t["idx"] = int(m.group(1)) if m else t["idx"]
        state["topics"][t["slug"]] = {
            "idx": t["idx"], "title": t["title"], "slug": t["slug"],
            "reply_count": t["reply_count"], "count": len(items), "file": fn,
        }
        n += 1
    return n


# ===== 3. 同步到技能目录 =====

SYNC_MAP = [
    ("01_主贴正文", "资料/01_主贴正文"),
    ("02_跟帖全量", "资料/02_跟帖全量"),
    ("03_跟帖精华", "资料/03_跟帖精华"),
    # 对话版：楼主 + 网友提问，由 工具/重建_对话版.py 单独维护。
    # 若目录不存在会自动跳过，不影响主流程。
    ("04_跟帖对话版", "资料/04_跟帖对话版"),
]
SYNC_FILES = [
    ("跟帖索引.md", "资料/跟帖索引.md"),
    ("跟帖实战速查手册.md", "资料/跟帖实战速查手册.md"),
    ("个股与题材速查索引.md", "资料/个股与题材速查索引.md"),
    ("主贴清单.txt", "资料/主贴清单.txt"),
    # 下面两份放技能目录根部。以前漏配了，导致改完工作目录的版本后
    # 技能目录/打包里还是旧的，得手工拷贝——2026-09-10 补上。
    ("使用手册.html", "使用手册.html"),
    ("说明.md", "说明.md"),
]


def sync_to_skill(root, skill_dir):
    """
    增量同步到技能目录。

    ⚠ 不要改回 rmtree + copytree：整目录删除会一次性删掉上百个文件，
    触发批量删除保护（SAFE_DELETE_BULK_CONFIRM_REQUIRED）导致同步中断。
    这里改成「按文件比较后覆盖写 + 只清理漂移残留」，平时增删都是个位数。
    """
    if not os.path.isdir(skill_dir):
        log(f"  [跳过] 技能目录不存在：{skill_dir}")
        return False
    n_copy = n_del = 0
    for src, dst in SYNC_MAP:
        s = os.path.join(root, src)
        d = os.path.join(skill_dir, dst)
        if not os.path.isdir(s):
            continue
        os.makedirs(d, exist_ok=True)
        src_files = {f for f in os.listdir(s) if os.path.isfile(os.path.join(s, f))}
        # 新增 / 有变化 → 覆盖写
        for f in src_files:
            sp, dp = os.path.join(s, f), os.path.join(d, f)
            if (not os.path.exists(dp)
                    or os.path.getsize(sp) != os.path.getsize(dp)
                    or os.path.getmtime(sp) > os.path.getmtime(dp)):
                shutil.copy2(sp, dp)
                n_copy += 1
        # 源里已没有的（多为标题变化导致的文件名漂移）→ 清理
        stale = [f for f in os.listdir(d)
                 if f not in src_files and os.path.isfile(os.path.join(d, f))]
        if len(stale) > 20:
            log(f"      ⚠ {dst} 有 {len(stale)} 个残留文件超出预期，"
                f"已跳过清理，请手工确认")
        else:
            for f in stale:
                os.remove(os.path.join(d, f))
                n_del += 1
    log(f"      覆盖 {n_copy} 个文件，清理 {n_del} 个残留")
    for src, dst in SYNC_FILES:
        s = os.path.join(root, src)
        d = os.path.join(skill_dir, dst)
        if os.path.exists(s):
            os.makedirs(os.path.dirname(d), exist_ok=True)
            shutil.copy2(s, d)
    # 脚本保持同源。
    # 本脚本现在住在 <技能目录>/工具/抓取更新/，原地模式下它本来就在技能目录内
    # ——此时跳过，既避免自拷贝报 WinError 32，也避免把 抓取更新.py 平铺到 工具/。
    here = os.path.dirname(os.path.abspath(__file__))
    inside_skill = os.path.abspath(here).startswith(
        os.path.abspath(skill_dir) + os.sep)
    tools_src = os.path.dirname(here)          # <技能目录>/工具
    tools_dst = os.path.join(skill_dir, "工具")
    if not inside_skill and os.path.isdir(tools_dst):
        for base, dirs, files in os.walk(tools_src):
            dirs[:] = [d for d in dirs if d != "__pycache__"]
            rel = os.path.relpath(base, tools_src)
            out = os.path.join(tools_dst, rel) if rel != "." else tools_dst
            os.makedirs(out, exist_ok=True)
            for f in files:
                if f.endswith(".py") or f.endswith(".md"):
                    shutil.copy2(os.path.join(base, f), os.path.join(out, f))
    return True


def package(root, skill_dir, out_dir=None):
    if not os.path.isdir(skill_dir):
        return None
    zpath = os.path.join(out_dir or root, "qyiskill.zip")
    # 打进包里没意义、或含本机信息的条目
    EXCLUDE_DIRS = {"__pycache__", ".git", ".venv"}
    EXCLUDE_FILES = {"路径配置.txt", "cookie.txt", ".DS_Store"}
    EXCLUDE_EXT = {".pyc", ".zip"}      # 排除 zip，否则会把上一次的包套进新包里
    n = 0
    with zipfile.ZipFile(zpath, "w", zipfile.ZIP_DEFLATED) as z:
        for base, dirs, files in os.walk(skill_dir):
            dirs[:] = [d for d in dirs if d not in EXCLUDE_DIRS]
            for f in files:
                if f in EXCLUDE_FILES or os.path.splitext(f)[1] in EXCLUDE_EXT:
                    continue
                p = os.path.join(base, f)
                z.write(p, os.path.relpath(p, os.path.dirname(skill_dir)))
                n += 1
    return zpath, n


# ===== 主流程 =====

def main():
    ap = argparse.ArgumentParser(description="见股起意知识库一键增量更新")
    ap.add_argument("--root", default=None, help="知识库工作目录")
    ap.add_argument("--cookie-file", default=None, help="cookie 文件路径")
    ap.add_argument("--workers", type=int, default=4, help="并发线程数（默认 4）")
    ap.add_argument("--tail-pages", type=int, default=2,
                    help="已抓过的帖子重抓尾部多少页（默认 2）")
    ap.add_argument("--check", action="store_true", help="只体检，不抓数据")
    ap.add_argument("--force", action="store_true", help="全量重抓跟帖")
    ap.add_argument("--full-probe", action="store_true",
                    help="全量探测全部 98 篇（默认只探「最新几篇 + 近期活跃帖」）")
    ap.add_argument("--probe-newest", type=int, default=5, metavar="N",
                    help="探测编号最小的 N 篇＝最新的 N 篇（默认 5）")
    ap.add_argument("--probe-days", type=int, default=45, metavar="M",
                    help="额外探测最近 M 天内有跟帖的帖（默认 45）")
    ap.add_argument("--quick", type=int, default=0, metavar="N",
                    help="只探测最新的 N 篇（覆盖默认的探测范围）")
    ap.add_argument("--idle-back", type=int, default=12, metavar="N",
                    help="冷却帖末页无楼主跟帖时，最多往回扫几页（默认 12）")
    ap.add_argument("--resume-back", type=int, default=80, metavar="N",
                    help="定位起抓页时最多往回扫几页（默认 80）")
    ap.add_argument("--posts-only", action="store_true", help="只更新主帖正文")
    ap.add_argument("--replies-only", action="store_true", help="只更新跟帖")
    ap.add_argument("--no-sync", action="store_true", help="不同步到技能目录")
    ap.add_argument("--no-package", action="store_true", help="不重新打包 zip")
    ap.add_argument("--inplace", action="store_true",
                    help="原地更新：root 就是技能目录本身，数据直接读写 资料/，"
                         "跳过同步步骤（移植到新机器后用这个）")
    args = ap.parse_args()

    K.set_layout(args.inplace)
    root = K.get_root(args.root)
    # 原地模式下 root 即技能目录
    skill_dir = root if args.inplace else K.get_skill_dir()
    posts_dir = K.sub("posts", root)
    replies_dir = K.sub("replies", root)
    os.makedirs(posts_dir, exist_ok=True)
    os.makedirs(replies_dir, exist_ok=True)

    cookie, src = K.load_cookie(args.cookie_file, root)
    K.init_cookie(cookie)

    state_path = os.path.join(root, "增量状态.json")
    state = K.load_json(state_path, {"topics": {}, "last_run": None})

    t0 = time.time()
    log("=" * 66)
    log("见股起意知识库 · 增量更新" + ("（原地模式）" if args.inplace else ""))
    log("=" * 66)
    log(f"工作目录 : {root}")
    log(f"技能目录 : {skill_dir}"
        + ("（= 工作目录）" if args.inplace else ""))
    log(f"Cookie   : {src}")
    log("")

    # --- 步骤 1：cookie 体检 ---
    log("[1/7] 校验 cookie ...")
    ok, msg = K.check_cookie()
    log(f"      {msg}")
    if not ok:
        log("")
        log("  × cookie 失效。请把浏览器里复制的新 cookie 保存到：")
        log(f"      {os.path.join(root, 'cookie.txt')}")
        log("    或运行时加 --cookie-file <路径>")
        return 1

    # --- 步骤 2：抓主帖列表 ---
    log("[2/7] 抓取主帖列表 ...")
    topics = K.fetch_topics()
    if not topics:
        log("  × 未取到主帖列表，中止")
        return 1
    K.write_topics_txt(topics, os.path.join(root, K._LAYOUT["base"],
                                            K._LAYOUT["topics"]))
    log(f"      共 {len(topics)} 篇主帖")

    # 沿用已有编号：新帖排在末尾，删除的帖不再出现
    known = state["topics"]
    used = {v["idx"] for v in known.values()}
    next_idx = max(used) + 1 if used else 0
    for t in topics:
        if t["slug"] in known:
            t["idx"] = known[t["slug"]]["idx"]
        else:
            next_idx += 1
            t["idx"] = next_idx

    # 首次运行时用已有文件播种，避免误判为全量新帖
    seeded = seed_state(state, topics, replies_dir)
    if seeded:
        log(f"      已从本地 {seeded} 个跟帖文件恢复状态")

    new_topics = [t for t in topics if t["slug"] not in known]
    count_changed = [t for t in topics
                     if t["slug"] in known
                     and known[t["slug"]].get("reply_count") != t["reply_count"]]
    have_idx = {f[:3] for f in os.listdir(replies_dir) if f.endswith("_跟帖.md")}
    missing = [t for t in topics if f"{t['idx']:03d}" not in have_idx]

    log(f"      新帖 {len(new_topics)} 篇 | 列表页总数有变化 {len(count_changed)} 篇 "
        f"| 本地缺文件 {len(missing)} 篇")

    # --- 步骤 2b：尾部探测（增量判定的真正依据） ---
    probe_map = {}
    if args.force or args.posts_only:
        log("")
        log("[2b/7] 跳过尾部探测（--force / --posts-only）")
        changed = list(count_changed)
    else:
        if args.quick:
            probe_list = topics[:args.quick]
            scope = f"--quick {args.quick}"
        elif args.full_probe:
            probe_list = topics
            scope = "全量（--full-probe）"
        else:
            probe_list = pick_probe_list(topics, state,
                                         args.probe_newest, args.probe_days)
            scope = (f"快速（最新 {args.probe_newest} 篇 + "
                     f"{args.probe_days} 天内有跟帖的）")
        log("")
        log(f"[2b/7] 尾部探测 {len(probe_list)}/{len(topics)} 篇 · {scope}，"
            f"并发 {args.workers} ...")
        if len(probe_list) < len(topics):
            log(f"      跳过 {len(topics) - len(probe_list)} 篇陈年老帖"
                f"（要全量加 --full-probe）")
        n_probe_ok = 0
        n_probe_fail = 0
        with ThreadPoolExecutor(max_workers=args.workers) as ex:
            futs = {ex.submit(probe_topic, t, replies_dir,
                              args.idle_back, args.resume_back): t
                    for t in probe_list}
            for fu in as_completed(futs):
                t = futs[fu]
                try:
                    r = fu.result()
                except Exception as e:
                    log(f"      × {t['idx']:03d} 探测异常 "
                        f"{type(e).__name__}: {e}")
                    continue
                if not r.get("ok"):
                    # ⚠ 关键：抓不到内容 ≠ 没有新内容。
                    # 2026-09-15 踩过——淘股吧加实名认证墙后，所有帖都抓不到，
                    # 旧代码仍报「探测完成 98/98，有新跟帖 0 篇」，看起来像正常。
                    n_probe_fail += 1
                    probe_map[r["slug"]] = r
                    if n_probe_fail <= 3:
                        log(f"      × {t['idx']:03d} 探测失败（抓不到内容）")
                    continue
                probe_map[r["slug"]] = r
                n_probe_ok += 1
                if r["need"]:
                    log(f"      ★ {t['idx']:03d} 有新跟帖  "
                        f"本地 {r['local_last'][:10]} → 网站 {r['web_last'][:10]}  "
                        f"{t['title'][:24]}")
        n_new = sum(1 for r in probe_map.values() if r["need"])
        log(f"      探测完成 {n_probe_ok}/{len(probe_list)} 篇成功"
            + (f"，{n_probe_fail} 篇失败" if n_probe_fail else "")
            + f"，其中有新跟帖 {n_new} 篇")

        # 全军覆没 → 说明是访问被挡（认证墙 / cookie 失效 / 网站改版），
        # 绝不能报「无更新」，要明确告诉用户去查什么。
        if n_probe_fail and n_probe_ok == 0:
            log("")
            log("  " + "×" * 58)
            log(f"  × 全部 {n_probe_fail} 篇都抓不到内容，本次没有做任何更新。")
            log("  × 常见原因（按可能性排序）：")
            log("  ×   1) 淘股吧新增实名认证要求 → 帖子页被重定向到认证页")
            log("  ×      解决：用该账号在网页版完成实名认证（含人脸核身）后重试")
            log("  ×   2) cookie 失效 → 重新取一份粘进 cookie.txt")
            log("  ×   3) 网站改版 → 页面结构变了，需要更新解析规则")
            log("  × 本地已有数据完好，查询不受影响。")
            log("  " + "×" * 58)
            log("")
            # 抓不到数据 ≠ 什么都不做：本地文档/索引可能被手工改过，
            # 同步+打包不依赖抓取，顺手做掉，并说清楚「没有新数据」。
            log("  → 仍同步并重新打包本地已有内容（不含新抓取的数据）...")
            try:
                if not args.inplace and not args.no_sync:
                    if sync_to_skill(root, skill_dir):
                        log(f"      已同步 → {skill_dir}")
                if not args.no_package:
                    # ⚠ 非 inplace 时不要传 out_dir（默认写到 root）；
                    # 传 os.path.dirname(root) 会把 zip 写到工作目录的父目录
                    r = (package(root, skill_dir, out_dir=os.path.dirname(root))
                         if args.inplace else package(root, skill_dir))
                    if r:
                        zp, n = r
                        log(f"      已打包 → {zp}"
                            f"（{os.path.getsize(zp)/1048576:.1f}MB, {n} 文件）")
            except Exception as e:
                log(f"     同步/打包失败：{type(e).__name__}: {e}")
            log("")
            return 2

        # 有更新 = 探测命中 ∪ 列表页总数变化（双保险，任一命中即抓）
        changed = list(count_changed)
        got = {t["slug"] for t in changed}
        for t in topics:
            r = probe_map.get(t["slug"])
            if r and r["need"] and t["slug"] not in got:
                changed.append(t)
                got.add(t["slug"])

    if args.check:
        log("")
        log("  --check 模式，不抓数据。待更新清单：")
        for t in new_topics:
            log(f"     [新帖] {t['idx']:03d} {t['title'][:36]} "
                f"(跟帖 {t['reply_count']})")
        for t in changed:
            r = probe_map.get(t["slug"])
            if r and r["need"]:
                log(f"     [跟帖] {t['idx']:03d} {t['title'][:36]} "
                    f"{r['local_last'][:10]} → {r['web_last'][:10]}")
            else:
                o = known[t["slug"]].get("reply_count", 0)
                log(f"     [总数] {t['idx']:03d} {t['title'][:36]} "
                    f"{o} → {t['reply_count']}")
        for t in missing:
            log(f"     [缺件] {t['idx']:03d} {t['title'][:36]}")
        if not (new_topics or changed or missing):
            log("     无更新，知识库已是最新")
        return 0

    # --- 步骤 3：新主帖正文 ---
    if not args.replies_only:
        log(f"[3/7] 抓取主帖正文（新帖 {len(new_topics)} 篇）...")
        n_ok = 0
        for t in new_topics:
            fn = scrape_post(t, posts_dir)
            if fn:
                n_ok += 1
                log(f"      ✓ {t['idx']:03d} {t['title'][:40]}")
            else:
                log(f"      × {t['idx']:03d} {t['title'][:40]} 抓取失败")
            time.sleep(0.4)
        log(f"      完成 {n_ok}/{len(new_topics)}")
    else:
        log("[3/7] 跳过（--replies-only）")

    # --- 步骤 4：跟帖增量 ---
    if not args.posts_only:
        if args.force:
            todo = topics
            log(f"[4/7] 全量重抓跟帖（{len(todo)} 篇）...")
        else:
            todo = list({t["slug"]: t for t in (new_topics + changed + missing)}.values())
            log(f"[4/7] 增量抓跟帖（{len(todo)} 篇）...")
        todo.sort(key=lambda t: t["idx"])

        done = 0
        total_added = 0
        with ThreadPoolExecutor(max_workers=args.workers) as ex:
            futs = {}
            for t in todo:
                r = probe_map.get(t["slug"])
                res = r["resume"] if (r and r["need"]) else None
                futs[ex.submit(scrape_replies_task, t, replies_dir, state,
                               args.tail_pages, args.force, res)] = t
            for fu in as_completed(futs):
                t = futs[fu]
                try:
                    r = fu.result()
                except Exception as e:
                    log(f"      × {t['idx']:03d} 异常 {type(e).__name__}: {e}")
                    continue
                if not r["ok"]:
                    log(f"      × {t['idx']:03d} {t['title'][:36]} {r['note']}")
                    continue
                with _lock:
                    state["topics"][r["slug"]] = {
                        "idx": t["idx"], "title": t["title"], "slug": r["slug"],
                        "reply_count": t["reply_count"], "count": r["count"],
                        "pages": r["pages"], "file": r["file"],
                        "last_time": r.get("last_time", ""),
                    }
                    K.save_json(state_path, state)
                total_added += r["added"]
                done += 1
                log(f"      ✓ {t['idx']:03d} {r['count']:5d} 条 (+{r['added']:3d} 新增, "
                    f"扫描 {r['scanned']} 页)  {t['title'][:28]}"
                    + (f"  ⚠ {r['note']}" if r["note"] else ""))
        log(f"      完成 {done}/{len(todo)} 篇，新增跟帖 {total_added} 条")
    else:
        log("[4/7] 跳过（--posts-only）")

    # 补全未变动帖子的元信息
    for t in topics:
        slug = t["slug"]
        if slug not in state["topics"]:
            fn = next((f for f in os.listdir(replies_dir)
                       if f.startswith(f"{t['idx']:03d}_") and f.endswith("_跟帖.md")), None)
            state["topics"][slug] = {
                "idx": t["idx"], "title": t["title"], "slug": slug,
                "reply_count": t["reply_count"], "count": None, "file": fn}
        else:
            state["topics"][slug]["reply_count"] = t["reply_count"]
            state["topics"][slug]["idx"] = t["idx"]
            state["topics"][slug]["title"] = t["title"]

    # --- 步骤 5：精华版 + 索引 ---
    log("[5/7] 重建精华版与索引 ...")
    total_all, total_val, nfiles = K.build_digest_index(root)
    log(f"      跟帖 {total_all} 条 → 精华 {total_val} 条（{nfiles} 篇）")

    # --- 步骤 6：速查手册 + 导航索引 ---
    log("[6/7] 重建速查手册与导航索引 ...")
    picked, pool, hb = K.build_handbook(root)
    log(f"      速查手册 {picked} 条（候选 {pool} 条）")
    ns, nt, nav = K.build_nav_index(root)
    if nav:
        log(f"      导航索引：个股 {ns} 只 / 题材 {nt} 个")

    # --- 步骤 7：同步 + 打包 ---
    if args.inplace:
        log("[7/7] 原地模式：数据已在技能目录内，跳过同步")
        if args.no_package:
            log("      跳过打包（--no-package）")
        else:
            r = package(root, skill_dir, out_dir=os.path.dirname(root))
            if r:
                zp, n = r
                log(f"      已打包 → {zp}（{os.path.getsize(zp)/1048576:.1f}MB, {n} 文件）")
    elif args.no_sync:
        log("[7/7] 跳过同步（--no-sync）")
    else:
        log("[7/7] 同步到技能目录并打包 ...")
        if sync_to_skill(root, skill_dir):
            log(f"      已同步 → {skill_dir}")
        if args.no_package:
            log("      跳过打包（--no-package）")
        else:
            r = package(root, skill_dir)
            if r:
                zp, n = r
                log(f"      已打包 → {zp}（{os.path.getsize(zp)/1048576:.1f}MB, {n} 文件）")

    state["last_run"] = time.strftime("%Y-%m-%d %H:%M:%S")
    state["stats"] = {"topics": len(topics), "replies": total_all,
                      "digest": total_val, "handbook": picked}
    K.save_json(state_path, state)

    log("")
    log("=" * 66)
    log(f"全部完成，用时 {(time.time()-t0)/60:.1f} 分钟")
    log(f"主帖 {len(topics)} 篇 | 跟帖 {total_all} 条 | 精华 {total_val} 条 "
        f"| 手册 {picked} 条")
    log("=" * 66)
    return 0


if __name__ == "__main__":
    sys.exit(main())
