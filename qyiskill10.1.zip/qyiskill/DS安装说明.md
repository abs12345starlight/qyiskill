# DS Harness 安装记录

**安装日期**：2026-09-27
**安装位置**：`%USERPROFILE%\.dsh\skills\qyiskill\`
**数据版本**：跟帖 50,953 条 / 精华 25,131 条 / 对话版问答 41,250 条 / 截至 2026-09-30

---

## 一、DS 的技能规则（来自 .dsh 官方 skill-authoring）

扫描根目录，按优先级从高到低：

| 级别 | 位置 |
|---|---|
| 100 | `<项目根>\.dsh\skills` （项目级） |
| 400 | `~\.dsh\skills` （用户级，**本次用的这个**） |
| 500 | `~\.agents\skills` |

目录必须长这样：`<扫描根>\<技能名>\SKILL.md`

**关键限制**：
- ❌ **不认 zip** —— 必须解压成目录
- ❌ **不递归扫描** —— `SKILL.md` 若在第一层以下，不会被发现
- ⚠️ frontmatter 不合规会**静默跳过**（只写日志，不报错）

---

## 二、这个技能为什么能直接跑

`工具/公共库.py` 里的路径解析是**自动定位**的，不含写死的绝对路径：

```python
def _self_skill_dir():
    here = os.path.dirname(os.path.abspath(__file__))  # 工具/
    cand = os.path.dirname(here)                       # 技能目录
    if 有 SKILL.md 或 资料/: return cand
```

`get_root()` 的回退链：
```
--root 参数 > 环境变量 TGB_KB_ROOT > 工具/路径配置.txt（且路径须真实存在）
> 技能目录有 资料/ 就用技能目录 > 最后的兜底常量
```

所以在 DS 这边 `get_root()` 自动返回技能目录自身 —— **原地模式**，数据只有一份。

---

## 三、数据分布

```
qyiskill/
├── SKILL.md              技能定义（DS 读这个）
├── 说明.md  移植说明.md  使用手册.html
├── cookie.txt            ← 手动补的，打包时不含
├── 增量状态.json          ← 手动补的，打包时不含
├── 资料/
│   ├── 01_主贴正文/       98 篇
│   ├── 02_跟帖全量/       98 篇（50,953 条）
│   ├── 03_跟帖精华/       98 篇（25,131 条）
│   ├── 04_跟帖对话版/     98 篇（29MB）
│   ├── 跟帖实战速查手册.md
│   ├── 个股与题材速查索引.md
│   ├── 跟帖索引.md  主贴索引.md  主贴清单.txt
└── 工具/
    ├── 检索关键词.py  检索个股.py
    ├── 重建_精华与索引.py  重建_速查手册.py
    ├── 重建_个股题材索引.py  重建_对话版.py
    ├── 公共库.py  安装.py  说明.md
    └── 抓取更新/  抓取更新.py  统计评论页数.py
```

---

## 四、常用命令

Python 解释器（同机共用）：

```
%USERPROFILE%\.workbuddy\binaries\python\envs\default\Scripts\python.exe
```

**检索**（在技能目录下执行）：

```bash
PY="%USERPROFILE%\.workbuddy\binaries\python\envs\default\Scripts\python.exe"

$PY 工具/检索关键词.py 要信早信 --limit 10        # 精华版，默认
$PY 工具/检索关键词.py 节点 --qa                  # 对话版（能看网友提问）
$PY 工具/检索关键词.py "破五|破位" --full          # 全量版
$PY 工具/检索个股.py 红宝丽                       # 按个股查
$PY 工具/检索个股.py 红宝丽 --brief               # 只看月度分布
```

**更新**（推荐用启动器，它会自己判断模式）：

> 默认是**快速模式**：只探「编号最小的 5 篇 + 45 天内有跟帖的帖」，
> **5 秒跑完**。因为博主已「下课」（001 帖标题就是《最后一课…下课》），
> 不会再开新主帖，新跟帖都在最新那篇里；98 篇里 95 篇是陈年老帖。
> 要全量校验时加 `--full-probe`。

```bash
# ✅ 推荐：双击本目录的 更新知识库.cmd
#    或命令行跑启动器
$PY 工具/启动_更新.py              # 增量更新（约 10 秒）
$PY 工具/启动_更新.py --check      # 只体检（约 5 秒）
```

启动器按「自己住在哪」自动选数据：

| 启动器位置 | 使用 |
|---|---|
| `~\.dsh\skills\...\工具\` | DS 这份（原地模式） |
| `~\.workbuddy\skills\...\工具\` | 车间 |
| `车间\工具\` | 车间 |

**手动调用**（必须带 `--inplace --root .`）：

```bash
$PY 工具/抓取更新/抓取更新.py --inplace --root . --check
$PY 工具/抓取更新/抓取更新.py --inplace --root .
```

> ⚠️ `--inplace` 和 `--root` 必须成对给。漏了会走普通模式，去一个不存在的
> 车间路径找数据 —— 症状是体检输出里「本地 → 网站」两个日期**都是空的**，
> 还误报「新帖 98 篇 / 本地缺文件 98 篇」（2026-09-27 踩过）。

### 改密码后怎么恢复

改淘股吧密码会让 cookie 失效（服务器主动作废旧会话，正常的安全设计）。
**数据不会丢，只是不能增量更新**。恢复步骤：

```
1. 把新 cookie 存成一个 txt（一整行，不能有换行）
2. 把这个 txt 拖到本目录的 更新cookie.cmd 上
3. 它会自动备份旧的、写入两处、并跑一次验证
```

拿新 cookie：浏览器 F12 → Application → Cookies → `https://www.tgb.cn`，
复制整串（从 `tgbuser` 到 `showStatus...`）。

---

## 五、与 WorkBuddy 侧的关系

| | WorkBuddy | DS |
|---|---|---|
| 技能目录 | `~\.workbuddy\skills\qyiskill` | `~\.dsh\skills\qyiskill` |
| 数据模式 | 普通模式（车间 + 同步） | 原地模式 |
| 车间 | `WorkBuddy\2026-07-29-10-57-33\` | 无（数据就在技能目录内） |

**两份相互独立**，各自都能读能更新。

**同步方式**：WorkBuddy 侧跑完更新后，重新打包，再解压覆盖 DS 副本：

```bash
# 1. 打新包（WorkBuddy 侧）
cd "%USERPROFILE%\.workbuddy\skills\qyiskill/工具/抓取更新"
$PY -c "import sys; sys.path[:0]=[r'%USERPROFILE%\.workbuddy\skills\qyiskill/工具/抓取更新', r'%USERPROFILE%\.workbuddy\skills\qyiskill/工具']; import 抓取更新 as U; print(U.package(r'%USERPROFILE%\WorkBuddy\2026-07-29-10-57-33', r'%USERPROFILE%\.workbuddy\skills\qyiskill'))"

# 2. 解压覆盖 DS（保留 cookie 和状态文件）
cd "%USERPROFILE%\.dsh\skills"
$PY -c "import zipfile; zipfile.ZipFile(r'%USERPROFILE%\WorkBuddy\2026-07-29-10-57-33/qyiskill.zip').extractall(r'%USERPROFILE%\.dsh\skills/')"
```

> 打包时**自动排除** `cookie.txt` 和 `路径配置.txt`，所以解压不会覆盖掉 DS 的 cookie。

---

## 六、踩坑记录

1. **zip 放着不生效**。最初把 `tgb71skill-v1.4.zip` 直接丢在 `.dsh/skills/`，DS 完全看不到。
2. **`--root` 和 `--inplace` 要成对给**。只给 `--no-sync` 时走普通模式，会去车间找数据。
   表现是体检输出里「本地 → 网站」两个日期都空着。
3. **DS 的 skill 定义字段**与 WorkBuddy 略有差异。已补 `whenToUse` 和 `metadata`，
   两边都能识别（WorkBuddy 忽略未知键）。
