@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion

set "WORK=%~dp0"
set "WORK=%WORK:~0,-1%"
set "SKILL=%USERPROFILE%\.workbuddy\skills\qyiskill"
set "DSDIR=%USERPROFILE%\.dsh\skills\qyiskill"
set "PY=%USERPROFILE%\.workbuddy\binaries\python\envs\default\Scripts\python.exe"
if not exist "%PY%" set "PY=python"

echo ============================================================
echo   见股起意知识库 - 更新 cookie
echo ============================================================
echo.

set "SRC=%~1"
if "%SRC%"=="" (
    echo 用法：把这个 .cmd 拖到一个「新 cookie 文本文件」上。
    echo.
    echo 拿到新 cookie 的步骤：
    echo   1. 去 https://www.tgb.cn 用新密码登录
    echo   2. 按 F12 -^> Application -^> Cookies -^> https://www.tgb.cn
    echo   3. 把整串 cookie 复制出来（从 tgbuser 到 showStatus...）
    echo   4. 粘进一个 txt 存好（必须一整行，不能有换行）
    echo   5. 把那个 txt 拖到本文件上
    echo.
    pause
    exit /b 1
)

if not exist "%SRC%" (
    echo [错误] 找不到文件：%SRC%
    pause
    exit /b 1
)

for /f "tokens=1-6 delims=/: " %%a in ("%date% %time%") do set "STAMP=%%c%%b%%a-%%d%%e"

echo [1/5] 备份现有 cookie ...
if exist "%WORK%\cookie.txt" (
    copy /y "%WORK%\cookie.txt" "%WORK%\cookie.txt.bak-!STAMP!" >nul
    echo       车间 -^> cookie.txt.bak-!STAMP!
) else (
    echo       车间无 cookie，跳过
)
if exist "%DSDIR%\cookie.txt" (
    copy /y "%DSDIR%\cookie.txt" "%DSDIR%\cookie.txt.bak-!STAMP!" >nul
    echo       DS   -^> cookie.txt.bak-!STAMP!
)
echo.

echo [2/5] 写入新 cookie ...
copy /y "%SRC%" "%WORK%\cookie.txt" >nul
if errorlevel 1 (
    echo [错误] 写入车间失败
    pause
    exit /b 1
)
echo       车间 -^> %WORK%\cookie.txt
echo.

echo [3/5] 同步到技能目录与 DS ...
if exist "%SKILL%\工具\" (
    copy /y "%SRC%" "%SKILL%\cookie.txt" >nul
    echo       技能目录 -^> %SKILL%\cookie.txt
) else (
    echo       未找到技能目录，跳过
)
if exist "%DSDIR%\工具\" (
    copy /y "%SRC%" "%DSDIR%\cookie.txt" >nul
    echo       DS       -^> %DSDIR%\cookie.txt
) else (
    echo       未找到 DS 目录，跳过
)
echo.

echo [4/5] 验证 cookie（约 15 秒）...
echo.
"%PY%" "%SKILL%\工具\抓取更新\抓取更新.py" --check --quick 1 --no-sync --no-package
set "RC=!errorlevel!"
echo.
if !RC! GEQ 2 (
    echo [!] 验证失败：cookie 无效，或账号未实名认证。
    echo.
    echo   已写入的文件都保留了备份，修好后重跑本脚本即可。
    echo   注意：本地数据完好，检索不受影响。
    pause
    exit /b 2
)

echo [5/5] 完成。
echo.
echo   想立刻拉最新数据，双击：更新知识库.cmd
echo.
pause
