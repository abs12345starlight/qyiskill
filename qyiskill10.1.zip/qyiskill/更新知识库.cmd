@echo off
chcp 65001 >nul
set "PY=%USERPROFILE%\.workbuddy\binaries\python\envs\default\Scripts\python.exe"
if not exist "%PY%" set "PY=python"
echo ============================================================
echo   见股起意知识库 - 一键增量更新
echo ============================================================
"%PY%" "%USERPROFILE%\.workbuddy\skills\qyiskill\工具\启动_更新.py" %*
echo.
pause
