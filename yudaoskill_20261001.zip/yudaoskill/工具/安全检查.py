#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""安全检查 —— 发布前自检：确认知识库里没有会话凭证、账号标识与本机隐私。

用法：
    python3 工具/安全检查.py                    # 扫本 skill 本体
    python3 工具/安全检查.py path/to/包.zip ...  # 额外扫指定的 zip

退出码：0 = 全部通过；1 = 发现可疑内容（详见输出）。

为什么需要它（2026-10-01 教训）
--------------------------------
本库曾把一整套真实会话凭证（含 `tgbpwd` 密码哈希）**硬编码在两个抓取脚本里**，
样例 HTML 里也留着登录态（loginUserID / loginUserName），
另有一个 700 KB 的 `_raw_*.html` 残留没清。
这些一旦随 skill 或导出包分发出去，等于把账号交出去。
所以定下规矩：**凭证一律不落库**（只从环境变量或 skill 目录外的文件读），
并在每次发布前跑一遍本脚本。
"""
import os
import re
import sys
import zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.normpath(os.path.join(HERE, '..'))          # skill 根
SELF = os.path.basename(os.path.abspath(__file__))

# 只扫文本类文件；二进制跳过
TEXT_EXT = {'.md', '.py', '.html', '.htm', '.txt', '.json', '.csv', '.yaml', '.yml'}

# ------------------------------------------------------------------
# 检测规则：命中即视为「需要处理」
# 注意不要把本脚本自身算进去（规则字符串会自匹配），已用 SELF 排除。
# ------------------------------------------------------------------
CHECKS = [
    ('会话凭证（赋值形式）',
     r'(?:JSESSIONID|acw_tc|tgbpwd|tgbuser|loginStatus)\s*=\s*[A-Za-z0-9]'),
    ('HTTP Cookie 请求头（带实际值）',
     r'Cookie\s*[:：]\s*(?:acw_tc|JSESSIONID|tgbuser|tgbpwd|session|sid|token)\s*='),
    ('curl 的 -b 传 Cookie',
     r"['\"]-b['\"]\s*,\s*['\"][^'\"]{20,}['\"]"),
    ('页面登录态字段（带真实值）',
     'loginUserI[Dd]\\s*=\\s*["\']?(?!0\\b)\\d'
     '|loginUserNam[Ee]\\s*=\\s*["\'](?!tester|test\\b)[^"\']{2,}["\']'
     '|id="userID"[^>]*value="(?!0["\'])[^"\']+"'),
    ('本机绝对路径（含用户名）',
     r'[A-Za-z]:[\\/]+Users[\\/]+(?!<)[^\\/\s\'"）】]+'),
    ('手机号',
     r'(?<!\d)1[3-9]\d{9}(?!\d)'),
    ('身份证号',
     r'(?<!\d)\d{17}[\dXx](?!\d)'),
]

# 明确不构成风险、需要静音的噪音（如论坛官方客服邮箱、常见英文词）
WHITELIST = [
    r'taoguba\d*@taoguba\.com',        # 淘股吧官方客服邮箱（页面模板自带）
    r'\btoken\b',                      # 英文单词，非凭证
]


def strip_whitelist(text):
    for pat in WHITELIST:
        text = re.sub(pat, ' ', text, flags=re.I)
    return text


def scan_text(name, text, out):
    text = strip_whitelist(text)
    for label, pat in CHECKS:
        for m in re.finditer(pat, text, re.I):
            frag = text[max(0, m.start() - 45):m.end() + 45].replace('\n', ' ⏎ ')
            out.append((name, label, m.group(0)[:60], frag[:150]))


def scan_tree(root, out):
    n = 0
    for dirpath, dirs, files in os.walk(root):
        dirs[:] = [d for d in dirs if d not in ('__pycache__', '.git')]
        for f in sorted(files):
            if f == SELF:
                continue
            ext = os.path.splitext(f)[1].lower()
            if ext not in TEXT_EXT:
                continue
            p = os.path.join(dirpath, f)
            rel = os.path.relpath(p, root)
            try:
                scan_text(rel, open(p, encoding='utf-8', errors='ignore').read(), out)
            except OSError:
                pass
            n += 1
    return n


def scan_zip(path, out):
    z = zipfile.ZipFile(path)
    tag = os.path.basename(path)
    for n in z.namelist():
        if os.path.splitext(n)[1].lower() not in TEXT_EXT:
            continue
        scan_text(f'{tag} :: {n}', z.read(n).decode('utf-8', 'ignore'), out)
    return len(z.namelist())


def main():
    targets = sys.argv[1:]
    hits = []
    print('=' * 70)
    print('安全检查 · yudaoskill')
    print('=' * 70)
    print(f'扫描 skill 本体：{ROOT}')
    n = scan_tree(ROOT, hits)
    print(f'  已扫 {n} 个文本文件')
    for t in targets:
        if os.path.isfile(t):
            m = scan_zip(t, hits)
            print(f'扫描压缩包：{os.path.basename(t)}（{m} 条目）')
        else:
            print(f'  !! 跳过（不存在）：{t}')

    print()
    if not hits:
        print('✅ 通过：未发现会话凭证、账号标识或本机隐私。')
        return 0

    print(f'❌ 发现 {len(hits)} 处可疑内容，发布前必须处理：')
    cur = None
    for name, label, val, frag in hits:
        if label != cur:
            cur = label
            print(f'\n【{label}】')
        print(f'   · {name[:64]}')
        print(f'       命中值: {val}')
        print(f'       上下文: {frag}')
    print()
    print('提示：凭证不要写进脚本或知识库 —— 放到环境变量 TGB_COOKIE，')
    print('      或 skill 目录之外的 ~/.workbuddy/tgb_cookie.txt。')
    return 1


if __name__ == '__main__':
    sys.exit(main())
