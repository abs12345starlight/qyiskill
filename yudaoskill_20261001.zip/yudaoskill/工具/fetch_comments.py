#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
郁金香知识库 · 淘股吧 博主「跟帖」爬取脚本
=========================================

背景
----
网页端「只看该作者」接口（/topic/lookUserTopic）是**积分付费**功能，抓到第 4 篇
积分就耗光，且失败时 HTTP 仍返回 200（页面内容是「淘股吧_积分不够」），属于静默失败。
因此本脚本采用**免费方案**：普通评论分页 `/a/{postId}-{pageNo}`，每页条数不固定
（实测 44~49 条，pageSize 参数无效），本地按作者 ID 筛选博主跟帖。

产出
----
每篇主贴生成一个跟帖 Markdown，存入 知识库/comments/：

    NN_标题_跟帖.md

每条跟帖保留：时间 / 被引用的原评论（上下文）/ 博主回复正文。
被引用部分以 Markdown 引用块形式保留，便于还原「问→答」语境。

用法
----
  python3 fetch_comments.py survey          # 普查：每篇总页数 + 预估请求量（只读第1页）
  python3 fetch_comments.py check --last 3  # 体检「发布时间最新」的 3 篇（★ 日常增量用这条）
  python3 fetch_comments.py check           # 体检全库 61 篇（约 6 秒）
  python3 fetch_comments.py one 53          # 只抓第 53 篇（验证用）
  python3 fetch_comments.py all             # 全量抓取（可断点续传，已完成的会跳过）
  python3 fetch_comments.py all --force     # 忽略已有产出，强制重抓
  python3 fetch_comments.py index           # 仅重建 comments/INDEX.md

增量更新建议
------------
1) `check --last 3` —— 只查最近 3 篇。它一次同时看「页数变化」与「末页最新博主回复」，
   两类更新都能兜住，所以快速模式下不必再跑 survey（survey 只比页数，会漏未满页的新增）。
2) 命中的篇目 `one N --force` 重抓（比 `all --force` 快得多）。
3) 重建 gems：`build_index.py`。
`one` / `all` 会自动重建 comments/INDEX.md，但 gems/ 分册需另跑 build_index.py。

Cookie
------
同 fetch_tgb.py：优先读环境变量 TGB_COOKIE，回退到本文件内会话（会过期）。
"""

import re
import os
import sys
import html
import glob
import time
import random
import subprocess
from concurrent.futures import ThreadPoolExecutor, as_completed

# ============================ 配置 ============================
BLOG_UID = '10016726'          # 博主 userID，用于筛选跟帖
BLOG_NAME = '郁金香5678'

# ⚠️ 本脚本**不内置任何 Cookie**（凭证不入库、不随 skill 分发）。
# 淘股吧需登录态才能拿到完整正文，按以下顺序取：
#   1) 环境变量 TGB_COOKIE
#   2) 本地文件 ~/.workbuddy/tgb_cookie.txt（在 skill 目录**之外**，不会被分发）
# 获取方法：浏览器登录 tgb.cn → DevTools → Network → 任意请求 → 复制 Cookie 请求头
COOKIE = os.environ.get('TGB_COOKIE', '').strip()
if not COOKIE:
    _ck = os.path.expanduser('~/.workbuddy/tgb_cookie.txt')
    if os.path.exists(_ck):
        try:
            COOKIE = open(_ck, encoding='utf-8').read().strip()
        except OSError:
            pass

_cookie_warned = False


def ensure_cookie():
    """COOKIE 为空时提示一次，方便快速定位失败原因。"""
    global _cookie_warned
    if not COOKIE and not _cookie_warned:
        _cookie_warned = True
        print('[!] 未设置 TGB_COOKIE 环境变量 —— 淘股吧需要登录态，'
              '本次请求会失败。请按脚本头部说明设置后重试。')
    return bool(COOKIE)



HEADERS = [
    'accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'accept-language: zh-CN,zh;q=0.9',
    'referer: https://www.tgb.cn/blog/10016726',
    'user-agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36',
]

# 知识库目录：优先 YUDAO_KB_DIR，其次旧名 TGB_KB_DIR（保留兼容），最后取同级的「知识库/」
KB_DIR = (os.environ.get('YUDAO_KB_DIR')
          or os.environ.get('TGB_KB_DIR')
          or os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                           '..', '知识库')))
TITLES_MD = os.path.join(KB_DIR, 'tgb_posts_titles.md')
OUT_DIR = os.path.join(KB_DIR, 'comments')

MAX_WORKERS = int(os.environ.get('TGB_COMMENT_WORKERS', '8'))
RETRY = 2
TIMEOUT = 40

# 真正的静默失败页特征（出现在 <title> 里，非页面 JS 文案）
FAIL_TITLES = ['积分不够', '积分不足', '登录_淘股吧', '用户登陆']
# 正向校验：有效评论页必然含评论容器
MUST_HAVE = 'comment-lists'


# ============================ 基础工具 ============================
def curl_text(url, timeout=TIMEOUT):
    ensure_cookie()
    """GET url，返回 (ok, text)。

    注意：页面 JS 里本就存在「您的积分不足，请确认」等红包功能文案，
    因此不能用关键词反查，改用「是否含评论容器」做正向校验，
    并辅以 <title> 判定真正的积分耗尽 / 登录跳转页。
    """
    cmd = ['curl', url, '-s', '-w', '\n__HTTP__%{http_code}', '-b', COOKIE]
    for h in HEADERS:
        cmd += ['-H', h]
    cmd += ['--max-time', str(timeout)]
    try:
        r = subprocess.run(cmd, capture_output=True, timeout=timeout + 10)
        raw = r.stdout.decode('utf-8', errors='ignore')
    except Exception:
        return False, ''
    m = re.search(r'__HTTP__(\d+)\s*$', raw.strip())
    code = m.group(1) if m else '000'
    text = raw[:m.start()] if m else raw
    if code != '200' or len(text) < 5000:
        return False, text
    tm = re.search(r'<title[^>]*>(.*?)</title>', text, re.S | re.I)
    title = html.unescape(tm.group(1)).strip() if tm else ''
    for tok in FAIL_TITLES:
        if tok in title:
            return False, text
    if MUST_HAVE and MUST_HAVE not in text:
        return False, text
    return True, text


def get_page(url, tries=RETRY):
    for i in range(tries):
        ok, txt = curl_text(url)
        if ok:
            return txt
        time.sleep(0.6 * (i + 1) + random.random() * 0.4)
    return None


def div_inner(h, start):
    """从 start（指向 <div 的 '<'）做 div 标签平衡，返回内部 HTML（失败返回 None）。"""
    tag_re = re.compile(r'<(/\s*)?div\b[^>]*>', re.I)
    m0 = tag_re.search(h, start)
    if not m0 or m0.group(1):
        return None
    content_start = m0.end()
    depth, pos = 1, m0.end()
    while True:
        m = tag_re.search(h, pos)
        if not m:
            return None
        if m.group(1):
            depth -= 1
            if depth == 0:
                return h[content_start:m.start()]
        else:
            depth += 1
        pos = m.end()


def strip_tags(s):
    """HTML 片段 → 纯文本（保留图片链接与换行）。"""
    s = re.sub(r'<br\s*/?>', '\n', s, flags=re.I)
    s = re.sub(r'</(p|div|li|blockquote|h\d)>', '\n', s, flags=re.I)
    s = re.sub(r'<img[^>]*?\bsrc="([^"]+)"[^>]*?/?>', lambda m: f'\n![]({m.group(1)})\n', s, flags=re.I)
    s = re.sub(r'<[^>]+>', '', s)
    s = html.unescape(s)
    s = re.sub(r'[ \t\u00a0]+', ' ', s)
    lines = [ln.strip() for ln in s.splitlines()]
    out, blank = [], 0
    for ln in lines:
        if ln == '':
            blank += 1
            if blank <= 1:
                out.append('')
        else:
            blank = 0
            out.append(ln)
    return '\n'.join(out).strip()


# ============================ 评论解析 ============================
BLOCK_RE = re.compile(r'<div class="comment-data user_(\d+)"', re.I)


def parse_page(text, only_uid=BLOG_UID):
    """解析一页评论，返回本页全部评论 dict 列表（按出现顺序）。"""
    if not text:
        return []
    cstart = text.find('comment-lists list-reply')
    if cstart == -1:
        return []
    seg = text[cstart:]

    starts = [(m.start(), m.group(1)) for m in BLOCK_RE.finditer(seg)]
    if not starts:
        return []

    out = []
    for k, (pos, uid) in enumerate(starts):
        end = starts[k + 1][0] if k + 1 < len(starts) else len(seg)
        block = seg[pos:end]

        # 正文（comment-data-text）
        body = ''
        mt = re.search(r'<div class="comment-data-text"[^>]*>', block)
        if mt:
            inner = div_inner(block, mt.start())
            if inner is not None:
                body = strip_tags(inner)

        # 引用（comment-data-quote，博主回复别人的上下文）
        quote_name, quote_text, quote_time = '', '', ''
        mq = re.search(r'<div class="comment-data-quote"[^>]*>', block)
        if mq:
            qinner = div_inner(block, mq.start())
            if qinner is not None:
                nm = re.search(r'class="cursor[^"]*"[^>]*>\s*([^<]+?)\s*</a>', qinner)
                if nm:
                    quote_name = html.unescape(nm.group(1)).strip()
                qtm = re.search(r'(\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2})', qinner)
                if qtm:
                    quote_time = qtm.group(1).strip()
                # 正文容器：<p class="quote-content data-quote-text">…</p>
                qt = re.search(r'<(\w+)[^>]*class="[^"]*data-quote-text[^"]*"[^>]*>(.*?)</\1>',
                               qinner, re.S | re.I)
                if qt:
                    quote_text = strip_tags(qt.group(2))
                if not quote_text:
                    rest = re.sub(r'<a\b[^>]*>.*?</a>', ' ', qinner, flags=re.S)
                    rest = re.sub(r'\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}', ' ', rest)
                    quote_text = strip_tags(rest)

        # 时间 / 用户名
        tm = re.search(r'<span class="pcyclspan[^"]*"[^>]*>\s*([\d\-]{8,10}[\d: ]*)\s*</span>', block)
        ctime = tm.group(1).strip() if tm else ''
        nm = re.search(r'class="user-name[^"]*"[^>]*>\s*([^<]+?)\s*</a>', block)
        uname = html.unescape(nm.group(1)).strip() if nm else ''

        if only_uid and uid != only_uid:
            continue
        if not body and not quote_text:
            continue
        out.append({'uid': uid, 'name': uname, 'time': ctime, 'text': body,
                    'quote_name': quote_name, 'quote_text': quote_text,
                    'quote_time': quote_time})
    return out


def get_total_pages(text):
    """从页面取评论总页数；无分页控件则视为 1 页。"""
    if not text:
        return 0
    m = re.findall(r'data-page-num="(\d+)"', text)
    if m:
        try:
            return max(int(x) for x in m)
        except ValueError:
            pass
    return 1


# ============================ 目录读取 ============================
def read_posts():
    """读取「编号 / 标题 / 来源链接」，**以主贴正文文件名 `NN_*.md` 为准**。返回按编号升序。

    ⚠️ **编号不是时间顺序**（2026-10-01 踩坑，务必记住）：
      首次建库（2026-07-29）按当时博客列表的**日期倒序**编号 ——
        01 = 26.6.23（当时最新）… 60 = 24.4.8「新号首帖」（最老）；
      此后增量抓到的新帖续接在 61、62…（目前 61 = 26.8.19《内驱与外驱》，是最新一篇）。
      → 所以「最近 N 篇」**不能取编号尾部**，要按发布时间排序，用 `read_posts_dated()`。

    ⚠️ 也不要改回读 tgb_posts_titles.md：该目录由 fetch_tgb.py 的 write_catalog()
    按日期倒序重写（1 = 最新帖），与文件名编号不是一回事。
    历史教训：2026-09-15 跑 survey 时，误把它当编号来源，61 篇页数全部错位一位。
    """
    posts = []
    if not os.path.isdir(KB_DIR):
        return posts
    for fn in sorted(os.listdir(KB_DIR)):
        m = re.match(r'^(\d{2})_(.*)\.md$', fn)
        if not m:
            continue
        url = ''
        try:
            with open(os.path.join(KB_DIR, fn), encoding='utf-8', errors='ignore') as fh:
                for ln in fh:
                    if ln.startswith('- 来源：'):
                        url = ln.split('：', 1)[1].strip()
                        break
        except OSError:
            pass
        if not url.startswith('https://www.tgb.cn/a/'):
            continue
        posts.append((int(m.group(1)), m.group(2), url))
    posts.sort()
    return posts


def read_posts_dated():
    """同 `read_posts()`，但额外带回主贴的「发布时间」，并按时间倒序返回。

    专门用于「最近 N 篇」这类需求 —— 因为**编号不等于时间顺序**（见 read_posts
    的说明）。`cmd_check(last=N)` 依赖它，别再改回用编号切片。
    """
    out = []
    for idx, title, url in read_posts():
        date = ''
        for fn in os.listdir(KB_DIR):
            if fn.startswith(f'{idx:02d}_') and fn.endswith('.md'):
                try:
                    with open(os.path.join(KB_DIR, fn), encoding='utf-8', errors='ignore') as fh:
                        for ln in fh:
                            if ln.startswith('- 发布时间：'):
                                date = ln.split('：', 1)[1].strip()
                                break
                except OSError:
                    pass
                break
        out.append((idx, title, url, date))
    out.sort(key=lambda r: r[3] or '', reverse=True)
    return out


def sanitize(name):
    name = name.replace('&nbsp;', ' ').replace('\u00a0', ' ')
    for c in '/\\:*"<>|':
        name = name.replace(c, '_')
    return name.strip()[:60]


def write_comments_index():
    """重建 comments/INDEX.md（条数/页数取各跟帖文件头部，链接取主贴正文）。"""
    meta = {i: (t, u) for i, t, u in read_posts()}
    rows, total = [], 0
    for fn in sorted(os.listdir(OUT_DIR)):
        m = re.match(r'^(\d{2})_(.*)_跟帖\.md$', fn)
        if not m:
            continue
        idx = int(m.group(1))
        head = open(os.path.join(OUT_DIR, fn), encoding='utf-8').read(700)
        mn = re.search(r'- 跟帖条数：(\d+)', head)
        mp = re.search(r'- 评论总页数：(\d+)', head)
        n = int(mn.group(1)) if mn else 0
        pg = int(mp.group(1)) if mp else 0
        t, u = meta.get(idx, (m.group(2), ''))
        rows.append((idx, t, n, pg, fn))
        total += n
    rows.sort()
    idx_path = os.path.join(OUT_DIR, 'INDEX.md')
    with open(idx_path, 'w', encoding='utf-8') as f:
        f.write(f'# {BLOG_NAME} 跟帖合集（共 {len(rows)} 篇，{total} 条）\n\n')
        f.write('> 跟帖 = 博主在主贴评论区回复网友的实战问答，含「网友提问 → 博主回答」上下文。\n')
        f.write('> 正文见上级目录；检索时建议两个目录一起搜。\n\n')
        f.write('| # | 主贴标题 | 跟帖条数 | 评论页数 | 文件 |\n')
        f.write('|---|---------|---------|---------|------|\n')
        for idx, t, n, pg, fn in rows:
            f.write(f'| {idx:02d} | [{t}]({u}) | {n} | {pg} | {fn} |\n')
    return idx_path, len(rows), total


# ============================ 单篇抓取 ============================
def fetch_post_comments(idx, title, url, force=False):
    """抓一篇主贴的全部博主跟帖，返回 (md_path, 跟帖条数, 页数)。"""
    os.makedirs(OUT_DIR, exist_ok=True)
    pid = url.rstrip('/').split('/')[-1]
    md_name = f'{idx:02d}_{sanitize(title)}_跟帖.md'
    md_path = os.path.join(OUT_DIR, md_name)
    if os.path.exists(md_path) and not force:
        try:
            head = open(md_path, encoding='utf-8').read(400)
            m = re.search(r'- 跟帖条数：(\d+)', head)
            if m and '抓取中断' not in head:
                return md_path, int(m.group(1)), 0
        except Exception:
            pass

    first = get_page(f'https://www.tgb.cn/a/{pid}-1')
    if first is None:
        return None, 0, 0
    total = get_total_pages(first)

    results = {1: parse_page(first)}
    if total > 1:
        def work(p):
            t = get_page(f'https://www.tgb.cn/a/{pid}-{p}')
            return p, (parse_page(t) if t else [])
        with ThreadPoolExecutor(max_workers=MAX_WORKERS) as ex:
            futs = [ex.submit(work, p) for p in range(2, total + 1)]
            for fut in as_completed(futs):
                p, items = fut.result()
                results[p] = items

    # 按页序 + 页内原序拼接，保持时间线
    all_items = []
    for p in sorted(results):
        all_items.extend(results[p])

    # 去重（同时间+同正文）
    seen, uniq = set(), []
    for it in all_items:
        key = (it['time'], it['text'][:80])
        if key in seen:
            continue
        seen.add(key)
        uniq.append(it)

    with open(md_path, 'w', encoding='utf-8') as f:
        f.write(f'# {title} · {BLOG_NAME} 跟帖\n\n')
        f.write(f'- 主贴：{url}\n')
        f.write(f'- 跟帖条数：{len(uniq)}\n')
        f.write(f'- 评论总页数：{total}\n')
        f.write(f'- 抓取时间：{time.strftime("%Y-%m-%d %H:%M")}\n\n---\n\n')
        if not uniq:
            f.write('（本贴未抓到博主跟帖）\n')
        for it in uniq:
            f.write(f'### {it["time"] or "（时间未知）"}\n\n')
            if it['quote_text']:
                who = it['quote_name'] or '（网友）'
                if it['quote_time']:
                    who += f'（{it["quote_time"]}）'
                qt = it['quote_text'].replace('\n', '\n> ')
                f.write(f'> **{who}**：{qt}\n\n')
            f.write(f'{it["text"]}\n\n')
    return md_path, len(uniq), total


# ============================ 命令 ============================
def cmd_survey():
    posts = read_posts()
    print(f'普查 {len(posts)} 篇主贴的评论总页数（每篇只读第 1 页）...\n')
    rows = []
    t0 = time.time()
    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as ex:
        futs = {ex.submit(get_page, f'https://www.tgb.cn/a/{u.rstrip("/").split("/")[-1]}-1'): (i, t)
                for i, t, u in posts}
        for fut in as_completed(futs):
            i, t = futs[fut]
            txt = fut.result()
            pages = get_total_pages(txt) if txt else 0
            mine = len(parse_page(txt)) if txt else 0
            rows.append((i, t, pages, mine))
    rows.sort()
    total_pages = sum(r[2] for r in rows)
    total_mine = sum(r[3] for r in rows)
    for i, t, pages, mine in rows:
        print(f'  [{i:02d}] {pages:5} 页  第1页含博主 {mine:3} 条  {t[:34]}')
    print(f'\n合计：评论总页数 ≈ {total_pages} 页')
    print(f'      第1页已含博主跟帖 {total_mine} 条（全量预估 ≈ {int(total_mine * total_pages / max(len(rows),1))} 条）')
    print(f'      按 {MAX_WORKERS} 并发、每页 ~1.5s 估算：约 {total_pages / MAX_WORKERS * 1.5 / 60:.0f} 分钟')
    print(f'      普查耗时 {time.time()-t0:.1f}s')


def cmd_one(idx, force=False):
    posts = {i: (t, u) for i, t, u in read_posts()}
    if idx not in posts:
        print(f'未找到编号 {idx} 的主贴')
        return
    t, u = posts[idx]
    print(f'抓取 [{idx:02d}] {t} ...')
    t0 = time.time()
    md, n, pages = fetch_post_comments(idx, t, u, force=force)
    print(f'完成：{pages} 页，博主跟帖 {n} 条，耗时 {time.time()-t0:.1f}s')
    print(f'输出：{md}')
    ip, cnt, tot = write_comments_index()
    print(f'已重建 {ip}：{cnt} 篇 / {tot} 条')
    print('提醒：跟帖有更新后需再跑 build_index.py 重建 gems/ 与 TOPICS.md。')


def cmd_all(force=False):
    posts = read_posts()
    if not posts:
        print('目录为空，请先运行 fetch_tgb.py sync')
        return
    os.makedirs(OUT_DIR, exist_ok=True)
    print(f'开始抓取 {len(posts)} 篇主贴的博主跟帖（并发 {MAX_WORKERS}）...\n')
    t0 = time.time()
    done = 0
    total_mine = 0
    for i, t, u in posts:
        md, n, pages = fetch_post_comments(i, t, u, force=force)
        done += 1
        total_mine += n
        print(f'  [{i:02d}/{len(posts)}] {pages:5}页 跟帖{n:4}条  {t[:30]}')
    print(f'\n全部完成：{done} 篇，博主跟帖合计 {total_mine} 条，'
          f'耗时 {(time.time()-t0)/60:.1f} 分钟')
    print(f'输出目录：{OUT_DIR}')
    ip, cnt, tot = write_comments_index()
    print(f'已重建 {ip}：{cnt} 篇 / {tot} 条')
    print('提醒：跟帖有更新后需再跑 build_index.py 重建 gems/ 与 TOPICS.md。')


# ============================ 增量体检（补 survey 的盲区） ============================
def post_id_of(url):
    m = re.search(r'/a/([A-Za-z0-9_\-]+)', url)
    return m.group(1) if m else ''


def _probe_last_page(rec):
    """探测一篇：先取**当前**总页数，再抓当前末页，取最新博主回复与最新任意回复。

    ⚠️ 必须用**当前**页数去抓末页。若直接用库内记录的页数，而帖子此后涨了页，
    抓到只是旧的中间页，会把「其实有大量新增」误判成「无更新」（2026-10-01 修）。

    返回 (编号, 标题, 发布时间, 库内页数, 当前页数, 抓取时间, 末页最新博主回复, 末页最新任意评论)
    """
    idx, title, url, lib_pages, snap, date = rec
    pid = post_id_of(url)
    if not pid:
        return (idx, title, date, lib_pages, 0, snap, None, None)
    first = get_page(f'https://www.tgb.cn/a/{pid}-1')
    if not first:
        return (idx, title, date, lib_pages, 0, snap, None, None)
    cur = get_total_pages(first) or lib_pages
    txt = first if cur == 1 else get_page(f'https://www.tgb.cn/a/{pid}-{cur}')
    if not txt:
        return (idx, title, date, lib_pages, cur, snap, None, None)
    mine = max((x['time'] for x in parse_page(txt)), default='')
    anys = max((x['time'] for x in parse_page(txt, only_uid=None)), default='')
    return (idx, title, date, lib_pages, cur, snap, mine, anys)


def cmd_check(last=0):
    """体检：找出需要重抓的篇目。**日常增量跑这一条就够，不必先 survey。**

    每篇抓 2 个请求（第 1 页取当前总页数 + 当前末页），判定规则：

      ★ 页数变化   当前页数 ≠ 库内记录      → 一定有大段新增，必须重抓
      ★ 有新回复   末页博主回复晚于抓取时间 → 新增不足一页，同样要重抓
      ? 待确认     末页无博主、但网友有新发言 → 建议人工翻一下前一两页
      — 无更新

    `last=N` 取**发布时间最新的 N 篇**，注意**不是编号最大的 N 篇** —— 编号是首次
    建库时按日期倒序编的（01 最新、60 最老），与时间顺序无关，见 read_posts 说明。
    日常增量推荐 `--last 3`（博主活跃的基本只有最新那一两篇）。
    """
    posts = read_posts_dated()
    recs = []
    for idx, title, url, date in posts:
        fs = sorted(glob.glob(os.path.join(OUT_DIR, f'{idx:02d}_*.md')))
        if not fs:
            continue
        with open(fs[0], encoding='utf-8', errors='ignore') as fh:
            head = fh.read(900)
        mp = re.search(r'- 评论总页数：(\d+)', head)
        ms = re.search(r'- 抓取时间：([0-9\-: ]+)', head)
        recs.append((idx, title, url, int(mp.group(1)) if mp else 1,
                     ms.group(1).strip() if ms else '', date))
    if not recs:
        print('未找到跟帖文件，请先跑 survey / all')
        return
    recs.sort(key=lambda r: r[5] or '', reverse=True)   # 按发布时间倒序
    if last > 0:
        recs = recs[:last]
        print('最近 %d 篇（按发布时间）：%s' % (
            len(recs), '、'.join(f'{r[0]:02d} {r[5][:10]}' for r in recs)))
    print(f'探测 {len(recs)} 篇（每篇 2 个请求，并发 {MAX_WORKERS}）...')
    t0 = time.time()
    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as ex:
        res = list(ex.map(_probe_last_page, recs))
    need, maybe = [], []
    print()
    print('编号  发布时间     库内→当前页   抓取时间           末页最新博主回复      末页最新评论          篇名')
    for idx, title, date, lib_pages, cur, snap, mine, anys in res:
        if not cur:
            status = '抓取失败'
        elif cur != lib_pages:
            status = f'★ 页数变化 {lib_pages}→{cur}'
            need.append(idx)
        elif mine and snap and mine > snap:
            status = '★ 有新回复'
            need.append(idx)
        elif not mine and anys and snap and anys > snap:
            status = '? 待确认'
            maybe.append(idx)
        else:
            status = '—'
        print(f'  {idx:02d}  {date[:10]:11s} {lib_pages:4d} → {cur:4d}   {snap:18s} '
              f'{str(mine):20s} {str(anys):20s} {title[:16]:16s} {status}')
    print()
    print(f'耗时 {time.time() - t0:.1f}s')
    if need:
        print(f'需重抓的篇目：{need}')
        for i in need:
            print(f'  python3 工具/fetch_comments.py one {i} --force')
    else:
        print('无需重抓。')
    if maybe:
        print(f'待人工确认（末页无博主但有新网友发言）：{maybe}')


if __name__ == '__main__':
    arg = sys.argv[1] if len(sys.argv) > 1 else 'survey'
    force = '--force' in sys.argv
    last = 0
    if '--last' in sys.argv:
        _i = sys.argv.index('--last')
        if _i + 1 < len(sys.argv) and sys.argv[_i + 1].isdigit():
            last = int(sys.argv[_i + 1])
    if arg == 'survey':
        cmd_survey()
    elif arg == 'one':
        cmd_one(int(sys.argv[2]) if len(sys.argv) > 2 else 1, force)
    elif arg == 'all':
        cmd_all(force)
    elif arg == 'check':
        cmd_check(last)
    elif arg == 'index':
        ip, cnt, tot = write_comments_index()
        print(f'已重建 {ip}：{cnt} 篇 / {tot} 条')
    else:
        print(__doc__)
