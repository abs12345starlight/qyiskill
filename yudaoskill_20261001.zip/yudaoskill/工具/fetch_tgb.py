#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
郁金香知识库 · 淘股吧(郁金香5678) 主贴爬取脚本
===============================================

功能
----
1. `sync`    —— 增量同步：拉取博主最新博客列表，只抓取知识库中还没有的新文章。
2. `list`    —— 仅打印当前博客列表（标题 / 回复数 / 日期 / 链接），不下载正文。
3. `all`     —— 按 知识库/tgb_posts_titles.md 目录，全量重抓所有主贴。
4. `reconvert` —— 用已下载的 _raw_*.html 重新生成 markdown（不改网络）。
5. `test`    —— 用本地样例 HTML 验证「列表解析」与「正文提取」逻辑（离线，无需 cookie）。

博主
----
- 淘股吧用户：郁金香5678
- userID：10016726
- 博客首页：https://www.tgb.cn/blog/10016726

Cookie 说明（重要）
------------------
淘股吧需登录态才能拿到完整正文。脚本优先读取环境变量 TGB_COOKIE；
若未设置则回退到本文件内 COOKIE（为你本机 2026-07-28 抓取的会话，会过期）。
Cookie 过期后脚本会返回 200 但正文为空/被重定向到登录页，此时请：
  1. 浏览器登录 tgb.cn，打开 DevTools → Network → 任意请求 → 复制 Cookie 请求头；
  2. 导出环境变量： export TGB_COOKIE="acw_tc=...; ..."
  3. 或直接修改本文件顶部 COOKIE。

用法
----
  python3 fetch_tgb.py sync
  python3 fetch_tgb.py list
  python3 fetch_tgb.py all
  python3 fetch_tgb.py test
"""

import re
import html
import os
import sys
import time
import subprocess
from concurrent.futures import ThreadPoolExecutor, as_completed

# ============================ 配置 ============================
BLOG_UID = '10016726'
BLOG_NAME = '郁金香5678'
LIST_URL = f'https://www.tgb.cn/user/blog/moreTopic?userID={BLOG_UID}'

# Cookie：见下方 COOKIE 块（取自环境变量或 skill 目录外的本地文件，脚本不内置凭证）
# ⚠️ 本脚本**不内置任何 Cookie**（凭证不入库、不随 skill 分发）。
# 淘股吧需登录态才能拿到完整正文，按以下顺序取：
#   1) 环境变量 TGB_COOKIE
#   2) 本地文件 ~/.workbuddy/tgb_cookie.txt（在 skill 目录**之外**，不会被分发）
# 获取方法：浏览器登录 tgb.cn → DevTools → Network → 任意请求 → 复制 Cookie 请求头
COOKIE = os.environ.get('TGB_COOKIE', '').strip()
if not COOKIE:
    _ck = os.path.expanduser('~/.workbuddy/tgb_cookie.txt')
    if os.path.exists(_ck):
        try:
            COOKIE = open(_ck, encoding='utf-8').read().strip()
        except OSError:
            pass

_cookie_warned = False


def ensure_cookie():
    """COOKIE 为空时提示一次，方便快速定位失败原因。"""
    global _cookie_warned
    if not COOKIE and not _cookie_warned:
        _cookie_warned = True
        print('[!] 未设置 TGB_COOKIE 环境变量 —— 淘股吧需要登录态，'
              '本次请求会失败。请按脚本头部说明设置后重试。')
    return bool(COOKIE)



HEADERS = [
    'accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'accept-language: en,zh;q=0.9,zh-TW;q=0.8',
    'cache-control: max-age=0',
    'priority: u=0, i',
    f'referer: https://www.tgb.cn/blog/{BLOG_UID}',
    'sec-ch-ua: "Google Chrome";v="149", "Chromium";v="149", "Not)A;Brand";v="24"',
    'sec-ch-ua-mobile: ?0',
    'sec-ch-ua-platform: "macOS"',
    'sec-fetch-dest: document',
    'sec-fetch-mode: navigate',
    'sec-fetch-site: same-origin',
    'sec-fetch-user: ?1',
    'upgrade-insecure-requests: 1',
    'user-agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36',
]

# 知识库目录：优先 YUDAO_KB_DIR，其次旧名 TGB_KB_DIR（保留兼容），最后取同级的「知识库/」
KB_DIR = (os.environ.get('YUDAO_KB_DIR')
          or os.environ.get('TGB_KB_DIR')
          or os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                           '..', '知识库')))
TITLES_MD = os.path.join(KB_DIR, 'tgb_posts_titles.md')
INDEX_MD = os.path.join(KB_DIR, 'INDEX.md')

JUNK_TOKENS = ['淘股吧原创', '淘股吧]', '详情', '展开', '加油', '分享文章',
               '复制链接', '举报', '已过期', '精华', '点亮', '收藏', '举报']


# ============================ 工具函数 ============================
def build_curl(url, out_path, cookie=None):
    ensure_cookie()
    cookie = cookie or COOKIE
    cmd = ['curl', url, '-s', '-o', out_path, '-w', '%{http_code}']
    for h in HEADERS:
        cmd += ['-H', h]
    cmd += ['-b', cookie]
    return cmd


def sanitize(name):
    name = name.replace('&nbsp;', ' ').replace('\u00a0', ' ')
    for c in '/\\:*"<>|':
        name = name.replace(c, '_')
    return name.strip()[:60]


def fetch_url(url, out_path, timeout=30):
    """下载 url 到 out_path，返回 HTTP 状态码字符串。"""
    code = subprocess.run(build_curl(url, out_path), capture_output=True,
                          text=True, timeout=timeout).stdout.strip()
    return code


# ============================ 正文提取 ============================
def extract_content(html_text):
    # 取页面 <title>
    m = re.search(r'<title[^>]*>(.*?)</title>', html_text, re.S | re.I)
    page_title = html.unescape(m.group(1).strip()) if m else ''
    # 定位正文容器
    start = html_text.find('class="article-content"')
    if start == -1:
        start = html_text.find('article-content')
    if start == -1:
        return page_title, '', ''
    gt = html_text.find('>', start)
    content_start = gt + 1
    # 正文结束标记（以分享文章为优先，剔除底部评论/分享 UI）
    end_markers = ['分享文章', '复制链接', 'id="comment', 'var _article', '评论区', '发表评论']
    content_end = len(html_text)
    for mk in end_markers:
        pos = html_text.find(mk, content_start)
        if pos != -1:
            content_end = pos
            break
    seg = html_text[content_start:content_end]
    seg = re.sub(r'<script[\s\S]*?</script>', ' ', seg, flags=re.I)
    seg = re.sub(r'<style[\s\S]*?</style>', ' ', seg, flags=re.I)
    # 删除作者博客链接块（头像+署名），避免跨行干扰
    seg = re.sub(r'<a\b[^>]*\bhref="/blog/%s"[^>]*>.*?</a>' % BLOG_UID, ' ', seg, flags=re.S | re.I)
    # 图片：只保留真实配图(image.tgb.cn / img.tgb.cn)，丢弃 css.tgb.cn 装饰图标
    def img_repl(mm):
        src = mm.group(1)
        if 'image.tgb.cn' in src or 'img.tgb.cn' in src:
            return f'\n\n![]({src})\n\n'
        return ' '
    seg = re.sub(r'<img\b[^>]*?\bsrc="([^"]+)"[^>]*?/?>', img_repl, seg, flags=re.I)
    # 链接转 markdown（去掉 javascript: 空链接）
    def link_repl(mm):
        href = mm.group(1)
        txt = re.sub(r'<[^>]+>', '', mm.group(2))
        if href.startswith('javascript:'):
            return txt
        return f'[{txt}]({href})'
    seg = re.sub(r'<a\b[^>]*?\bhref="([^"]+)"[^>]*?>(.*?)</a>', link_repl, seg, flags=re.I | re.S)
    seg = re.sub(r'</(p|div|h1|h2|h3|h4|h5|h6|li|tr|blockquote)>', '\n', seg, flags=re.I)
    seg = re.sub(r'<br\s*/?>', '\n', seg, flags=re.I)
    seg = re.sub(r'<[^>]+>', '', seg)
    seg = html.unescape(seg)
    lines = [l.rstrip() for l in seg.splitlines()]
    out = []
    blank = 0
    heading = page_title.split('_')[0] if page_title else ''
    for l in lines:
        s = l.strip()
        if s == '':
            blank += 1
            if blank <= 1:
                out.append('')
            continue
        # 丢弃 UI 噪音行
        if any(tok in s for tok in JUNK_TOKENS):
            continue
        # 丢弃纯装饰链接行（如只剩 [xxx](/blog/...) 或 [淘股吧]）
        if re.fullmatch(r'\[[^\]]*\]\((?:/blog/|javascript:)[^)]*\)', s):
            continue
        # 丢弃与标题重复的署名标题行
        if heading and s == heading:
            continue
        blank = 0
        out.append(l)
    text = '\n'.join(out).strip()
    # 后处理：清理开头署名块 + 结尾统计数字
    lines = text.split('\n')

    def is_byline(s):
        s = s.strip()
        if '/blog/%s' % BLOG_UID in s or '淘股吧' in s:
            return True
        if re.fullmatch(r'\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}', s):
            return True
        if re.search(r'(浏览|评论)\s*\d', s):
            return True
        return False

    # 顶部：跳过空行 / 署名行 / 纯 | 行
    changed = True
    while changed:
        changed = False
        while lines and lines[0].strip() == '':
            lines.pop(0)
            changed = True
        if lines and (is_byline(lines[0]) or re.fullmatch(r'[\s|]+', lines[0].strip())):
            lines.pop(0)
            changed = True
    # 顶部：去掉孤立头像小图
    while lines and lines[0].strip().startswith('![') and ('60wh' in lines[0] or 'avatar' in lines[0].lower() or 'head' in lines[0].lower()):
        lines.pop(0)
    # 尾部：去掉空行 / 统计数字行（夹着空行也处理）
    changed = True
    while changed:
        changed = False
        while lines and lines[-1].strip() == '':
            lines.pop()
            changed = True
        if lines and (re.fullmatch(r'[\d/\s|]+', lines[-1].strip()) or re.fullmatch(r'[\s|]+', lines[-1].strip())):
            lines.pop()
            changed = True
    out2 = []
    blank = 0
    for l in lines:
        if l.strip() == '':
            blank += 1
            if blank <= 1:
                out2.append('')
        else:
            blank = 0
            out2.append(l)
    text = '\n'.join(out2).strip()
    dm = re.search(r'(\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2})', seg)
    date = dm.group(1) if dm else ''
    return page_title, text, date


# ============================ 博客列表解析 ============================
def parse_list(html_text):
    """从博客列表页 HTML 解析出 [(title, url, replies, date), ...]"""
    items = []
    rows = re.findall(r'<tr[^>]*>(.*?)</tr>', html_text, re.S | re.I)
    for row in rows:
        am = re.search(
            r'<a\s+href="(/a/[A-Za-z0-9_\-]+)"\s+title="([^"]*)"[^>]*>(.*?)</a>',
            row, re.S | re.I)
        if not am:
            continue
        url = 'https://www.tgb.cn' + am.group(1)
        title = re.sub(r'<[^>]+>', '', am.group(3)).strip() or am.group(2).strip()
        title = title.strip()
        dm = re.search(r'<td>(\d{4}-\d{2}-\d{2})</td>', row)
        date = dm.group(1) if dm else ''
        rm = re.search(r'\((\d+)\)', row)
        replies = rm.group(1) if rm else ''
        items.append({'title': title, 'url': url, 'replies': replies, 'date': date})
    # 去重（同 url 保留首次出现）
    seen, uniq = set(), []
    for it in items:
        if it['url'] in seen:
            continue
        seen.add(it['url'])
        uniq.append(it)
    return uniq


def fetch_all_list_pages(max_pages=30):
    """翻页拉取全部博客列表，返回合并后的条目列表。"""
    all_items = []
    seen_urls = set()
    for p in range(1, max_pages + 1):
        url = LIST_URL if p == 1 else f'{LIST_URL}&pageNo={p}'
        tmp = os.path.join(KB_DIR, f'_list_p{p}.html')
        code = fetch_url(url, tmp)
        if code != '200' or not os.path.exists(tmp):
            print(f'  列表页 {p} 下载失败 HTTP {code}，停止翻页')
            break
        txt = open(tmp, encoding='utf-8', errors='ignore').read()
        items = parse_list(txt)
        if not items:
            print(f'  列表页 {p} 无条目，停止翻页')
            break
        new = 0
        for it in items:
            if it['url'] not in seen_urls:
                seen_urls.add(it['url'])
                all_items.append(it)
                new += 1
        print(f'  列表页 {p}：{len(items)} 条，累计 {len(all_items)} 条')
        if new == 0:
            break
    # 清理临时列表页
    for p in range(1, max_pages + 1):
        tp = os.path.join(KB_DIR, f'_list_p{p}.html')
        if os.path.exists(tp):
            os.remove(tp)
    return all_items


# ============================ 目录 / 索引维护 ============================
def read_catalog_urls():
    """读取 tgb_posts_titles.md，返回已收录的 url 集合。"""
    urls = set()
    if not os.path.exists(TITLES_MD):
        return urls
    for line in open(TITLES_MD, encoding='utf-8').read().splitlines():
        if not line.startswith('| '):
            continue
        cells = [c.strip() for c in line.strip().strip('|').split('|')]
        if len(cells) < 5:
            continue
        url = cells[4]
        if url.startswith('https://www.tgb.cn/a/'):
            urls.add(url)
    return urls


def write_catalog(items):
    """把条目列表（含已有+新增）写回 tgb_posts_titles.md。"""
    # 合并：已有目录 + 新条目，按日期倒序
    existing = []
    if os.path.exists(TITLES_MD):
        for line in open(TITLES_MD, encoding='utf-8').read().splitlines():
            if not line.startswith('| '):
                continue
            cells = [c.strip() for c in line.strip().strip('|').split('|')]
            if len(cells) < 5 or not cells[4].startswith('https://www.tgb.cn/a/'):
                continue
            existing.append({'title': cells[1], 'url': cells[4],
                             'replies': cells[2], 'date': cells[3]})
    merged = {}
    for it in existing + items:
        merged[it['url']] = it
    merged_list = list(merged.values())
    merged_list.sort(key=lambda x: x.get('date', ''), reverse=True)

    with open(TITLES_MD, 'w', encoding='utf-8') as f:
        f.write(f'# {BLOG_NAME} 全部主贴标题（共 {len(merged_list)} 条，'
                f'userID={BLOG_UID}，更新于 {time.strftime("%Y-%m-%d")}）\n\n')
        f.write('| # | 标题 | 回复数 | 发布日期 | 链接 |\n')
        f.write('|---|------|--------|----------|------|\n')
        for i, it in enumerate(merged_list, 1):
            t = html.unescape(it["title"]).replace('\u00a0', ' ').strip()
            f.write(f'| {i} | {t} | {it.get("replies","")} | '
                    f'{it.get("date","")} | {it["url"]} |\n')


def write_index(results):
    """results: [(idx, title, url, code, md_path|None), ...]"""
    ok = [r for r in results if r[4]]
    fail = [r for r in results if not r[4]]
    with open(INDEX_MD, 'w', encoding='utf-8') as f:
        f.write(f'# {BLOG_NAME} 主贴正文合集（共 {len(results)} 篇）\n\n')
        f.write(f'成功 {len(ok)} 篇，失败 {len(fail)} 篇。\n\n')
        f.write('| # | 标题 | 文件 | 来源 |\n')
        f.write('|---|------|------|------|\n')
        for idx, title, url, code, md in results:
            fn = os.path.basename(md) if md else f'（失败 HTTP {code}）'
            f.write(f'| {idx} | {title} | {fn} | {url} |\n')


# ============================ 抓取单篇 ============================
def fetch_one(item):
    idx, title, url = item
    pid = url.rstrip('/').split('/')[-1]
    html_path = os.path.join(KB_DIR, f'_raw_{pid}.html')
    code = fetch_url(url, html_path)
    if code != '200' or not os.path.exists(html_path):
        return (idx, title, url, code, None)
    txt = open(html_path, encoding='utf-8', errors='ignore').read()
    page_title, body, date = extract_content(txt)
    md_name = f'{idx:02d}_{sanitize(title)}.md'
    md_path = os.path.join(KB_DIR, md_name)
    heading = page_title.split('_')[0] if page_title else title
    clean = html.unescape(title).replace('\u00a0', ' ').strip()
    with open(md_path, 'w', encoding='utf-8') as f:
        f.write(f'# {clean}\n\n')
        f.write(f'- 作者：{BLOG_NAME}\n')
        if date:
            f.write(f'- 发布时间：{date}\n')
        f.write(f'- 来源：{url}\n\n---\n\n')
        f.write(body if body else '（正文提取为空，可能为纯视频/图片帖或 Cookie 已过期）')
    return (idx, title, url, code, md_path)


# ============================ 命令实现 ============================
def cmd_list():
    print(f'拉取 {BLOG_NAME} 博客列表...')
    items = fetch_all_list_pages()
    print(f'\n共 {len(items)} 篇主贴：\n')
    for i, it in enumerate(items, 1):
        print(f'  {i:02d}. [{it["date"]}] ({it["replies"]}回) {it["title"]}')
        print(f'      {it["url"]}')
    print(f'\n如需抓取新文章：python3 {os.path.basename(__file__)} sync')


def cmd_sync():
    os.makedirs(KB_DIR, exist_ok=True)
    print(f'拉取 {BLOG_NAME} 博客列表...')
    items = fetch_all_list_pages()
    have = read_catalog_urls()
    new_items = [it for it in items if it['url'] not in have]
    print(f'\n列表共 {len(items)} 篇，知识库已收录 {len(have)} 篇，待抓取新文章 {len(new_items)} 篇。')
    if not new_items:
        print('没有新文章，知识库已是最新。')
        return
    # 新文章序号从已有最大编号之后继续，避免覆盖既有文件
    start_idx = 0
    for fn in os.listdir(KB_DIR):
        m = re.match(r'^(\d{2})_.*\.md$', fn)
        if m:
            start_idx = max(start_idx, int(m.group(1)))
    # 更新目录（加入新条目的标题/链接，便于下次比对与 all 重抓）
    write_catalog(new_items)
    # 抓取新文章（按日期倒序给序号，续接已有编号）
    posts = [(start_idx + i, it['title'], it['url']) for i, it in enumerate(new_items, 1)]
    results = []
    t0 = time.time()
    with ThreadPoolExecutor(max_workers=8) as ex:
        futs = {ex.submit(fetch_one, p): p for p in posts}
        for fut in as_completed(futs):
            r = fut.result()
            results.append(r)
            print(f'  [新] {r[1][:36]:<38} HTTP {r[3]}')
    results.sort(key=lambda x: x[0])
    # 重新生成完整索引（基于全部 kb md 文件）
    all_md = sorted([f for f in os.listdir(KB_DIR) if re.match(r'^\d{2}_.*\.md$', f)])
    full = []
    for fn in all_md:
        m = re.match(r'^(\d{2})_(.*)\.md$', fn)
        if not m:
            continue
        idx = int(m.group(1))
        # 从文件里取来源链接
        src = ''
        for ln in open(os.path.join(KB_DIR, fn), encoding='utf-8', errors='ignore'):
            if ln.startswith('- 来源：'):
                src = ln.split('：', 1)[1].strip()
                break
        full.append((idx, m.group(2), src, 'OK', os.path.join(KB_DIR, fn)))
    write_index(full)
    print(f'\n完成：新增 {len(results)} 篇，知识库现共 {len(full)} 篇，耗时 {time.time()-t0:.1f}s')


def cmd_all():
    os.makedirs(KB_DIR, exist_ok=True)
    posts = read_posts_from_catalog()
    if not posts:
        print('目录为空，先用 list 或 sync 生成 tgb_posts_titles.md')
        return
    print(f'读取到 {len(posts)} 篇主贴，开始并行抓取...')
    results = []
    t0 = time.time()
    with ThreadPoolExecutor(max_workers=8) as ex:
        futs = {ex.submit(fetch_one, p): p for p in posts}
        for fut in as_completed(futs):
            r = fut.result()
            results.append(r)
            print(f'  [{r[0]:02d}] {r[1][:30]:<32} HTTP {r[3]}')
    results.sort(key=lambda x: x[0])
    write_index(results)
    ok = [r for r in results if r[4]]
    fail = [r for r in results if not r[4]]
    print(f'\n完成：成功 {len(ok)} / 失败 {len(fail)}，耗时 {time.time()-t0:.1f}s')
    if fail:
        print('失败列表：')
        for r in fail:
            print('  ', r[0], r[1], 'HTTP', r[3])


def read_posts_from_catalog():
    posts = []
    if not os.path.exists(TITLES_MD):
        return posts
    for line in open(TITLES_MD, encoding='utf-8').read().splitlines():
        if not line.startswith('| '):
            continue
        cells = [c.strip() for c in line.strip().strip('|').split('|')]
        if len(cells) < 5:
            continue
        idx, title, url = cells[0], cells[1], cells[4]
        if not url.startswith('https://www.tgb.cn/a/') or not idx.isdigit():
            continue
        posts.append((int(idx), title, url))
    return posts


def cmd_reconvert():
    os.makedirs(KB_DIR, exist_ok=True)
    posts = read_posts_from_catalog()
    results = []
    for idx, title, url in posts:
        pid = url.rstrip('/').split('/')[-1]
        html_path = os.path.join(KB_DIR, f'_raw_{pid}.html')
        if not os.path.exists(html_path):
            results.append((idx, title, url, 'NO_RAW', None))
            continue
        txt = open(html_path, encoding='utf-8', errors='ignore').read()
        page_title, body, date = extract_content(txt)
        md_name = f'{idx:02d}_{sanitize(title)}.md'
        md_path = os.path.join(KB_DIR, md_name)
        with open(md_path, 'w', encoding='utf-8') as f:
            f.write(f'# {title}\n\n')
            f.write(f'- 作者：{BLOG_NAME}\n')
            if date:
                f.write(f'- 发布时间：{date}\n')
            f.write(f'- 来源：{url}\n\n---\n\n')
            f.write(body if body else '（正文提取为空，可能为纯视频/图片帖）')
        results.append((idx, title, url, 'OK', md_path))
    results.sort(key=lambda x: x[0])
    write_index(results)
    ok = [r for r in results if r[4]]
    print(f'重转完成：{len(ok)}/{len(results)} 篇')


def cmd_test():
    """离线验证解析逻辑：用打包的样例 HTML（若存在）。"""
    here = os.path.dirname(os.path.abspath(__file__))
    samples = [
        ('列表样例', os.path.join(here, '..', '样例', 'sample_blog_list.html')),
        ('正文样例', os.path.join(here, '..', '样例', 'sample_article.html')),
    ]
    list_html = None
    for label, p in samples:
        p = os.path.normpath(p)
        if os.path.exists(p):
            print(f'[test] 找到{label}：{p}')
            if label.startswith('列表'):
                list_html = open(p, encoding='utf-8', errors='ignore').read()
            else:
                t, b, d = extract_content(open(p, encoding='utf-8', errors='ignore').read())
                print(f'       标题={t!r} 日期={d!r} 正文长度={len(b)}')
                print('       正文预览：', b[:120].replace(chr(10), ' '))
    if list_html:
        items = parse_list(list_html)
        print(f'[test] 列表解析到 {len(items)} 条：')
        for it in items[:5]:
            print('       ', it)
    if not list_html:
        print('[test] 未找到样例 HTML，跳过（仅验证正文提取函数存在）。')


# ============================ 入口 ============================
if __name__ == '__main__':
    arg = sys.argv[1] if len(sys.argv) > 1 else 'sync'
    os.makedirs(KB_DIR, exist_ok=True)
    if arg == 'list':
        cmd_list()
    elif arg == 'sync':
        cmd_sync()
    elif arg == 'all':
        cmd_all()
    elif arg == 'reconvert':
        cmd_reconvert()
    elif arg == 'test':
        cmd_test()
    else:
        print(__doc__)
