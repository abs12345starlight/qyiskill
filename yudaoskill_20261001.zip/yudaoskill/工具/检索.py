#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
郁金香知识库统一检索。

三个检索范围：
  posts    60 篇主贴正文
  gems     精华跟帖分册（已清洗、按主题分类，约 1073 条）—— 默认，噪音最少
  comments 跟帖全量（10408 条，含 <10 字的短回复噪音）

用法：
  python3 工具/检索.py 反核                      # 默认搜精华
  python3 工具/检索.py 反核 --scope all          # 精华 + 主贴 + 全量跟帖
  python3 工具/检索.py 合富 --scope comments     # 只在全量跟帖里搜（查具体个股用这个）
  python3 工具/检索.py 竞价 --scope gems         # 只在精华分册里搜
  python3 工具/检索.py 反核 --len 80             # 只看回答 >=80 字的
  python3 工具/检索.py 反核 -n 30                # 最多输出 30 条
  python3 工具/检索.py 反核 竞价 --all-kw        # 多个关键词，全部命中才输出（AND）
"""
import os, re, sys, argparse

HERE = os.path.dirname(os.path.abspath(__file__))
# 默认本 skill 的 知识库；可用 TGB_KB_DIR 覆盖，便于复用到其他博主的知识库
# 知识库目录：优先 YUDAO_KB_DIR，其次旧名 TGB_KB_DIR（保留兼容），最后取同级的「知识库/」
KB = (os.environ.get('YUDAO_KB_DIR')
      or os.environ.get('TGB_KB_DIR')
      or os.path.normpath(os.path.join(HERE, '..', '知识库')))
CM = os.path.join(KB, 'comments')
GEMS = os.path.join(KB, 'gems')


SELF_MARK = '_（博主主动发言'   # gems 分册里对无引用条目的标记


def split_blocks(txt):
    """跟帖：切分为 [(时间, 提问, 回答)]"""
    out = []
    for b in re.split(r'\n### ', txt)[1:]:
        lines = b.splitlines()
        time = lines[0].strip()
        rest = lines[1:]
        quote = '\n'.join(l[2:] for l in rest if l.startswith('> ')).strip()
        if quote.startswith(SELF_MARK):     # 主动发言标记不是真提问
            quote = ''
        ans = '\n'.join(l for l in rest if not l.startswith('> ') and l.strip()).strip()
        out.append((time, quote, ans))
    return out


def search_posts(kws, mode_and, min_len, limit):
    """主贴：按行命中输出上下文"""
    hits = []
    for f in sorted(os.listdir(KB)):
        if not f.endswith('.md') or f.startswith('tgb_') or f == 'INDEX.md' or f == 'TOPICS.md':
            continue
        path = os.path.join(KB, f)
        lines = open(path, encoding='utf-8').read().splitlines()
        for i, ln in enumerate(lines):
            ok = all(k in ln for k in kws) if mode_and else any(k in ln for k in kws)
            if ok and len(ln.strip()) >= min_len:
                ctx = ' / '.join(x.strip() for x in lines[max(0, i-1):i+2] if x.strip())
                hits.append((f, ctx[:400]))
                if len(hits) >= limit:
                    return hits
    return hits


def search_comments(kws, mode_and, min_len, limit, root=CM, prefix=''):
    """跟帖：输出「网友提问 → 博主回答」问答对"""
    hits = []
    for f in sorted(os.listdir(root)):
        if not f.endswith('.md') or f == 'INDEX.md':
            continue
        txt = open(os.path.join(root, f), encoding='utf-8').read()
        for time, quote, ans in split_blocks(txt):
            if len(ans) < min_len:
                continue
            ok = all(k in ans for k in kws) if mode_and else any(k in ans for k in kws)
            if ok:
                hits.append((prefix + f, time, quote, ans))
                if len(hits) >= limit:
                    return hits
    return hits


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('keywords', nargs='+', help='要搜的关键词')
    ap.add_argument('--scope', default='gems',
                    choices=['gems', 'posts', 'comments', 'all'],
                    help='检索范围（默认 gems 精华）')
    ap.add_argument('--len', type=int, default=0, help='回答/行最小长度过滤')
    ap.add_argument('-n', type=int, default=20, help='最多输出条数')
    ap.add_argument('--all-kw', action='store_true', help='多个关键词需全部命中（AND，默认 OR）')
    args = ap.parse_args()

    kws = args.keywords
    mode_and = args.all_kw
    joiner = ' AND ' if mode_and else ' OR '
    print(f'搜索：{joiner.join(kws)}   范围：{args.scope}   最少 {args.len} 字   上限 {args.n} 条\n')
    print('=' * 70)

    if args.scope in ('posts', 'all'):
        hits = search_posts(kws, mode_and, args.len, args.n)
        print(f'\n【主贴】命中 {len(hits)} 处\n' + '-' * 70)
        for f, ctx in hits:
            print(f'[{f[:40]}]\n  {ctx}\n')

    if args.scope in ('gems', 'all'):
        hits = search_comments(kws, mode_and, args.len, args.n, GEMS, 'gems/')
        print(f'\n【精华跟帖】命中 {len(hits)} 条\n' + '-' * 70)
        for f, time, quote, ans in hits:
            print(f'[{f[:34]}] {time}')
            if quote:
                print(f'  Q：{quote[:150]}')
            else:
                print('  Q：（博主主动发言）')
            print(f'  A：{ans[:400]}\n')

    if args.scope in ('comments', 'all'):
        hits = search_comments(kws, mode_and, args.len, args.n, CM)
        print(f'\n【跟帖全量】命中 {len(hits)} 条\n' + '-' * 70)
        for f, time, quote, ans in hits:
            print(f'[{f[:34]}] {time}')
            if quote:
                print(f'  Q：{quote[:150]}')
            else:
                print('  Q：（博主主动发言）')
            print(f'  A：{ans[:400]}\n')


if __name__ == '__main__':
    main()
