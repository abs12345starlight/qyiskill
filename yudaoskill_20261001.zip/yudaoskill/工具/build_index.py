#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
构建郁金香知识库「主题索引 + 精华分册」。

产出（位于 知识库/）：
  TOPICS.md        主题地图：每个主题 → 相关主贴 + 精华条数
  gems/<主题>.md   精华问答分册（博主回答 >=100 字，或主动分享 >=60 字）

设计目的：
  跟帖全量 143 万字、1 万多条，其中约 15% 是「赔钱」「这篇认真看」这类 <10 字噪音，
  真精华只有 ~1200 条 / 25 万字。按主题切分成册后，单册 1~4 万字可直接 Read 精读，
  不必每次 grep 全库。

用法：
  python3 工具/build_index.py            # 重建索引与分册
  python3 工具/build_index.py --stats    # 只看统计，不写文件
"""
import os, re, sys, argparse

# 默认本 skill 的 知识库；可用 TGB_KB_DIR 覆盖，便于复用到其他博主的知识库
# 知识库目录：优先 YUDAO_KB_DIR，其次旧名 TGB_KB_DIR（保留兼容），最后取同级的「知识库/」
KB = (os.environ.get('YUDAO_KB_DIR')
      or os.environ.get('TGB_KB_DIR')
      or os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                       '..', '知识库')))
CM = os.path.join(KB, 'comments')
GEMS = os.path.join(KB, 'gems')

# 主题定义：主题名 -> 关键词。一条问答归入「命中关键词数最多」的主题（平局取定义靠前者）
#
# ⚠️ 关键词必须是「特指词」，不要用「情绪」「方向」「板块」这类泛词——
#    泛词会把大量无关回答吸进同一个分册（实测「情绪」一词会让情绪周期分册膨胀到 280 条 / 7.3 万字）。
TOPICS = [
    ('反核翘板', ['反核', '翘板', '撬板', '地天', '核按', '地板', '跌停开']),
    ('竞价', ['竞价', '一字开', '封单', '撤单', '9:25', '9:20', '集合竞价']),
    ('买点与介入', ['低吸', '半路', '打板', '扫板', '介入', '买点', '上车', '点火', '追高']),
    ('卖点与止损', ['卖点', '止损', '割肉', '止盈', '兑现', '减仓', '清仓', '被套', '手起刀落']),
    ('情绪周期', ['冰点', '退潮', '高潮', '回暖', '修复', '分歧转一致', '分歧', '一致',
                  '情绪周期', '情绪流', '节点', '主升']),
    ('地位与辨识度', ['地位', '辨识度', '卡位', '身位', '龙头', '带动', '引领']),
    ('接力与连板', ['接力', '连板', '连扳', '晋级', '断板', '高度板', '空间板']),
    ('主线与题材', ['主线', '题材', '支线', '轮动', '主流', '板块效应']),
    ('量价与筹码', ['量价', '筹码', '换手', '放量', '缩量', '量能', '抛压', '承接', '砸盘']),
    ('预期与确定性', ['预期差', '确定性', '盈亏比', '性价比', '胜率']),
    ('纪律与心态', ['纪律', '心态', '空仓', '管住手', '节奏', '知行合一']),
    ('分时与盘口', ['分时', '盘口', '扫单', '炸板', '开板', '尾盘']),
]

GEM_MIN = 100        # 有引用的问答：清洗后回答 >=100 字才算精华
GEM_MIN_SELF = 60    # 博主主动发言（无引用）：>=60 字

# 未命中任何主题关键词时的归处（多为具体个股点评 / 盘中随笔，仍有价值，不是杂物）
FALLBACK = '综合与个股点评'

# —— 噪音清洗 ——
# 整行剔除：图片占位符、纯表情/水印
RE_IMG_LINE = re.compile(r'^\s*!\[.*\]\(.*\)\s*$')
RE_EMOJI = re.compile(r'\[[^\[\]]{1,8}\]')          # [淘股吧] [牛逼] 等表情占位
RE_URL = re.compile(r'https?://\S+')

# 运营/水贴句：命中即整句剔除（拉票、直播通知、打赏感谢、活动）
NOISE_SENT = ['投票', '催播', '打赏', '点赞', '贡献榜', '预约直播', '直播活动',
              '郁神语录', '签到', '抽奖', '福利', '粉丝群', '催更',
              'placeHolder', '淘股吧官方', '补上红包', '投给我', '投两票']


def clean(text):
    """清洗水贴成分，返回有效正文。"""
    lines = []
    for ln in text.splitlines():
        if RE_IMG_LINE.match(ln):
            continue
        ln = RE_EMOJI.sub('', ln)
        ln = RE_URL.sub('', ln)
        # 剔除含运营词的句子（按标点切句）
        segs = re.split(r'(?<=[。！？!?\n])', ln)
        kept = [s for s in segs if not any(k in s for k in NOISE_SENT)]
        ln = ''.join(kept)
        lines.append(ln)
    out = '\n'.join(lines)
    out = re.sub(r'\n{3,}', '\n\n', out)
    out = re.sub(r'[ \t]+', ' ', out)
    return out.strip()


def parse_comments():
    """返回 [(篇号, 文件, 时间, 提问, 清洗后回答, 原始回答)]"""
    out = []
    for f in sorted(os.listdir(CM)):
        if not f.endswith('.md') or f == 'INDEX.md':
            continue
        num = f.split('_')[0]
        txt = open(os.path.join(CM, f), encoding='utf-8').read()
        for b in re.split(r'\n### ', txt)[1:]:
            lines = b.splitlines()
            time = lines[0].strip()
            rest = lines[1:]
            quote = '\n'.join(l[2:] for l in rest if l.startswith('> ')).strip()
            raw = '\n'.join(l for l in rest if not l.startswith('> ') and l.strip()).strip()
            out.append((num, f, time, quote, clean(raw), raw))
    return out


def classify(ans):
    """返回 (主题名, 命中数)；无命中返回 ('其他精华', 0)"""
    best, best_n = FALLBACK, 0
    for name, kws in TOPICS:
        n = sum(1 for k in kws if k in ans)
        if n > best_n:
            best, best_n = name, n
    return best, best_n


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--stats', action='store_true', help='只打印统计，不写文件')
    args = ap.parse_args()

    all_c = parse_comments()
    gems = [c for c in all_c
            if len(c[4]) >= GEM_MIN or (not c[3] and len(c[4]) >= GEM_MIN_SELF)]
    noise = len([c for c in all_c
                 if len(c[5]) - len(c[4]) > 30 and c not in gems])

    # 按主贴统计精华分布
    by_post = {}
    for c in gems:
        by_post.setdefault(c[0], 0)
        by_post[c[0]] += 1

    # 分类
    buckets = {name: [] for name, _ in TOPICS}
    buckets[FALLBACK] = []
    for c in gems:
        t, _ = classify(c[4])
        buckets[t].append(c)

    total_chars = sum(len(c[4]) for c in gems)
    print(f'跟帖总数：{len(all_c)}')
    print(f'清洗掉的水贴/占位：{noise} 条')
    print(f'精华条数：{len(gems)}（{total_chars:,} 字符）')
    print()
    print(f'{"主题":<14}{"精华条数":>8}{"字符数":>10}')
    print('-' * 34)
    for name, _ in TOPICS + [(FALLBACK, [])]:
        items = buckets[name]
        ch = sum(len(c[4]) for c in items)
        print(f'{name:<14}{len(items):>8}{ch:>10,}')
    print()
    print('精华条数 Top10 主贴：')
    for num, n in sorted(by_post.items(), key=lambda x: -x[1])[:10]:
        print(f'  {num}  {n:4} 条')

    if args.stats:
        return

    # ---------- 写 gems/<主题>.md ----------
    os.makedirs(GEMS, exist_ok=True)
    for name, items in buckets.items():
        if not items:
            continue
        path = os.path.join(GEMS, name + '.md')
        with open(path, 'w', encoding='utf-8') as fo:
            ch = sum(len(c[4]) for c in items)
            fo.write(f'# {name} · 精华跟帖（{len(items)} 条 / 约 {ch//10000} 万字）\n\n')
            fo.write('> 筛选标准：博主回答清洗后 ≥100 字，或主动分享 ≥60 字；\n')
            fo.write('> 已剔除图片占位符、表情水印、投票/直播/打赏等运营水贴。\n')
            fo.write('> 按时间升序，格式为「网友提问 → 博主回答」。\n')
            fo.write('> 源文件 `comments/NN_*_跟帖.md`，需完整上下文请回原文件按时间戳定位。\n\n')
            fo.write('---\n\n')
            for num, f, time, quote, ans, raw in items:
                fo.write(f'### [{num}] {time}\n\n')
                if quote:
                    qt = quote.replace('\n', '\n> ')
                    fo.write(f'> {qt}\n\n')
                else:
                    fo.write('> _（博主主动发言，无引用）_\n\n')
                fo.write(ans + '\n\n')
        print(f'写入 {path}')

    # ---------- 写 TOPICS.md ----------
    main_meta = {}
    for line in open(os.path.join(KB, 'INDEX.md'), encoding='utf-8').read().splitlines():
        m = re.match(r'\|\s*(\d+)\s*\|\s*(.+?)\s*\|\s*(\d{2})_.+?\.md\s*\|\s*(https?://\S+?)\s*\|', line)
        if m:
            main_meta[m.group(3)] = (m.group(2), m.group(4))

    corpus_chars = sum(len(c[3]) + len(c[4]) for c in all_c)
    # 整个 comments/ 语料的字符数（含时间戳与 Markdown 标记），口径大于 corpus_chars
    raw_chars = 0
    for fn in sorted(os.listdir(CM)):
        if fn.endswith('.md') and fn[:2].isdigit():
            with open(os.path.join(CM, fn), encoding='utf-8', errors='ignore') as fh:
                raw_chars += len(fh.read())
    with open(os.path.join(KB, 'TOPICS.md'), 'w', encoding='utf-8') as fo:
        fo.write('# 主题地图（按主题定位主贴与精华跟帖）\n\n')
        fo.write(f'> 全库：主贴 {len(main_meta)} 篇 / 跟帖 {len(all_c)} 条'
                 f'（网友提问与博主回答正文合计约 {corpus_chars/10000:.1f} 万字；'
                 f'含时间戳与 Markdown 格式的整个语料约 {raw_chars/10000:.1f} 万字）。\n')
        fo.write(f'> 精华：{len(gems)} 条 / 约 {total_chars//10000} 万字，已按主题切分为 `gems/` 分册。\n\n')
        fo.write('**用法**：查某个主题时，直接 Read 对应的 `gems/<主题>.md` 分册精读，'
                 '比 grep 全库快且噪音少。\n\n')
        fo.write('| 主题 | 精华条数 | 分册文件 | 相关主贴 Top3（数字=关键词命中次数） |\n')
        fo.write('|------|---------|---------|--------------------------------|\n')
        for name, kws in TOPICS + [(FALLBACK, [])]:
            items = buckets[name]
            # 主贴命中：按关键词出现总次数排序取 Top3（比「是否命中」更有区分度）
            hits = []
            for num, (title, url) in sorted(main_meta.items()):
                p = os.path.join(KB, [f for f in os.listdir(KB)
                                      if f.startswith(num + '_') and f.endswith('.md')][0])
                try:
                    body = open(p, encoding='utf-8').read()
                except Exception:
                    continue
                n = sum(body.count(k) for k in kws)
                if n:
                    hits.append((n, num, title, url))
            hits.sort(reverse=True)
            cell = '、'.join(f'[{num} {t[:14]}·{n}]({u})'
                             for n, num, t, u in hits[:3]) if hits else '—'
            fo.write(f'| **{name}** | {len(items)} | `gems/{name}.md` | {cell} |\n')
        fo.write('\n## 精华条数最多的主贴 Top15\n\n')
        fo.write('| 主贴 | 精华条数 | 链接 |\n')
        fo.write('|------|---------|------|\n')
        for num, n in sorted(by_post.items(), key=lambda x: -x[1])[:15]:
            title, url = main_meta.get(num, ('?', ''))
            fo.write(f'| {num} {title} | {n} | {url} |\n')
        fo.write('\n## 主题关键词表\n\n')
        fo.write('调整分类只需改 `工具/build_index.py` 里的 `TOPICS`，然后重跑即可。\n\n')
        for name, kws in TOPICS:
            fo.write(f'- **{name}**：{"、".join(kws)}\n')
        fo.write(f'\n> 归类规则：一条问答归入「命中关键词数最多」的主题，平局取上表靠前者；\n')
        fo.write(f'> 未命中任何关键词的归入「{FALLBACK}」（多为具体个股点评，仍有价值）。\n')
        fo.write('> 同一条只出现在一个分册，不重复。\n')
    print(f'写入 {os.path.join(KB, "TOPICS.md")}')


if __name__ == '__main__':
    main()
