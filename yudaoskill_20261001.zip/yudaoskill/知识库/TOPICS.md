# 主题地图（按主题定位主贴与精华跟帖）

> 全库：主贴 61 篇 / 跟帖 10786 条（网友提问与博主回答正文合计约 114.2 万字；含时间戳与 Markdown 格式的整个语料约 148.1 万字）。
> 精华：1096 条 / 约 23 万字，已按主题切分为 `gems/` 分册。

**用法**：查某个主题时，直接 Read 对应的 `gems/<主题>.md` 分册精读，比 grep 全库快且噪音少。

| 主题 | 精华条数 | 分册文件 | 相关主贴 Top3（数字=关键词命中次数） |
|------|---------|---------|--------------------------------|
| **反核翘板** | 122 | `gems/反核翘板.md` | [25 [红包]周核心情绪流拆解·22](https://www.tgb.cn/a/2dg4tvpMndO)、[26 情绪流奥义：高低切与核心反核·20](https://www.tgb.cn/a/2cUqpxg2bbO)、[30 反核、穿越与首板·14](https://www.tgb.cn/a/2bG77s5qgff) |
| **竞价** | 66 | `gems/竞价.md` | [58 顶级逻辑3；大资金竞价怎么看·10](https://www.tgb.cn/a/27l7z4gy3CN)、[12 25.12.18.限定情绪流·10](https://www.tgb.cn/a/2nRqFoonFDy)、[57 顶级做盘逻辑4：为什么我能预·9](https://www.tgb.cn/a/27mNR5EZlli) |
| **买点与介入** | 65 | `gems/买点与介入.md` | [48 职业基础2：尾盘买法+接力连·12](https://www.tgb.cn/a/27QNkHjQIsH)、[52 盘面随笔2：四月的第一碗面！·8](https://www.tgb.cn/a/27ypQmSKIVF)、[45 顶级逻辑6：如何在启动点参与·7](https://www.tgb.cn/a/28kDFHQCK0S) |
| **卖点与止损** | 52 | `gems/卖点与止损.md` | [31 一文说清超短的确定性·9](https://www.tgb.cn/a/2bpuxnc6bJc)、[41 顶级逻辑7：大局观的切换·6](https://www.tgb.cn/a/28QcCyH6zcs)、[46 宏观基础3：超短预期、研报与·5](https://www.tgb.cn/a/28dXW0sEh9h) |
| **情绪周期** | 228 | `gems/情绪周期.md` | [24 预判每日情绪的第一要点：建立·36](https://www.tgb.cn/a/2dzfY6duXyV)、[61 [红包]26.8.19 内驱·12](https://www.tgb.cn/a/2uo9dXwVA4H)、[25 [红包]周核心情绪流拆解·12](https://www.tgb.cn/a/2dg4tvpMndO) |
| **地位与辨识度** | 112 | `gems/地位与辨识度.md` | [45 顶级逻辑6：如何在启动点参与·14](https://www.tgb.cn/a/28kDFHQCK0S)、[55 4.15号直播预告，不了解市·11](https://www.tgb.cn/a/27t2Crm4oas)、[52 盘面随笔2：四月的第一碗面！·10](https://www.tgb.cn/a/27ypQmSKIVF) |
| **接力与连板** | 39 | `gems/接力与连板.md` | [45 顶级逻辑6：如何在启动点参与·13](https://www.tgb.cn/a/28kDFHQCK0S)、[48 职业基础2：尾盘买法+接力连·12](https://www.tgb.cn/a/27QNkHjQIsH)、[39 男神节活动：再谈接力环境以及·8](https://www.tgb.cn/a/296BurQBc5M) |
| **主线与题材** | 51 | `gems/主线与题材.md` | [48 职业基础2：尾盘买法+接力连·16](https://www.tgb.cn/a/27QNkHjQIsH)、[44 集中一点，登峰造极。·12](https://www.tgb.cn/a/28w7FDVweUA)、[09 2026心法系列1：浅谈卖飞·9](https://www.tgb.cn/a/2owOV9Tii3h) |
| **量价与筹码** | 64 | `gems/量价与筹码.md` | [31 一文说清超短的确定性·10](https://www.tgb.cn/a/2bpuxnc6bJc)、[25 [红包]周核心情绪流拆解·9](https://www.tgb.cn/a/2dg4tvpMndO)、[24 预判每日情绪的第一要点：建立·9](https://www.tgb.cn/a/2dzfY6duXyV) |
| **预期与确定性** | 34 | `gems/预期与确定性.md` | [31 一文说清超短的确定性·15](https://www.tgb.cn/a/2bpuxnc6bJc)、[24 预判每日情绪的第一要点：建立·11](https://www.tgb.cn/a/2dzfY6duXyV)、[09 2026心法系列1：浅谈卖飞·8](https://www.tgb.cn/a/2owOV9Tii3h) |
| **纪律与心态** | 12 | `gems/纪律与心态.md` | [41 顶级逻辑7：大局观的切换·8](https://www.tgb.cn/a/28QcCyH6zcs)、[30 反核、穿越与首板·3](https://www.tgb.cn/a/2bG77s5qgff)、[49 盘面随笔3：明日接力行情预案·2](https://www.tgb.cn/a/27Iur8ZuTk7) |
| **分时与盘口** | 38 | `gems/分时与盘口.md` | [48 职业基础2：尾盘买法+接力连·22](https://www.tgb.cn/a/27QNkHjQIsH)、[13 [红包]25.12.16。限·18](https://www.tgb.cn/a/2nO2o0kgnl5)、[14 超短高阶必看：穿越？空间？一·12](https://www.tgb.cn/a/2lviP8aBf2g) |
| **综合与个股点评** | 213 | `gems/综合与个股点评.md` | — |

## 精华条数最多的主贴 Top15

| 主贴 | 精华条数 | 链接 |
|------|---------|------|
| 09 2026心法系列1：浅谈卖飞的定义。 | 78 | https://www.tgb.cn/a/2owOV9Tii3h |
| 16 [投票]25.3.31。关山难越 | 59 | https://www.tgb.cn/a/2gPbfLTcbPz |
| 14 超短高阶必看：穿越？空间？一文说清首开模式。 | 54 | https://www.tgb.cn/a/2lviP8aBf2g |
| 01 26.6.23.情绪与合力悖论 | 46 | https://www.tgb.cn/a/2sRC74XG5D1 |
| 41 顶级逻辑7：大局观的切换 | 36 | https://www.tgb.cn/a/28QcCyH6zcs |
| 22 隔日超短：跨年高度重要吗？ | 33 | https://www.tgb.cn/a/2e4OVsdjvLL |
| 30 反核、穿越与首板 | 33 | https://www.tgb.cn/a/2bG77s5qgff |
| 26 情绪流奥义：高低切与核心反核 | 31 | https://www.tgb.cn/a/2cUqpxg2bbO |
| 39 男神节活动：再谈接力环境以及后市零碎所思 | 31 | https://www.tgb.cn/a/296BurQBc5M |
| 32 超短反应力的具象化 | 30 | https://www.tgb.cn/a/2aXg61pJs1l |
| 05 26.4.9。高阶情绪流周回顾+后续预期建立 | 27 | https://www.tgb.cn/a/2qR9bpr7Joj |
| 49 盘面随笔3：明日接力行情预案，破局还是A杀 | 26 | https://www.tgb.cn/a/27Iur8ZuTk7 |
| 31 一文说清超短的确定性 | 25 | https://www.tgb.cn/a/2bpuxnc6bJc |
| 36 年中巨献：竞价题材强弱辨别与去留 | 25 | https://www.tgb.cn/a/29OckftwZ9V |
| 38 重磅奖品！第一届“花园杯”研股比赛周赛 | 25 | https://www.tgb.cn/a/29gIWeeROXU |

## 主题关键词表

调整分类只需改 `scripts/build_index.py` 里的 `TOPICS`，然后重跑即可。

- **反核翘板**：反核、翘板、撬板、地天、核按、地板、跌停开
- **竞价**：竞价、一字开、封单、撤单、9:25、9:20、集合竞价
- **买点与介入**：低吸、半路、打板、扫板、介入、买点、上车、点火、追高
- **卖点与止损**：卖点、止损、割肉、止盈、兑现、减仓、清仓、被套、手起刀落
- **情绪周期**：冰点、退潮、高潮、回暖、修复、分歧转一致、分歧、一致、情绪周期、情绪流、节点、主升
- **地位与辨识度**：地位、辨识度、卡位、身位、龙头、带动、引领
- **接力与连板**：接力、连板、连扳、晋级、断板、高度板、空间板
- **主线与题材**：主线、题材、支线、轮动、主流、板块效应
- **量价与筹码**：量价、筹码、换手、放量、缩量、量能、抛压、承接、砸盘
- **预期与确定性**：预期差、确定性、盈亏比、性价比、胜率
- **纪律与心态**：纪律、心态、空仓、管住手、节奏、知行合一
- **分时与盘口**：分时、盘口、扫单、炸板、开板、尾盘

> 归类规则：一条问答归入「命中关键词数最多」的主题，平局取上表靠前者；
> 未命中任何关键词的归入「综合与个股点评」（多为具体个股点评，仍有价值）。
> 同一条只出现在一个分册，不重复。
