# 郁金香5678 主贴正文合集（共 61 篇）

成功 61 篇，失败 0 篇。

| # | 标题 | 文件 | 来源 |
|---|------|------|------|
| 1 | 26.6.23.情绪与合力悖论 | 01_26.6.23.情绪与合力悖论.md | https://www.tgb.cn/a/2sRC74XG5D1 |
| 2 | 26.6.2.视频复盘：存储、电力预期与情绪流回顾 | 02_26.6.2.视频复盘：存储、电力预期与情绪流回顾.md | https://www.tgb.cn/a/2siU0UV6VNS |
| 3 | 26.5.25.视频复盘：短线锚点、情绪流回顾。 | 03_26.5.25.视频复盘：短线锚点、情绪流回顾。.md | https://www.tgb.cn/a/2s5GX6eepz1 |
| 4 | 26.5.20视频复盘：情绪流、短线锚点 | 04_26.5.20视频复盘：情绪流、短线锚点.md | https://www.tgb.cn/a/2rXnAYAEWSw |
| 5 | 26.4.9。高阶情绪流周回顾+后续预期建立 | 05_26.4.9。高阶情绪流周回顾+后续预期建立.md | https://www.tgb.cn/a/2qR9bpr7Joj |
| 6 | 26.3.26。超短高阶：反抽与反弹 | 06_26.3.26。超短高阶：反抽与反弹.md | https://www.tgb.cn/a/2qtUBChW5XI |
| 7 | 26.3.18。高阶情绪流回顾 | 07_26.3.18。高阶情绪流回顾.md | https://www.tgb.cn/a/2qgCsrjwyAQ |
| 8 | 26.3.16。高阶情绪流复盘与预期差 | 08_26.3.16。高阶情绪流复盘与预期差.md | https://www.tgb.cn/a/2qd9S66xaqL |
| 9 | 2026心法系列1：浅谈卖飞的定义。 | 09_2026心法系列1：浅谈卖飞的定义。.md | https://www.tgb.cn/a/2owOV9Tii3h |
| 10 | 26.1.5。盘面情绪流回顾5 | 10_26.1.5。盘面情绪流回顾5.md | https://www.tgb.cn/a/2oldFwYH3bB |
| 11 | 2025.12.23。限定情绪流回顾3 | 11_2025.12.23。限定情绪流回顾3.md | https://www.tgb.cn/a/2nZG8Sya9g8 |
| 12 | 25.12.18.限定情绪流回顾2 | 12_25.12.18.限定情绪流回顾2.md | https://www.tgb.cn/a/2nRqFoonFDy |
| 13 | [红包]25.12.16。限定情绪流回顾 | 13_[红包]25.12.16。限定情绪流回顾.md | https://www.tgb.cn/a/2nO2o0kgnl5 |
| 14 | 超短高阶必看：穿越？空间？一文说清首开模式。 | 14_超短高阶必看：穿越？空间？一文说清首开模式。.md | https://www.tgb.cn/a/2lviP8aBf2g |
| 15 | [红包]25.8.13。连板？对不起，只要趋势反包。 | 15_[红包]25.8.13。连板？对不起，只要趋势反包。.md | https://www.tgb.cn/a/2ksFPXRuoHM |
| 16 | [投票]25.3.31。关山难越 | 16_[投票]25.3.31。关山难越.md | https://www.tgb.cn/a/2gPbfLTcbPz |
| 17 | 25.3.16。见龙在田 | 17_25.3.16。见龙在田.md | https://www.tgb.cn/a/2grOVTys7hH |
| 18 | 25.3.7早盘 | 18_25.3.7早盘.md | https://www.tgb.cn/a/2gbXWwqe7Ni |
| 19 | 25.2.19。停云落月 | 19_25.2.19。停云落月.md | https://www.tgb.cn/a/2fMfvSXDZ5W |
| 20 | 25.2.11。 | 20_25.2.11。.md | https://www.tgb.cn/a/2fyTCAkgewH |
| 21 | 2025首帖：超短理念系列 | 21_2025首帖：超短理念系列.md | https://www.tgb.cn/a/2eCOuOqAjhO |
| 22 | 隔日超短：跨年高度重要吗？ | 22_隔日超短：跨年高度重要吗？.md | https://www.tgb.cn/a/2e4OVsdjvLL |
| 23 | 情绪流切换：极致的刀口舔血 | 23_情绪流切换：极致的刀口舔血.md | https://www.tgb.cn/a/2dLo8V9Uh9v |
| 24 | 预判每日情绪的第一要点：建立超短预期 | 24_预判每日情绪的第一要点：建立超短预期.md | https://www.tgb.cn/a/2dzfY6duXyV |
| 25 | [红包]周核心情绪流拆解 | 25_[红包]周核心情绪流拆解.md | https://www.tgb.cn/a/2dg4tvpMndO |
| 26 | 情绪流奥义：高低切与核心反核 | 26_情绪流奥义：高低切与核心反核.md | https://www.tgb.cn/a/2cUqpxg2bbO |
| 27 | 增量行情里隔日超短与所谓周期 | 27_增量行情里隔日超短与所谓周期.md | https://www.tgb.cn/a/2cDd4KDX3ot |
| 28 | [投票]24.10.11：这就是牛市吗！ | 28_[投票]24.10.11：这就是牛市吗！.md | https://www.tgb.cn/a/2cgDXzUkwWg |
| 29 | 写在3258。 | 29_写在3258。.md | https://www.tgb.cn/a/2cdkftNJ0z7 |
| 30 | 反核、穿越与首板 | 30_反核、穿越与首板.md | https://www.tgb.cn/a/2bG77s5qgff |
| 31 | 一文说清超短的确定性 | 31_一文说清超短的确定性.md | https://www.tgb.cn/a/2bpuxnc6bJc |
| 32 | 超短反应力的具象化 | 32_超短反应力的具象化.md | https://www.tgb.cn/a/2aXg61pJs1l |
| 33 | 缩量行情的极致切换 | 33_缩量行情的极致切换.md | https://www.tgb.cn/a/2aMM4QIr2AA |
| 34 | 盘面随笔5：顶级大局观！商业航天的参与节奏 | 34_盘面随笔5：顶级大局观！商业航天的参与节奏.md | https://www.tgb.cn/a/2aA2PXOHWWf |
| 35 | 年中巨献2：主线、主流与核心 | 35_年中巨献2：主线、主流与核心.md | https://www.tgb.cn/a/2aeB87v2jq8 |
| 36 | 年中巨献：竞价题材强弱辨别与去留 | 36_年中巨献：竞价题材强弱辨别与去留.md | https://www.tgb.cn/a/29OckftwZ9V |
| 37 | 大局观：反包与接力风格的切换 | 37_大局观：反包与接力风格的切换.md | https://www.tgb.cn/a/29z0iMFVLdt |
| 38 | 重磅奖品！第一届“花园杯”研股比赛周赛 | 38_重磅奖品！第一届“花园杯”研股比赛周赛.md | https://www.tgb.cn/a/29gIWeeROXU |
| 39 | 男神节活动：再谈接力环境以及后市零碎所思 | 39_男神节活动：再谈接力环境以及后市零碎所思.md | https://www.tgb.cn/a/296BurQBc5M |
| 40 | [投票]顶级逻辑8：高标是如何被大资金打造出来的 | 40_[投票]顶级逻辑8：高标是如何被大资金打造出来的.md | https://www.tgb.cn/a/2954NjxkXpl |
| 41 | 顶级逻辑7：大局观的切换 | 41_顶级逻辑7：大局观的切换.md | https://www.tgb.cn/a/28QcCyH6zcs |
| 42 | 随笔4：端午竞股活动说明+盘面简笔与后市 | 42_随笔4：端午竞股活动说明+盘面简笔与后市.md | https://www.tgb.cn/a/28JzEIzgz4I |
| 43 | 于暴雨中行走，伞是倒划天空的船。 | 43_于暴雨中行走，伞是倒划天空的船。.md | https://www.tgb.cn/a/28EyAsfDTlb |
| 44 | 集中一点，登峰造极。 | 44_集中一点，登峰造极。.md | https://www.tgb.cn/a/28w7FDVweUA |
| 45 | 顶级逻辑6：如何在启动点参与市场龙头高标？顶级大局观周复盘 | 45_顶级逻辑6：如何在启动点参与市场龙头高标？顶级大局观周复盘.md | https://www.tgb.cn/a/28kDFHQCK0S |
| 46 | 宏观基础3：超短预期、研报与运价指数 | 46_宏观基础3：超短预期、研报与运价指数.md | https://www.tgb.cn/a/28dXW0sEh9h |
| 47 | 5.8直播预告：盘面梳理+市值管理、庄股案例 | 47_5.8直播预告：盘面梳理+市值管理、庄股案例.md | https://www.tgb.cn/a/285vH18Znlm |
| 48 | 职业基础2：尾盘买法+接力连扳心法 | 48_职业基础2：尾盘买法+接力连扳心法.md | https://www.tgb.cn/a/27QNkHjQIsH |
| 49 | 盘面随笔3：明日接力行情预案，破局还是A杀 | 49_盘面随笔3：明日接力行情预案，破局还是A杀.md | https://www.tgb.cn/a/27Iur8ZuTk7 |
| 50 | 职业基础：操盘手做盘的核心秘密 | 50_职业基础：操盘手做盘的核心秘密.md | https://www.tgb.cn/a/27GMqbtYW1b |
| 51 | 4.22直播预告：职业超短的框架完结篇。 | 51_4.22直播预告：职业超短的框架完结篇。.md | https://www.tgb.cn/a/27DovTfdEq5 |
| 52 | 盘面随笔2：四月的第一碗面！ | 52_盘面随笔2：四月的第一碗面！.md | https://www.tgb.cn/a/27ypQmSKIVF |
| 53 | 顶级逻辑5：超跌反转日，普涨如何参与？ | 53_顶级逻辑5：超跌反转日，普涨如何参与？.md | https://www.tgb.cn/a/27wLJmWAKO2 |
| 54 | 随笔：退潮日如何避开接力陷阱 | 54_随笔：退潮日如何避开接力陷阱.md | https://www.tgb.cn/a/27v9772a3fL |
| 55 | 4.15号直播预告，不了解市场的骨干还敢继续炒？ | 55_4.15号直播预告，不了解市场的骨干还敢继续炒？.md | https://www.tgb.cn/a/27t2Crm4oas |
| 56 | 6B参与莱绅通灵买点简析+首播预告 | 56_6B参与莱绅通灵买点简析+首播预告.md | https://www.tgb.cn/a/27otslqD23w |
| 57 | 顶级做盘逻辑4：为什么我能预判瀑布杀？ | 57_顶级做盘逻辑4：为什么我能预判瀑布杀？.md | https://www.tgb.cn/a/27mNR5EZlli |
| 58 | 顶级逻辑3；大资金竞价怎么看题材？提高你3年竞价认知 | 58_顶级逻辑3；大资金竞价怎么看题材？提高你3年竞价认知.md | https://www.tgb.cn/a/27l7z4gy3CN |
| 59 | 顶级逻辑2：卡位与晋级 | 59_顶级逻辑2：卡位与晋级.md | https://www.tgb.cn/a/27jubnOULJG |
| 60 | 顶级逻辑：新号首帖直播说明！ | 60_顶级逻辑：新号首帖直播说明！.md | https://www.tgb.cn/a/27hLKkjBdDB |
| 61 | [红包]26.8.19 内驱与外驱 | 61_[红包]26.8.19 内驱与外驱.md | https://www.tgb.cn/a/2uo9dXwVA4H |
