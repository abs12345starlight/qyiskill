#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
见股起意知识库 · 打包

命名规则（主人 2026-10-10 定）：

    qyiskill_<月>.<日>v1.zip      普通包（含凭证与路径配置，自己用）
    qyiskill_<月>.<日>v2.zip      脱敏包（可公开分发 / 传 GitHub）

    日期形如 10.1、10.10 —— 就是「月.日」，与包在同一年的语境下足够区分。

用法
----
    python 打包.py            # 两个包都打
    python 打包.py --v1       # 只打普通包
    python 打包.py --v2       # 只打脱敏包

输出目录：默认写到 <ROOT>（车间）或技能目录的父目录（原地模式），
        可用 --out 指定。
"""

import os
import re
import sys
import zipfile
import argparse
from datetime import datetime

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import importlib

公共库 = importlib.import_module("公共库")


# ===== 排除规则 =====

# 两个包都排除：没意义的运行时垃圾
ALWAYS_EXCLUDE_DIRS = {"__pycache__", ".git", ".venv", ".idea", ".vscode"}
ALWAYS_EXCLUDE_EXT = {".pyc", ".pyo", ".zip", ".rar", ".7z"}
ALWAYS_EXCLUDE_FILES = {
    ".DS_Store", "Thumbs.db", "desktop.ini",
    # 路径配置.txt 指向本机车间目录，带出去会「悄悄」把脚本拽去别的路径
    # （DS 侧踩过：原地模式因此失效且不报错）→ 两个包都不带
    "路径配置.txt",
}

# 只有 v2（脱敏）额外排除（凭证类）
V2_EXCLUDE_FILES = {"cookie.txt", "cookie.txt.bak"}


# ===== 脱敏替换规则 =====
# (正则, 替换文本) —— 用正则兜住各种写法差异。
# ⚠ 这里刻意不写死本机用户名，用 [^/\\]+ 兜住任意用户名，
#   否则规则本身会带上 uid，脱敏包扫自己时会误报「有残留」。
_HOME_WIN = re.compile(r'([A-Za-z]:[/\\]Users[/\\])[^/\\]+')
_HOME_POSIX = re.compile(r'(/(?:Users|home)/)[^/]+')

SANITIZE_RULES = [
    # 内置备用 cookie / tgbuser / tgbpwd 一律清空
    (re.compile(r'(FALLBACK_COOKIE\s*=\s*\()\s*\n?(?:.*?\n)*?\s*\)', re.S),
     r'\1""  # 【已脱敏】原内置 cookie 已移除，请自备 cookie.txt\n)'),
    (re.compile(r'tgbuser=\d+'), 'tgbuser=<已脱敏>'),
    (re.compile(r'tgbpwd=[0-9a-f]+[a-z0-9]*'), 'tgbpwd=<已脱敏>'),
    (re.compile(r'JSESSIONID=[A-Za-z0-9_\-]+'), 'JSESSIONID=<已脱敏>'),
    # 本机绝对路径：先打掉具体子目录，再把用户名泛化
    (re.compile(r'([A-Za-z]:[/\\]Users[/\\][^/\\]+[/\\])WorkBuddy[/\\]2026-07-29-10-57-33'),
     r'\1<工作目录>'),
    (re.compile(r'([A-Za-z]:[/\\]Users[/\\][^/\\]+[/\\])\.workbuddy[/\\]skills[/\\]qyiskill'),
     r'\1<技能目录>'),
    (re.compile(r'([A-Za-z]:[/\\]Users[/\\][^/\\]+[/\\])\.dsh[/\\]skills[/\\]qyiskill'),
     r'\1<技能目录>'),
    (re.compile(r'([A-Za-z]:[/\\]Users[/\\][^/\\]+[/\\])\.workbuddy[/\\]binaries[/\\]python'
                r'[/\\]envs[/\\]default[/\\]Scripts[/\\]python\.exe'),
     r'\1python.exe'),
    (_HOME_WIN, r'\1<用户>'),
    (_HOME_POSIX, r'\1<用户>'),
]

# 需要脱敏扫一遍的文本文件类型
TEXT_EXT = {".py", ".md", ".txt", ".cmd", ".bat", ".sh", ".html", ".json", ".yaml", ".yml"}


def _date_tag():
    now = datetime.now()
    return f"{now.month}.{now.day}"


def _iter_files(skill_dir, sanitize):
    """遍历技能目录，产出 (绝对路径, 归档内相对路径)"""
    parent = os.path.dirname(skill_dir)
    for base, dirs, files in os.walk(skill_dir):
        dirs[:] = [d for d in dirs if d not in ALWAYS_EXCLUDE_DIRS]
        for f in files:
            if f in ALWAYS_EXCLUDE_FILES:
                continue
            if os.path.splitext(f)[1].lower() in ALWAYS_EXCLUDE_EXT:
                continue
            if sanitize and f in V2_EXCLUDE_FILES:
                continue
            p = os.path.join(base, f)
            yield p, os.path.relpath(p, parent)


def _sanitize_text(path):
    """读文本 → 替换敏感串。返回新内容；若不是文本或无需改则返回 None"""
    if os.path.splitext(path)[1].lower() not in TEXT_EXT:
        return None
    try:
        with open(path, "r", encoding="utf-8") as fp:
            s = fp.read()
    except (UnicodeDecodeError, PermissionError):
        return None
    orig = s
    for pat, repl in SANITIZE_RULES:
        s = pat.sub(repl, s)
    return s if s != orig else None


def build(skill_dir, out_dir, sanitize=False, verbose=True):
    """打一个包。sanitize=True 走脱敏，False 走普通包。返回 (zip路径, 文件数)"""
    if not os.path.isdir(skill_dir):
        raise SystemExit(f"技能目录不存在：{skill_dir}")

    ver = "v2" if sanitize else "v1"
    zname = f"qyiskill_{_date_tag()}{ver}.zip"
    zpath = os.path.join(out_dir, zname)

    n = 0
    sanitized = 0
    with zipfile.ZipFile(zpath, "w", zipfile.ZIP_DEFLATED) as z:
        for p, arc in _iter_files(skill_dir, sanitize):
            if sanitize:
                new = _sanitize_text(p)
                if new is not None:
                    z.writestr(arc, new)
                    sanitized += 1
                    n += 1
                    continue
            z.write(p, arc)
            n += 1

    if verbose:
        size = os.path.getsize(zpath) / 1048576
        tag = "脱敏包" if sanitize else "普通包"
        extra = f"，脱敏改写 {sanitized} 个文件" if sanitize else ""
        print(f"  [{tag}] {zname}  {size:.1f}MB  {n} 文件{extra}")
    return zpath, n


def main():
    ap = argparse.ArgumentParser(description="见股起意知识库打包")
    ap.add_argument("--skill-dir", default=None, help="技能目录（默认自动探测）")
    ap.add_argument("--out", default=None, help="输出目录（默认 <ROOT>）")
    ap.add_argument("--v1", action="store_true", help="只打普通包")
    ap.add_argument("--v2", action="store_true", help="只打脱敏包")
    args = ap.parse_args()

    skill_dir = args.skill_dir or 公共库.get_skill_dir()
    root = 公共库.get_root()

    if args.out:
        out_dir = args.out
    elif os.path.isdir(root) and os.path.abspath(root) != os.path.abspath(skill_dir):
        out_dir = root                      # 车间模式 → 写到车间
    else:
        out_dir = os.path.dirname(skill_dir)  # 原地模式 → 写到技能目录的父目录
    os.makedirs(out_dir, exist_ok=True)

    print("=" * 60)
    print("见股起意知识库 · 打包")
    print("=" * 60)
    print(f"技能目录 : {skill_dir}")
    print(f"输出目录 : {out_dir}")
    print(f"日期标记 : {_date_tag()}")
    print()

    do_v1 = not args.v2 or args.v1
    do_v2 = not args.v1 or args.v2

    if do_v1:
        build(skill_dir, out_dir, sanitize=False)
    if do_v2:
        build(skill_dir, out_dir, sanitize=True)

    print()


if __name__ == "__main__":
    main()
